#!/bin/sh
ocamlbuild expand.native
cp -L expand.native ../bin/expand
