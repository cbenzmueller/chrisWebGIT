let _ =
  let c_in = open_in Sys.argv.(1) in  
  let lexbuf = Lexing.from_channel c_in in
  let include_file flist =
    match flist with
      (Formula.Symbol file)::_ -> (
                    let dir = Filename.dirname (Sys.argv.(1)) in
                    Unix.system (Sys.argv.(0)^" "^dir^"/"^(String.sub file 1 ((String.length file) - 2)));
                    "")
    | _ -> failwith "No filename given"
  in
  Hashtbl.replace (!Formula.dictionary) "$$include" include_file;
  Tptp_config.accumulator := (fun f f_list -> print_string ((Formula.to_string f)^"\n");f_list);
  Tptp_parser.tptp_file Tptp_lexer.token lexbuf
