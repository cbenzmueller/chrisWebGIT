type formula =
  (* Appl function argument_list: *)
    Appl of formula * formula list
  (* Symbol name: *)
  | Symbol of string

val dictionary : (string,formula list -> string) Hashtbl.t ref

val to_string : formula -> string

val set_format : string -> unit
