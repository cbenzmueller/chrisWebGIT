(* Postprocess a parsed formula, default is accumulation into a list *)
val accumulator : (Formula.formula -> Formula.formula list -> Formula.formula list) ref
