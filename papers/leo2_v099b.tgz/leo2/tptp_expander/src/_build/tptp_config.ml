let accumulator = ref (fun f f_list -> f::f_list)
