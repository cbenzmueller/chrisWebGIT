#!/bin/sh
here=`pwd`
cp src/direxpand bin
cd src
./build.sh
cd $here