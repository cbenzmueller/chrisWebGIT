(* ========================================================================= *)
(* User readable terms                                                       *)
(* ========================================================================= *)

open Hol_type
open Util
(* open Signature *)

(** the user-readable terms have a simple structure which should not
    be hidden in an ADT.
    The insertion into the termset is easier to implement if the term
    structure is public. *)
    
type term =
  Symbol of string |
  Appl of term * term |
  Abstr of term * hol_type * term


let is_symbol = function
    Symbol _ -> true
  | _ -> false


let is_variable = function
    Symbol s -> (String.get s 0) >= 'A' && (String.get s 0) <= 'Z'
    (*Symbol s -> Char.uppercase (String.get s 0) = String.get s 0*)
  | _ -> false
  
let get_symbol = function
    Symbol s -> s
  | _ -> failwith "not a symbol"
  
let is_appl = function
    Appl _ -> true
  | _ -> false
  
let is_abstr = function
    Abstr _ -> true
  | _ -> false  


let free_vars t =
  let bound = Hashtbl.create 10 in
  let rec free = function
      Symbol s as t ->
        if Hashtbl.mem bound s then []
	else if is_variable t then [s]
	else []
    | Appl(t1,t2) ->
        concat_unique (free t1) (free t2)
    | Abstr(x,_,t1) ->
        assert(is_symbol x);
        let _ = Hashtbl.add bound (get_symbol x) () in
	free t1
  in free t



let rec get_head_symbol = function
    Symbol s -> Symbol s
  | Abstr(x,_,t1) -> get_head_symbol t1
  | Appl(t1,t2) -> get_head_symbol t1


(** pretty printer *)
let rec to_string = function
    Symbol s -> s
  | Appl(t1,t2) -> (add_pars t1)^" "^(add_pars t2)
  | Abstr(x,ty,t) -> "lambda ["^(to_string x)^"]: "^(to_string t)
and add_pars t =
  if is_symbol t then to_string t
  else "("^(to_string t)^")"


let symboltype gamma s =
  try (gamma s)
  with Failure _ -> new_typevar ()

let empty _ = failwith "empty"
let adjoin gamma v t = fun x -> if x=v then t else gamma x

let type_of sigma t =
  let rec typeof gamma = function
      (*Symbol s -> symboltype gamma s*)
      Symbol s -> (try (gamma s) with Failure _ -> failwith ("type of symbol "^s^" unknown"))
    | Abstr(x,ty,t') ->
        let ty' = typeof (adjoin gamma (get_symbol x) ty) t' in
        abstr_type ty ty'
    | Appl(t1,t2) ->
        let ty1 = typeof gamma t1 in
        let ty2 = typeof gamma t2 in
        if is_funtype ty1 then
          let (ty11,ty12) = (arg_type ty1,result_type ty1) in
          if ty11=ty2 then ty12
          else
            let theta = decompose_constraint (ty11,ty2) in
            try
              substs theta ty12
            with _ -> failwith ("argument type mismatch: "^(to_string t1)^" of type "^(Hol_type.to_string ty1)^
              " applied to "^(to_string t2)^" of type "^(Hol_type.to_string ty2))
        else failwith ("applying a non-function: "^(to_string t1)^" of type "^(Hol_type.to_string ty1)^
              " applied to "^(to_string t1)^" of type "^(Hol_type.to_string ty1))
  in
    try (
      typeof sigma t
    ) with Failure s -> failwith ("in term "^(to_string t)^":\n"^s)
    

let rec all_arg_terms_up_to_term t gt = 
  if t = gt then (true,[])
  else 
    match t with
       Symbol s -> (false,[])
     | Abstr(var,ty,body) -> (false,[])
     | Appl(hd,arg) -> 
	 let (flag,tl) = all_arg_terms_up_to_term  hd gt in
	 (flag,tl@[arg])

let types_of_all_arg_terms_up_to_term t gt sigma = 
  let (flag,termlist) = (all_arg_terms_up_to_term t gt) in
 (flag,(List.map (fun term -> type_of sigma term) termlist)) 

let rec bn bound = function
    Symbol s ->
      if List.mem_assoc s bound then
        List.assoc s bound
      else Symbol s
  | Appl(Abstr(x,_,t1),t2) ->
      assert(is_symbol x);
      bn ((get_symbol x, bn bound t2)::bound) t1
  | Appl(t1,t2) -> Appl(bn bound t1, bn bound t2)
  | Abstr(x,ty,t1) -> Abstr(x,ty,bn bound t1)

let beta_normalize = bn []


let multi_abstr args body =
  List.fold_right (fun (x,ty) acc -> Abstr(Symbol x, ty, acc)) args body

let multi_quantified quantifier args body =
  List.fold_right (fun (x,ty) acc -> Appl(quantifier,Abstr(Symbol x, ty, acc))) args body

let de_multi_abstr t =
	let rec chip acc = function
	    Abstr(Symbol x, ty, body) -> chip ((x,ty)::acc) body
	  | t' -> (List.rev acc, t') in
	chip [] t

let de_multi_quantified t =
	let rec chip quantifier acc = function
	    Appl(quantifier',Abstr(Symbol x, ty, body)) as t' ->
	      if quantifier = quantifier' then chip quantifier ((x,ty)::acc) body
	      else (quantifier, List.rev acc, t')
	  | t' -> (quantifier, List.rev acc, t') in
	match t with
	  Appl(Symbol q as quantifier,func) ->
	    if q = "!" or q = "?" then chip quantifier [] t
	    else failwith "no quantifier found"
	| _ -> failwith "no quantifier found"
	
  
  


let lstapp acc el =
	acc^(if acc="" then "" else ",")^el

(* signature names to hotptp names *)
let hotptpsymb_critical = function
          "~" -> "~"
	| "|"  -> "|"
	| "&" -> "&"
	| "~|" -> "~|"
	| "~&" -> "~&"
	| "=" -> "="
	| "!=" -> "!="
	| "=>" -> "=>"
	| "<=" -> "<="
	| "<=>" -> "<=>"
	| "<~>" -> "<~>"
	| "?" -> "?"
	| "!" -> "!"

  | s -> failwith "unknown symbol"
	


(** conversion in HOTPTP *)

let rec to_hotptp = function
    Symbol s -> (
				match s with
					"$true" -> "$true"
				| "$false" -> "$false"
				| _ -> s)
	| Appl(Symbol "!", Abstr(_,_,_)) as t ->
	    Util.sysout 3 "\n Enter hier";
	    Util.sysout 3 ("\n Printing: "^(to_string t)^"\n");
	    let res =
	      let (_,args,body) = de_multi_quantified t in 
	        Util.sysout 3 ("\n Body: "^(to_string body)^"\n");
		" ! ["^(List.fold_left
			  (fun acc (x,ty) -> lstapp acc	(x^":"^(Hol_type.to_hotptp ty)))
			  "" args)^"]:"^(add_pars body)
	    in (Util.sysout 3 "\n Leave hier"; res)
	| Appl(Symbol "?", Abstr(_,_,_)) as t ->
				let (_,args,body) = de_multi_quantified t in
				" ? ["^(List.fold_left
					(fun acc (x,ty) -> lstapp acc	(x^":"^(Hol_type.to_hotptp ty)))
					"" args)^"]:"^(add_pars body)
  | Abstr(_,_,_) as t ->
				let (args,body) = de_multi_abstr t in
				" ^ ["^(List.fold_left
					(fun acc (x,ty) -> lstapp acc	(x^":"^(Hol_type.to_hotptp ty)))
					"" args)^"]:"^(add_pars body)
  | Appl(Appl(Symbol binop, t1),t2) -> (
			try ((add_pars t1)^" "^(hotptpsymb_critical binop)^" "^(add_pars t2))
			with _ -> "("^binop^"@"^(add_pars t1)^")@"^(add_pars t2)) (* FIXME: will not print correctly Appl(Appl(Symbol "~", t1),t2) *)
  | Appl(Symbol unop,t) -> (
			try ((hotptpsymb_critical unop)^" ("^(to_hotptp t)^")")
			with _ -> unop^"@"^(add_pars t))
  | Appl(t1,t2) ->
  		(add_pars t1)^"@"^(add_pars t2)
and add_pars t =
  if is_symbol t then to_hotptp t
  else "("^(to_hotptp t)^")"


let rec to_compressed = function
    Symbol s -> s
  | Appl(Symbol "!", _) as t ->
        let (_,args,body) = de_multi_quantified t in
        "! ["^(List.fold_left
          (fun acc (x,ty) -> lstapp acc (x^":"^(Hol_type.to_hotptp ty)))
          "" args)^"] : "^(add_pars body)
  | Appl(Symbol "?", _) as t ->
        let (_,args,body) = de_multi_quantified t in
        "? ["^(List.fold_left
          (fun acc (x,ty) -> lstapp acc (x^":"^(Hol_type.to_hotptp ty)))
          "" args)^"] : "^(add_pars body)
  | Abstr(_,_,_) as t ->
        let (args,body) = de_multi_abstr t in
        "^ ["^(List.fold_left
          (fun acc (x,ty) -> lstapp acc (x^":"^(Hol_type.to_hotptp ty)))
          "" args)^"] : "^(add_pars body)
  | Appl(Appl(Symbol binop, t1),t2) -> (
      try ((add_pars t1)^(hotptpsymb_critical binop)^(add_pars t2))
      with _ -> "("^binop^" "^(add_pars t1)^") "^(add_pars t2)) (* FIXME: will not print correctly Appl(Appl(Symbol "neg", t1),t2) *)
  | Appl(Symbol unop,t) -> (
      try ((hotptpsymb_critical unop)^(add_pars t))
      with _ -> unop^" "^(add_pars t))
  | Appl(t1,t2) ->
      (add_pars t1)^" "^(add_pars t2)
and add_pars t =
  if is_symbol t then to_compressed t
  else "("^(to_compressed t)^")"



(** conversion in POST *)

									 
let postsymb_critical = function
    "~" -> "not"
  | "|"  -> "or"
  | "&" -> "and"
  | "~|" -> failwith "unknown post representation"
  | "~&" -> failwith "unknown post representation"
  | "=" -> "="
  | "!=" -> failwith "unknown post representation"
  | "=>" -> "implies"
  | "<=" -> failwith "unknown post representation"
  | "<=>" -> "equiv"
  | "<~>" -> failwith "unknown post representation"
  | "!" -> failwith "unknown post representation"
  | "?" -> failwith "unknown post representation"
  | s -> failwith "unknown symbol"



let rec to_post = function
    Symbol s -> 
      (match s with
	"$true" -> "true"
      | "$false" -> "false"
      | _ -> s)
  | Appl(Symbol "!",Abstr(Symbol x, ty, body)) -> 
      "(forall (lam ("^x^" "^(Hol_type.to_post ty)^") "^(to_post body)^"))"
  | Appl(Symbol "?",Abstr(Symbol x, ty, body)) -> 
      "(exists (lam ("^x^" "^(Hol_type.to_post ty)^") "^(to_post body)^"))"
  | Abstr(_,_,_) as t ->
      let (args,body) = de_multi_abstr t in
      ((List.fold_left (fun acc (x,ty) -> ("(lam ("^x^" "^(Hol_type.to_post ty)^") ")) "" args)
       ^(to_post body)^")")
  | Appl(Appl(Symbol binop, t1),t2) -> (
      try "("^(postsymb_critical binop)^" "^(to_post t1)^" "^(to_post t2)^")"
      with _ -> "("^binop^" "^(to_post t1)^" "^(to_post t2)^")"
     )
  | Appl(Symbol unop,t) -> (
      try "("^(postsymb_critical unop)^" "^(to_post t)^")"
      with _ -> "("^unop^" "^(to_post t)^")"
     )
  | Appl(t1,t2) ->
      "("^(to_post t1)^" "^(to_post t2)^")"

let termlist_to_string (ts:term list) =
  "["^(List.fold_left (fun s t -> (s^(to_post t)^" ")) " " ts)^"]"
