(* ========================================================================= *)
(* Index Test                                                                *)
(* ========================================================================= *)

(* only some tests so far *)

open Hol_type
open Signature
open Term
open Termset

(** Test 1: generic tests for termset *)
let test1 () =
  print_string "\nTest 4: Indexing Church Numerals\n";

  let ts = new_termset () in
  let rec church_num'(n) = (match n with 0 -> Symbol "x"
                                      | _ -> Appl(Symbol "f",church_num'(n-1)))
  in

  let church_num(n) =  Abstr(Symbol "f", abstr_type bt_i bt_i, Abstr(Symbol "x", bt_i, church_num'(n))) in
  let numeraltype = abstr_type (abstr_type bt_i bt_i) (abstr_type bt_i bt_i) in

  let ten = church_num(3) in

  let times = Abstr(Symbol "m", numeraltype, Abstr(Symbol "n", numeraltype, Abstr(Symbol "f", (abstr_type bt_i bt_i), Abstr(Symbol "x", bt_i,
    Appl(Appl(Symbol "m", Appl(Symbol "n", Symbol "f")),Symbol "x" ))))) in

  let t = Appl(Appl(times,Appl(Appl(times,ten),ten)),ten) in

  (* let t=church_num 15 in 
  let t = Appl(Symbol "f", Appl(Appl(Symbol "g", Abstr(Symbol "x", bt_i, Appl(Symbol "h", Symbol "x"))), Symbol "j")) in

  let t=Appl(Abstr(Symbol"x", bt_i, Abstr(Symbol "y", bt_i, Appl(Abstr (Symbol "z",bt_i,Symbol "z"), Symbol "x"))),Abstr(Symbol "u",bt_i,Symbol "a")) in *)
  print_string ("\nadding term: "^(Term.to_string t)^"\n");
  let id_t = create ts t in
  print_string ("->index: "^(string_of_int id_t)^"\n\n");
  print_string "termset:\n";
  print_string (Termset.to_string ts);

  print_string ("\nretrieve("^(string_of_int id_t)^"): "^(Term.to_string (retrieve ts id_t))^"\n"); 


  let idx = new_index ts in
  Termset.index_node id_t idx;
(*  Hashtbl.iter (fun a b -> print_string ((Term.to_string (retrieve ts a))^" : "^(Term.to_string (retrieve ts b))^"\n"))
               idx.headsymbol; 
  print_string "\nHeadsymbols (term : head):\n"; *)
  Hashtbl.iter (fun a b -> print_string ((Term.to_string (retrieve ts a))^" : "^(Term.to_string (retrieve ts b))^"\n"))
               idx.headsymbol; 

  print_string "\nHeadsymbols occur in (head : term):\n";
  Hashtbl.iter (fun a b -> print_string ((Term.to_string (retrieve ts a))^" : "^(Term.to_string (retrieve ts b))^"\n"))
               idx.has_headsymbol; 

  print_string "\noccurrences (pos : term):\n";
  Hashtbl.iter (fun a b -> Hashtbl.iter (fun c d -> print_string
                              ((Term.to_string (retrieve ts c))^" occurs in "^(Term.to_string (retrieve ts a))^" at :\n"^
                               (Position.show_all_entries (fun a -> Term.to_string (retrieve ts a)) d)))
                           b)
               idx.occurrences; 
  print_string "Done.\n"


(** Test 2: Read from file *)
let test2 () =
  let ts = new_termset () in
  let idx = new_index ts in
  let lexbuf = Lexing.from_channel stdin in
  let (termlist,sigma,_) = Htparser.input Htlexer.token lexbuf in
  let _ = List.iter (fun t -> print_string ((Term.to_string t)^"\n");
                              let id_t = create ts t in
                              print_string ("->index: "^(string_of_int id_t)^"\n\n");
                              Termset.index_node id_t idx
                    )
                    termlist in
  flush stdout;
  print_string "termset:\n";
  (*print_string (Termset.to_string ts);*)

  print_string "\nHeadsymbols (term : head):\n"; 
  Hashtbl.iter (fun a b -> print_string ((Term.to_string (retrieve ts a))^" : "^(Term.to_string (retrieve ts b))^"\n"))
               idx.headsymbol; 

  print_string "\nHeadsymbols occur in (head : term):\n";
  Hashtbl.iter (fun a b -> print_string ((Term.to_string (retrieve ts a))^" : "^(Term.to_string (retrieve ts b))^"\n"))
               idx.has_headsymbol; 

  print_string "\noccurrences (pos : term):\n";
  Hashtbl.iter (fun a b -> Hashtbl.iter (fun c d -> print_string
                              ((Term.to_string (retrieve ts c))^" occurs in "^(Term.to_string (retrieve ts a))^" at :\n"^
                               (Position.show_all_entries (fun a -> Term.to_string (retrieve ts a)) d)))
                           b)
               idx.occurrences; 
  print_string "Done.\n"







let main =
try
 (*  test1 (); *)
  test2 ()
with
 | Failure x -> (prerr_string ("\nError found: \n" ^ x ^ "\n"); exit(255))
 | e -> (prerr_string ("\n" ^ Printexc.to_string e ^ "\n"); exit (255))
