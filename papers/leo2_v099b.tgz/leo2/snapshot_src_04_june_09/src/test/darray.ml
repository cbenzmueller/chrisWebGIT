
type 'a darray =
  { mutable data : 'a array;
    mutable size : int }
    
let da_make s e = {
  data = Array.make s e;
  size = 0}
  
let da_insert da e =
  if da.size = Array.length da.data
  then (
    if Array.length da.data = 0
    then da.data <- [|e|]
    else (
      let newarray = Array.make (2 * da.size) e in
      Array.blit da.data 0 newarray 0 da.size;
      da.data <- newarray)
  );
  da.data.(da.size) <- e;
  da.size <- da.size + 1
  
let da_copy da = {
  data = Array.copy da.data;
  size = da.size}
          
let array2da ar = {
  data = ar;
  size = Array.length ar}
  
let da2array da =
  Array.sub da.data 0 da.size
  
let da_get da i =
  assert(i<da.size);
  da.data.(i)
  
let da_set da i v =
  assert(i<da.size);
  da.data.(i) <- v
  
let da_size da =
  da.size
