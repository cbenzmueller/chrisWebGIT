
open Hol_type
open Term
open Signature


(* print_string "Testing polymorphic type inference on explicit terms\n\n"; *)

let poly0 = mk_polyvar 0 in

(*
let t1 =
  Abstr(Symbol "X", abstr_type poly0 (abstr_type poly0 bt_o),
    Appl(
      Appl(
        Symbol "X",
        Symbol "Y"),
      Symbol "Z"
    )
  ) in
*)

(* from Landau *)
let transitive =
  Abstr(Symbol "X", abstr_type poly0 (abstr_type poly0 bt_o),
    Appl(
      Symbol "forall",
      Abstr(Symbol "U", poly0,
        Appl(
          Symbol "forall",
	        Abstr(Symbol "Z", poly0,
	          Appl(
	            Symbol "forall",
		          Abstr(Symbol "Y", poly0,
		            Appl(           
		              Appl(
		                Symbol "implies",                
		                Appl(               
		                  Appl(
		                    Symbol "and",                   
		                    Appl(
		                      Appl(
		                        Symbol "X",
		                        Symbol "U"
		                      ),
		                      Symbol "Z"
		                    )
		                  ),
		                  Appl(
		                    Appl(
		                      Symbol "X",
		                      Symbol "Z"
		                    ),
		                    Symbol "Y"
		                  )
		                )
		              ),
		              Appl(
		                Appl(
		                  Symbol "X",
		                  Symbol "U"
		                ),
		                Symbol "Y"
		              )
		            )
		          )
		        )
	        )
	      )
	    )
	  )
	) in
let sigma1 = function
    "and" -> abstr_type bt_o (abstr_type bt_o bt_o)
 | "implies" -> abstr_type bt_o (abstr_type bt_o bt_o)
 | "forall" -> abstr_type (abstr_type poly0 bt_o) bt_o
 | _ -> raise (Failure "sigma1")
in
print_string ("Term 1: "^(Term.to_hotptp transitive)^"\n");
print_string ("  Type: "^(Hol_type.to_string (Term.type_of sigma1 transitive))^"\n\n");


let t2 = Appl(Symbol "equal", Symbol "equal") in
let sigma2 = function
    "equal" -> abstr_type poly0 (abstr_type poly0 bt_o)
  | _ -> failwith "unknown" in
print_string ("Term 2: "^(Term.to_hotptp t2)^"\n");
print_string ("  with type(equal)="^(Hol_type.to_string (sigma2 "equal"))^"\n");
print_string ("  Type: "^(Hol_type.to_string (Term.type_of sigma2 t2))^"\n\n")



