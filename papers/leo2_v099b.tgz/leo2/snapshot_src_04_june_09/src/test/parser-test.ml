
open Hol_type
open Term
open Signature
open List
open Termset


let _ =
  let ts = new_termset () in
  let idx = new_index ts in
  let lexbuf = Lexing.from_channel stdin in
  let (termlist,sigma,_) = Htparser.input Htlexer.token lexbuf in
    let _ = print_string "\ntype variables:\n" in
    let _ = iter print_endline (all_type_vars sigma) in

    let _ = print_string "\nuninterpreted terms:\n" in
		let _ = iter (fun (s,ty) ->
			print_string (s^": "^(Hol_type.to_string ty)^"\n")) (all_uninterpreted_symbols sigma) in
    
    let _ = print_string "\ndefined terms:\n" in
    let _ = iter (fun (s,(t,ty)) ->
      (print_string (s^": "^(Term.to_string t)^"\n");
       let id_t = create ts t in
       print_string ("->index: "^(string_of_int id_t)^"\n");
       Termset.index_node id_t idx))
      (all_defined_symbols sigma) in
    print_string ("\n"^(string_of_int (List.length (all_defined_symbols sigma)))^" terms defined\n");      
    let _ = print_string "\ncreated terms:\n" in
    let _ = iter (fun t ->
      (print_string ((Term.to_string t)^"\n"));
       let id_t = create ts t in
       print_string ("->index: "^(string_of_int id_t)^"\n");
       Termset.index_node id_t idx)
      termlist in
    flush stdout;

(*   print_string "\nHeadsymbols (term : head):\n"; 
  Hashtbl.iter (fun a b -> print_string ((Term.to_string (retrieve ts a))^" : "^(Term.to_string (retrieve ts b))^"\n"))
               idx.headsymbol; 

  print_string "\nHeadsymbols occur in (head : term):\n";
  Hashtbl.iter (fun a b -> print_string ((Term.to_string (retrieve ts a))^" : "^(Term.to_string (retrieve ts b))^"\n"))
               idx.has_headsymbol;

  print_string "\noccurrences (pos : term):\n";
  Hashtbl.iter (fun a b -> Hashtbl.iter (fun c d -> print_string
                              ((Term.to_string (retrieve ts c))^" occurs in "^(Term.to_string (retrieve ts a))^" at :\n"^
                               (Position.show_all_entries (fun a -> Term.to_string (retrieve ts a)) d)))
                           b)
               idx.occurrences; *)

  (* let id1=16 in *)
  (* let idl =[13;15;2018;10040;1143;204;11088;11130] in*)
  (*let idl=[2;12;14;23;45;56] in*)
  let idl=[28;55;71] in
  List.iter (fun id1 ->
  (print_string ("\nTerm: "^(Term.to_string (retrieve ts id1))^"\n");
  
  let d = Position.merge (Hashtbl.fold (fun a b c -> b::c)
                         (Hashtbl.find idx.occurrences id1) []) in
  print_string ((Position.show_all_entries (fun a -> Term.to_string (retrieve ts a)) d)^
                "Size: "^(string_of_int (Position.size_of d))^
                "\nSize (alt): "^(string_of_int (Termset.size_of_term ts id1))^
                "\nNumber of symbols: "^(string_of_int (Hashtbl.length (Hashtbl.find idx.occurrences id1)))^"\n");

  
  if (Hashtbl.mem idx.boundoffset id1) then 
  (print_string ("\nBound vars in node "^(string_of_int id1)^": "^(Term.to_string (retrieve idx.termbase id1))^
   " with offset "^(string_of_int (Hashtbl.find idx.boundoffset id1))^":\n");
   List.iter (fun a->print_string
   ((Position.show_all_entries string_of_int a)^
    "Size: "^(string_of_int (Position.size_of a))^"\n\n"))
   (Hashtbl.find idx.boundvars id1))
  else print_string ("\n"^(Term.to_string (retrieve idx.termbase id1))^" has no binders\n");

  print_string ("\nBeta reducable in term: "^(Term.to_string (retrieve ts id1))^"\n");
  
  let d = beta_reducable id1 idx in
  print_string (Position.show_all_entries string_of_int d)))
  idl;

(*  start_timer "ana"; *)
  let timedexpr = analyze_termset idx in
(*  stop_timer "ana"; *)
  
  let term1=71 in
  (*let term1=204 in*)
  (*let term1=22 in*)

  let rplcd=(Substitution.apply_replace ts term1 (Position.modify (beta_reducable term1 idx) (fun a -> 1))) in
  Termset.index_node rplcd idx;
  print_string ("\nReplace beta reducables in\n"^(Term.to_string (retrieve ts term1))^"\nwith "^
               (Term.to_string (retrieve ts 1))^":\n"^
               (Term.to_string (retrieve ts rplcd))^
               "\n-> index "^(string_of_int rplcd));
  let d = Position.merge (Hashtbl.fold (fun a b c -> b::c)
                         (Hashtbl.find idx.occurrences rplcd) []) in
  print_string ((Position.show_all_entries (fun a -> Term.to_string (retrieve ts a)) d)^
                "Size: "^(string_of_int (Position.size_of d))^
                "\nNumber of symbols: "^(string_of_int (Hashtbl.length (Hashtbl.find idx.occurrences rplcd)))^"\n");
  analyze_termset idx;
 (*	List.iter (fun (time,proc) ->
			Printf.printf "%.5f: %s\n" time proc
	) (get_all_totals ()); *)
            
  print_string "\nDone.\n"

            
