(*
* Demo Code File for LPAR 2006
*)
open Hol_type
open Term
open Signature
open List
open Termset
open Substitution


let _ =
  let ts = new_termset () in
  let idx = new_index ts in


print_string "Save TeX output in file: ";
(* let filename = read_line () in *)
let filename = "../doc/talks/iwil-2006-demo.tex" in
let texfile = open_out filename in


let pause _ = print_string "\n\n<Return>\n"; read_line () in
let texout s = output_string texfile s in
let printout s = texout s; print_string s in
 

texout "
\\documentclass[a4paper,11pt]{article}
\\textwidth  14.63cm
\\textheight 22cm
\\oddsidemargin  0.65cm
\\evensidemargin 0.65cm
\\topmargin  2.00cm
\\headheight 0.0pt
\\headsep    0.0pt

\\usepackage{pstricks}
\\usepackage{pst-node}
\\usepackage{pst-tree}


\\begin{document}
";


(*
*  1. HOTPTP Representation 
*  theorem: (not (element-of a emptyset))
*  definition: element-of := (lambda y (lambda s (s y)))
*  definition: emptyset := (lambda z false) 
*)
  let termdef="
hof(emptyset,definition,
	(emptyset :=
		(^ [Z : $i] : $false))).

hof(element,definition,
	(element :=
		(^ [Y:$i, S:($i > $o)] : (S @ Y)))).

hof(theorem1,definition,
	(theorem1 := (~ ((element @ A) @ emptyset)))).

hof(theorem1alt,definition,
	(theorem1alt := (((element @ A) @ emptyset) => $false))).
" in

  let faketermdef="
thf(emptyset,definition,
	(emptyset :=
		(^ [Z : $i] : $false))).

thf(element,definition,
	(element :=
		(^ [Y:$i, S:($i > $o)] : (S @ Y)))).

thf(theorem1,conjecture,
	(~ ((element @ A) @ emptyset))).

thf(theorem1alt,conjecture,
	(((element @ A) @ emptyset) => $false)).
" in


  printout "\n\n";
  texout "\\section{";
  printout "Definitions of emptyset, element and the theorem in HOTPTP syntax:";
  texout "}";
  printout "\n\n";

  texout "
\\begin{verbatim}
";

  printout (faketermdef^"\n\n");

  texout "
\\end{verbatim}
";

  pause ();

(*
*  2. Parsing the Problem 
*)


  printout ("\n\nParsing...\n");

  let terms=["emptyset";"element";"theorem1";"theorem1alt"] in
  let lexbuf = Lexing.from_string termdef  in
  let (_,sigma,_) = Htparser.input Htlexer.token lexbuf in
  let termids = Hashtbl.create 3 in




(*
*  3. The complete termset (incl. de Bruijn representation) for the problem 
*  and the two definitions
*)
  printout "\n\n";
  texout "\\section{";
  printout ("Adding terms to term set:");
  texout "}";
  printout "\n\n";


  iter (fun t ->
    let term=get_defined_symbol sigma t in
  texout "
\\begin{verbatim}
";
    printout (t^": "^(Term.to_string term));
    let id_t = create ts term in
    printout ("->index: "^(string_of_int id_t));
    Termset.index_node id_t idx;
    Hashtbl.add termids t id_t;

  texout "
\\end{verbatim}
";

    texout (node_to_tex ts id_t))
    terms;

(*  analyze_termset idx; *)

  printout "Only three nodes (14,15 and 16) have been introduced.\n\n";

  pause ();

(*
*  4. Initial state of all hashtables
*)
  printout "  ";
  texout "\\section{";
  printout "Initial state";
  texout "}";
  printout "  ";


  printout ("\n\nThe term set:\n\n");

  texout "
\\begin{verbatim}
";

  printout (Termset.to_string ts);

  texout "
\\end{verbatim}
";

  pause ();

(*
*  5. Replace definition of emptyset / motivate PSTs and display them
*)
  printout "\n\n";
  texout "\\section{";
  printout ("Expand definition of emptyset:");
  texout "}";
  printout "\n\n";

  printout ("\n\nPST for occurrences of symbol emptyset in theorem1:\n\n");

  let th1_def=(Hashtbl.find termids "theorem1") in
  let es_def=(Hashtbl.find termids "emptyset") in
  let el_def=(Hashtbl.find termids "element") in
  let es_sym=Termset.create ts (Symbol "emptyset") in
  let el_sym=Termset.create ts (Symbol "element") in
  let pst1=Termset.occurrences th1_def es_sym idx in

  texout "
\\begin{verbatim}
";
  printout (Position.show_all_entries (fun a -> Term.to_string (retrieve ts a)) pst1);

  texout "
\\end{verbatim}
";

  texout (Position.to_tex (fun a -> Term.to_string (retrieve ts a)) pst1);


  let th2_def=Substitution.replace_by_fun ts th1_def pst1 (fun _ _ -> es_def) in
  texout "
\\begin{verbatim}
";
  printout ("theorem2: "^(Term.to_string (retrieve ts th2_def)));
  printout ("\n->index: "^(string_of_int th2_def)^"\n");
  texout "
\\end{verbatim}
";
  texout (node_to_tex ts th2_def);

  Termset.index_node th2_def idx;

  pause ();

(*
*  6. Normalize
*)
  printout "\n\n";
  texout "\\section{";
  printout ("Normalize:");
  texout "}";
  printout "\n\n";


  texout "
Normalization after replacing all occurrences of $t_2$ in term $t_1$ by a term
    $t_3$ depends on:
\\begin{itemize}
\\item The positions, at which replacements have been made, i.e., positions at
    which $t_2$ occurs in $t_1$. Parts of the term not affected by replacement
do not have to be checked.
\\item The number of arguments which can be supplied at these positions. Given
    the path representation of the position, this is the number of trailing
	{\\tt func}s.
\\item The number of arguments the replacement $t_3$ can take. This is the
    number of leading $\\lambda$s in the replacement term.
\\item The depth of $\\beta$-reduction to perform is the minimum of the latter
    two.
\\item Let $n$ be the depth of $\\beta$-reduction, then the position in $t_1$ of the
  replacement to perform to preserve normalization is $n$ steps {\\em above}
  the occurrence of the symbol to be replaced, $t_2$. The term to be inserted here is
  the replacement term $t_3$ after $n$ $\\beta$-reductions, i.e. the term at position
  {\\tt [abstr$_1$;...;abstr$_n$]} in $t_3$, where the affected bound variables
  are replaced.
\\item Wether and where $\\beta$-reduction replaces bound variables in $t_3$ is
  determined by the PSTs recording bound variableoccurrences in $t_3$. These
  are stored in the index.
\\item If there are bound variables to be replaced, normalization recurses. 
\\end{itemize}

As the only position where a replacement has been made is {\\tt [arg;arg]}
here, i.e., there are no trailing {\\tt func}s, no $\\beta$-reduction is
required here to preserve normal form.
";

  texout "
\\begin{verbatim}
";

  let th3_def=Substitution.normalize idx th2_def pst1 in
  texout "
\\end{verbatim}
";
  texout "
\\begin{verbatim}
";
  printout ("theorem3: "^(Term.to_string (retrieve ts th3_def)));
  printout ("\n->index: "^(string_of_int th3_def)^"\n");
  texout "
\\end{verbatim}
";







  texout (node_to_tex ts th3_def);


  pause ();

(*
*  7. Replace definition of elem / motivate PSTs and display them
*)

  printout "\n\n";
  texout "\\section{";
  printout ("Expand definition of element:");
  texout "}";
  printout "\n\n";

  printout ("\n\nPST for occurrences of symbol element in theorem1:\n\n");

  texout "
\\begin{verbatim}
";

  let pst2=Termset.occurrences th3_def el_sym idx in
  printout (Position.show_all_entries (fun a -> Term.to_string (retrieve ts a)) pst2);
  texout "
\\end{verbatim}
";

  texout (Position.to_tex (fun a -> Term.to_string (retrieve ts a)) pst2);

  texout "
\\begin{verbatim}
";

  let th4_def=Substitution.replace_by_fun ts th3_def pst2 (fun _ _ -> el_def) in
  printout ("theorem4: "^(Term.to_string (retrieve ts th4_def)));
  printout ("\n->index: "^(string_of_int th4_def)^"\n");
  Termset.index_node th4_def idx;
  texout "
\\end{verbatim}
";
  texout (node_to_tex ts th4_def);

  pause ();


(*  analyze_termset idx; *)


(*
*  9. Normalize
*)
  printout "\n\n";
  texout "\\section{";
  printout ("Normalize:");
  texout "}";
  printout "\n\n";

  texout "
\\begin{verbatim}
";

  let th5_def=Substitution.normalize idx th4_def pst2 in
  texout "
\\end{verbatim}
";


  texout "Replacement positions are given here by:\n\n";

  texout "
\\begin{verbatim}
";
  texout (Position.show_all_entries (fun a -> Term.to_string (retrieve ts a)) pst2);
  texout "
\\end{verbatim}
";

  texout (Position.to_tex (fun a -> Term.to_string (retrieve ts a)) pst2);


  texout "\n\nwhere the replacement term is:\n\n";

  texout "
\\begin{verbatim}
";
  texout ("element: "^(Term.to_string (retrieve ts el_def)));
  texout "
\\end{verbatim}
";

  texout "In position {\\tt [arg;func;func]}, there are two trailing {\\tt
  func}s. The replacement term has two leading $\\lambda$s, so the depth of
  $\\beta$-reduction is two. Thus the term\n";

  texout "
\\begin{verbatim}
";
  texout ("node4: "^(Term.to_string (retrieve ts 4)));
  texout "
\\end{verbatim}
";

  texout ("has to be inserted at position {"^(String.escaped "tt")^" [arg]} (i.e., with the two trailing {"^(String.escaped "tt")^" func}s cut) with the variables bound by the first two $"^(String.escaped "lambda")^"$-binders replaced. The position of these bound variables is stored  in the index and is given by: "^(String.escaped "footnote")^"{Bound variable positions for each term are stored in a list of PSTs  and an offset, which gives the scope number of the first PST in the list. The scope number of a PST in the list  is that of the previous incremented by one. Thus each element in the list is assigned a scope number. List and offset are constructed as follows: Symbols are assigned an empty list, bound variables have a one-node PST which is marked, offset ist 0 (the variables bound by the next binder above). For an application ${t_1}@{t_2}$ the PSTs of each scope are combined: ${"^(String.escaped "mathit")^"{pst}_{1,i}}@{"^(String.escaped "mathit")^"{pst}_{2,i}}$. For an abstraction $"^(String.escaped "lambda")^".t$, the offset is incremented by one, and the last element of the list is cut if its  scope number is greater than 0.}\n\n");

(*  texout (node_to_tex ts 4);*)
  let pst3 = Position.merge (Hashtbl.find idx.boundvars 4) in
  texout "
\\begin{verbatim}
";
  texout (Position.show_all_entries (fun a -> ("x_"^(string_of_int a))) pst3);
  texout "
\\end{verbatim}
";
  texout (Position.to_tex (fun a -> ("$x_"^(string_of_int a)^"$")) pst3);


  texout "\n\n(Okay, nothing to win here, as every position is taken by a bound variable...)";

  texout "\n\nReplacement of bound variables by the arguments supplied here yields:\n\n";

  texout (node_to_tex ts 22);

  texout "and normalization recurses. The depth of $\\beta$-reduction is one
  here, and as there are no occurrences of bound variables in {\\tt false},
  nothing has to be replaced and the recursion ends.

  The result after normalization is:\n\n";



  texout "
\\begin{verbatim}
";
  printout ("theorem5: "^(Term.to_string (retrieve ts th5_def)));
  printout ("\n->index: "^(string_of_int th5_def)^"\n");
  texout "
\\end{verbatim}
";
  texout (node_to_tex ts th5_def);

(*
*  9. Proof found
*)

  printout ("Proof found!\n\n");

texout "
Note:
\\begin{itemize}
\\item Intermediate results in non-normal form are not stored in the final
  implementation.
\\item Key feature is the guidance for occurrence check and replace provided by PSTs
\\item Positions relevant for replacement and to preserve normal form can be
    found without search, but by using the information gained from PSTs.
\\end{itemize}
";

  printout ("\n\nThe term set:\n\n");

  texout "
\\begin{verbatim}
";

  printout (Termset.to_string ts);
  texout "
\\end{verbatim}
";

  texout "
\\end{document}
";
  flush stdout




