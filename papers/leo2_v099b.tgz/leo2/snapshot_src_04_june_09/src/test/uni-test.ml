open Hol_type
open Signature
open Term
open Termset
open Termsystem



  let ts = new_termset () in
  let idx = new_index ts in

(*  let termdef="thf(transitive_def,definition,(transitive1 := ^ [A: $type] : (^ [X: (A > (A > $o))] : (! [U: A,Z: A,Y: A] : ((((X @ U) @ Z) & ((X @ Z) @ Y)) => ((X @ U) @ Y))))))." in
*)

(*
parsing from standard in:
==============================================*)


  let lexbuf = Lexing.from_channel stdin in 


(* 
==============================================
Parsing from a string:
  
  let lexbuf = Lexing.from_string termdef in 

==============================================
  let (termlist,sigma,termrole) = Htparser.input Htlexer.token lexbuf in
  Hashtbl.iter (fun a (_,b) -> print_string (a ^": "^(Term.to_string b)^"\n")) termrole;
  print_string (signature_to_string sigma);
  let _ = List.iter (fun t -> print_string ((Term.to_string t)^"\n");
                              let id_t = create ts t in
                              print_string ("->index: "^(string_of_int id_t)^"\n\n");
                              Termset.index_node id_t idx
                    )
                    termlist in
  print_string ("Termlist has "^(string_of_int (List.length termlist))^" Elements.\n");
  print_string "termset:\n";
  print_string (Termset.to_string ts);
  print_string ("Term 20 is now:"^(Term.to_string (Termset.retrieve ts 20))^"\n");
  Termset.remove_node ts 17;
  print_string ("Term 20 is now:"^(Term.to_string (Termset.retrieve ts 20))^"\n");
  print_string "\ntermset after removal of node 17:\n";
  print_string (Termset.to_string ts);
  Termset.replace_node ts 5 3;
  print_string "\ntermset after replacing node 5 by node 3:\n";
  print_string (Termset.to_string ts);


  let lexbuf = Lexing.from_string termdef in*)
  let (termlist,sigma,termrole) = Htparser.input Htlexer.token lexbuf in
  (*match List.rev termlist with
    t1::t2::t3::_ -> (
      let terms = List.map (fun t -> let id_t = create ts t in
                            print_string ((Term.to_string t)^"\n");
                            print_string ("->index: "^(string_of_int id_t)^"\n\n");
                            Termset.index_node id_t idx; id_t)
                    [t1;t2;t3] in
      match terms with
        [t1;t2;t3] -> print_string
          ("Applying ["^(Term.to_string (Termset.retrieve ts t2))^"/"^(Term.to_string (Termset.retrieve ts t3))^"] to\n"^
           (Term.to_string (Termset.retrieve ts t1))^"\n");
            let t4=Substitution.apply_subst idx [(t2,t3)] t1 in 
(*          let t4=Substitution.normalize_appl idx t3 t2 in*)
            print_string ("Result: "^(Term.to_string (Termset.retrieve ts t4))^"\n")
      | _ -> ()
  )
  | _ -> print_string "nope.\n";*)


  let _ = List.map (fun t -> Termset.index_with_role idx t 1) termlist in
  print_string "\nTermset:\n\n";
  print_string (Termset.to_string ts);
  print_string "\n\nSome figures:\n\n";
  analyze_termset idx;

  let problem_file="/home/tenzing/spass_problem1" in
  let solution_file="/home/tenzing/spass_solution1" in
  let problem_string="begin_problem(Sokrates1).

list_of_descriptions.
name({*Sokrates*}).
author({*Christoph Weidenbach*}).
status(unsatisfiable).
description({* Sokrates is mortal and since all humans are mortal, he is mortal too. *}).
end_of_list.

list_of_symbols.
  functions[(sokrates,0)].
  predicates[(Human,1),(Mortal,1)].
end_of_list.

list_of_formulae(axioms).

formula(Human(sokrates),1).
formula(forall([x],implies(Human(x),Mortal(x))),2).

end_of_list.

list_of_formulae(conjectures).

formula(Mortal(sokrates),3).

end_of_list.

end_problem.
" in
  let chan = open_out problem_file in
  output_string chan problem_string;
  close_out chan;
  let _ = Sys.command ("SPASS "^problem_file^" > "^solution_file) in
   
  flush stdout
