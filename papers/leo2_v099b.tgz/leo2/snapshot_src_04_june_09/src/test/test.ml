
(* ------------------------------------------------------------------------- *)
(* Types of HOL types, terms, termnodes and termsets                         *)
(* ------------------------------------------------------------------------- *)

type hol_type = string

type term =
  Symbol of string |
  Appl of term * term |
  Abstr of term * hol_type * term
  
type id = int

type nodestruct =
  Symbol_node of string |
  Appl_node of id * id |
  Abstr_node of hol_type * id |
  Bound_node of hol_type * int
  
type termnode = {
  name : id;
  structure : nodestruct
}

type termset = {
 nodes      : termnode darray;
 term2id    : (term,        id) Hashtbl.t;
 appl_with_arg  : (id, (id,id) Hashtbl.t) Hashtbl.t;
 appl_with_func : (id, (id,id) Hashtbl.t) Hashtbl.t;
 abstr_with : (id*hol_type, id) Hashtbl.t
}


(* ------------------------------------------------------------------------- *)
(* Some access functions                                                     *)
(* ------------------------------------------------------------------------- *)

let is_symbol = function
    Symbol _ -> true
  | _ -> false
  
let get_symbol = function
    Symbol s -> s
  | _ -> failwith "not a symbol"
  
let is_appl = function
    Appl _ -> true
  | _ -> false
  
let is_abstr = function
    Abstr _ -> true
  | _ -> false  

let appl_with_argument ts func arg =
  Hashtbl.find (Hashtbl.find ts.appl_with_arg func) arg
  
let appl_with_function ts arg func =
  Hashtbl.find (Hashtbl.find ts.appl_with_func arg) func
  
let abstr_with_type ts body typ =
  Hashtbl.find ts.abstr_with (body,typ)
  
let appl_exists ts func arg =
  try (
    Hashtbl.mem (Hashtbl.find ts.appl_with_arg func) arg
  ) with _ -> false
  
let abstr_exists ts body typ =
  Hashtbl.mem ts.abstr_with (body,typ)


(* ------------------------------------------------------------------------- *)
(* val insert : termset -> term -> nodestruct -> id                          *)
(*                                                                           *)
(* [insert ts term nodestruct] assumes [nodestruct] corresponds to [term],   *)
(* determines a fresh [id] for [nodestruct], inserts [nodestruct] into [ts]  *)
(* and updates all hashtables.                                               *)
(* ------------------------------------------------------------------------- *)
let insert ts term nodestruct =
  let id = da_size ts.nodes in
  let _ = da_insert ts.nodes { name = id; structure = nodestruct } in
  let _ = Hashtbl.add ts.term2id term id in
  let _ = match term,nodestruct with
      (Appl _, Appl_node (id1,id2)) ->
        let appl_with_arg_id1 = ref (Hashtbl.create 10) in
        let _ =
          if Hashtbl.mem ts.appl_with_arg id1 then
            appl_with_arg_id1 := Hashtbl.find ts.appl_with_arg id1 in
        Hashtbl.add !appl_with_arg_id1 id2 id;
        Hashtbl.replace ts.appl_with_arg id1 !appl_with_arg_id1;
        let appl_with_func_id2 = ref (Hashtbl.create 10) in
        let _ =
          if Hashtbl.mem ts.appl_with_func id2 then
            appl_with_func_id2 := Hashtbl.find ts.appl_with_func id2 in
        Hashtbl.add !appl_with_func_id2 id1 id;
        Hashtbl.replace ts.appl_with_func id2 !appl_with_func_id2
    | (Abstr _, Abstr_node (typ,id1)) ->
        Hashtbl.add ts.abstr_with (id1,typ) id
    | _ -> () in
  id


(* ---------------------------------------------------------------------------------------------- *)
(* val create' : termset -> term -> int -> (string*(int*hol_type)) list -> (string*id) list -> id *)
(*                                                                                                *)
(* [create' ts t d bound applied] expects                                                         *)
(*   [ts] a termset                                                                               *)
(*   [t] a term                                                                                   *)
(*   [d] the current scope                                                                        *)
(*   [bound] a list mapping symbols to pairs of deBruijn-indices and types                        *)
(*   [applied] a list mapping symbols to IDs for beta-reduction                                   *)
(* ---------------------------------------------------------------------------------------------- *)
let rec create' ts t d bound applied =
  match t with
    Symbol s ->
            if mem_assoc s applied then
              assoc s applied
            else if mem_assoc s bound then
              let idx_s, typ_s = assoc s bound in
              insert ts t (Bound_node (typ_s,d - idx_s))
            else if Hashtbl.mem ts.term2id t then
              Hashtbl.find ts.term2id t
            else
              insert ts t (Symbol_node s)
  | Appl(Abstr(x,typx,t1),t2) ->
            let id2 = create' ts t2 d bound applied in
            let id1 = create' ts t1 (d+1) bound ((get_symbol x,id2)::applied) in
            id1
  | Appl (t1,t2) ->
            let id1, id2 = create' ts t1 d bound applied, create' ts t2 d bound applied in
            if appl_exists ts id1 id2 then
              appl_with_argument ts id1 id2
            else
              insert ts t (Appl_node (id1,id2))
  | Abstr (x,typx,t1) ->
            assert(is_symbol x);
            let id1 = create' ts t1 (d+1) ((get_symbol x,(d+1,typx))::bound) applied in
            if abstr_exists ts id1 typx then
              abstr_with_type ts id1 typx
            else
              insert ts t (Abstr_node (typx,id1))

let create ts t = create' ts t (-1) [] []



let rec retrieve' ts id d bound =
  assert(id>=0 &&  id<da_size ts.nodes);
  match (da_get ts.nodes id).structure with
    Symbol_node s -> Symbol s
  | Appl_node (id1,id2) -> Appl(retrieve' ts id1 d bound, retrieve' ts id2 d bound)
  | Abstr_node (typ,id) ->
          let var_name = "x" ^ (string_of_int (d+1)) in
          Abstr(Symbol var_name, typ, retrieve' ts id (d+1) ((d+1,var_name)::bound))
  | Bound_node (typ,idx) ->
          assert(mem_assoc idx bound);
          Symbol(assoc idx bound)

let retrieve ts id = retrieve' ts id (-1) []



(* ------------------------------------------------------------------------- *)
(* Some tests                                                                *)
(* ------------------------------------------------------------------------- *)

(*
let ts = {
  nodes = da_make 10 {name=0; structure=Symbol_node ""};
  term2id = Hashtbl.create 10;
  appl_with_arg = Hashtbl.create 10;
  appl_with_func = Hashtbl.create 10;
  abstr_with = Hashtbl.create 10;
}

(* test beta-reduction *)
let ta = Appl(Abstr(Symbol "x","X",Appl(Symbol "f",Symbol "x")),Symbol "c")
let tb = Appl(Abstr(Symbol "x","X",Symbol "x"),Symbol "c")
let tc = Appl(Abstr(Symbol "x","X",Appl(Symbol "x",Symbol "x")),  Abstr(Symbol "x","X",Appl(Symbol "x",Symbol "x")))

let t0 = Abstr(Symbol "x","X",Appl(Symbol "f",Symbol "x"))
let t1 = Appl(Symbol "f",Appl(Appl(Symbol "+", Symbol "a"),Symbol "b"))
let t2 = Appl(Symbol "f", Appl(Appl(Symbol "+", Appl(Appl(Symbol "+", Symbol "a"),Symbol "b")), Symbol "c"))

# create ts t0;;
- : id = 3
# create ts t1;;
- : id = 9
# create ts t2;;
- : id = 13
# da2array ts.nodes;;
- : termnode array =
[|{name = 0; structure = Bound_node ("X", 0)};
  {name = 1; structure = Symbol_node "f"};
  {name = 2; structure = Appl_node (1, 0)};
  {name = 3; structure = Abstr_node ("X", 2)};
  {name = 4; structure = Symbol_node "b"};
  {name = 5; structure = Symbol_node "a"};
  {name = 6; structure = Symbol_node "+"};
  {name = 7; structure = Appl_node (6, 5)};
  {name = 8; structure = Appl_node (7, 4)};
  {name = 9; structure = Appl_node (1, 8)};
  {name = 10; structure = Symbol_node "c"};
  {name = 11; structure = Appl_node (6, 8)};
  {name = 12; structure = Appl_node (11, 10)};
  {name = 13; structure = Appl_node (1, 12)}|]


*)