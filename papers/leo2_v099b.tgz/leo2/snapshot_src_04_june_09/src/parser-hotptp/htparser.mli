type token =
  | AMPERSAND
  | AT_SIGN
  | CARET
  | CNF
  | COLON
  | COMMA
  | EQUALS
  | EXCLAMATION
  | FOF
  | GETS
  | GREATER
  | HOF
  | IF
  | IFF
  | IMPLIES
  | INCLUDE
  | INPUT_CLAUSE
  | INPUT_FORMULA
  | LAMBDA
  | LBRKT
  | LPAREN
  | MAP_TO
  | MMINUS
  | NAMPERSAND
  | NEQUALS
  | NIFF
  | NVLINE
  | PERIOD
  | PPLUS
  | QUESTION
  | RBRKT
  | RPAREN
  | TILDE
  | TOK_FALSE
  | TOK_I
  | TOK_O
  | TOK_INT
  | TOK_REAL
  | TOK_TRUE
  | TOK_TYPE
  | VLINE
  | EOF
  | Unsigned_integer of (string)
  | Signed_integer of (string)
  | Decimal_part of (string)
  | Real of (string)
  | Atomic_system_word of (string)
  | Distinct_object of (string)
  | Single_quoted of (string)
  | Upper_word of (string)
  | Sq_upper_word of (string)
  | Lower_word of (string)
  | Unrecognized

val input :
  (Lexing.lexbuf  -> token) -> Lexing.lexbuf -> Term.term list * Signature.signature * (string , string * Term.term) Hashtbl.t
