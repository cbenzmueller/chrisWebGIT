(* Utilities *)

(* All the counters *)
let currentline = ref 0
let typedefs = ref 0
let axioms = ref 0

(* Stack *)
let stack = ref []

let stack_push x =
  stack := x::(!stack)

let rec stack_pop n =
  match !stack,n with
    _,0 -> []
  | (x::r), _ -> (stack := r; x::(stack_pop (n - 1)))
  | _ -> failwith ("Error: Stack is empty while processing line "^(string_of_int !currentline)) 

(* All the management *)
let arities = Hashtbl.create 10
let complextypes = Hashtbl.create 10 

(* Builtin symbols *)
let thf_symbols = [
  ("int","$int");
  ("bool","$o");
  ("any","A")
]

let mk_symbol_map symbollist =
  let smap = Hashtbl.create (List.length symbollist) in
  List.iter (fun (a,b) -> Hashtbl.add smap a b) symbollist;
  smap

let known_symbols = mk_symbol_map thf_symbols 


(* Remove special chars from symbol names *)
let clean_name s =
  if Hashtbl.mem known_symbols s
  then Hashtbl.find known_symbols s
  else if Hashtbl.mem complextypes s
  then Hashtbl.find complextypes s
  else (
  let char_map c =
    let cc = Char.code c in
    if (cc >= (Char.code 'A') && cc <= (Char.code 'Z')) ||
       (cc >= (Char.code 'a') && cc <= (Char.code 'z')) ||
       (cc >= (Char.code '0') && cc <= (Char.code '9'))
    then String.make 1 c
    else
      match c with
        '.' -> "_"
      | '_' -> "_"
      | '$' -> "s_"
      | '@' -> "_at_"
      | '#' -> "_x_"
      | _ -> ("_"^(string_of_int (Char.code c))^"_")
  in
  let accu = ref "" in 
  for i = 0 to (String.length s) -1 do
    accu := !accu^(char_map s.[i])
  done;
  "l"^(!accu))

(* Tokenize a string, separators: space, tab, ret *) 
let tokenize s = 
  let accu = ref [] in
  let token = ref "" in
  for i = 0 to (String.length s) -1 do
    if (s.[i] = ' ' || s.[i] = '\t' || s.[i]='\n' || (Char.code s.[i])=13) 
    then (if !token <> ""
          then (accu := (!token::(!accu)); token := ""))
    else token := (!token)^(String.make 1 s.[i])
  done;
  if !token <> "" then accu := !token::!accu;
  List.rev !accu




(* Read a file section-wise *)
let read_section f_in do_line =
  let read_more = ref true in
  while !read_more do
    let nextline = try tokenize (input_line f_in)
                   with End_of_file -> (read_more := false;["#"])
    in
    currentline := !currentline + 1;
    if nextline = ["#"]
    then read_more := false
    else do_line nextline
  done


(* Read base type definition *)
let do_basetypedef l = 
  match l with
    ["type"; t] -> (typedefs := !typedefs + 1;
                    print_string ("thf(typedef"^(string_of_int !typedefs)^
                    ",constant,("^(clean_name t)^" : $type)).\n"))
  | [] -> ()
  | _ -> failwith ("Basetype definition: Error in line "^(string_of_int !currentline))

(* Read array and bitvector types *)
let do_complextypedef l =
  match l with
    ["array1";t1;t2;abbr] -> (let abbr2 = clean_name abbr in
                              Hashtbl.add complextypes abbr2 ("("^(clean_name t1)^" > "^(clean_name t2)^")");
                              print_string ("% Array1: "^abbr2^" := ("^(clean_name t1)^" > "^(clean_name t2)^")\n"))
  | [] -> ()
  | _ -> failwith ("Complextype definition: Error in line "^(string_of_int !currentline))

(* Read function types *)
let do_funtypedef l = 
  match l with
    "fun"::(f::ty::args) -> (typedefs := !typedefs + 1;
                    let get_type t = 
                      let t_c = clean_name t in
                      if Hashtbl.mem complextypes t_c
                      then Hashtbl.find complextypes t_c
                      else t_c
                    in
                    let f_clean = clean_name f in
                    let ty_clean = get_type ty in
                    let args2 = List.map (fun a -> (get_type a)) args in
                    Hashtbl.add arities f_clean (List.length args);
                    (* print_string ("% arity of "^f_clean^": "^(string_of_int ((List.length args) -1))^"\n"); *)
                    print_string ("thf(typedef"^(string_of_int !typedefs)^
                    ",constant,("^(f_clean)^" : "^
                    (String.concat " > " (List.append args2 [ty_clean]))^
                    ")).\n"))
  | "attribute"::_ -> ()
  | [] -> ()
  | _ -> failwith ("Funtype definition: Error in line "^(string_of_int !currentline)^":\n"^(String.concat " " l))

(* Read axioms *)
let patterns = ref []

let freevars = ref []

let freevartbl = Hashtbl.create 10

let do_term l =
  let decrease_debruijn v s =
    (* print_string ("decrease debruijn: "^s^"\n"); *)
    let num = ref "" in
    let accu = ref "" in
    let read_num = ref false in
    for i = 0 to (String.length s) -1 do
      if s.[i] = '%'
      then
        if !read_num
        then (accu := (!accu)^(if !num = "0"
                               then v
                               else "%"^(string_of_int ((int_of_string !num) -1))^"%");
              num := ""; read_num := false) 
        else read_num := true
      else
        if !read_num
        then num := (!num)^(String.make 1 s.[i])
        else accu := (!accu)^(String.make 1 s.[i])
    done;
    !accu
  in
  match l with
    ["var";n] -> stack_push ("%"^n^"%")
  | ["fun";f] -> (try
                  let f_clean = clean_name f in
                  let n = Hashtbl.find arities f_clean in
                  let args = stack_pop n in
                  let term = if n > 0
                             then "("^(String.concat " @ " (f_clean::args))^")"
                             else (String.concat " @ " (f_clean::args)) in
                  stack_push term
                  with _ -> failwith ("Term reader: Could not resolve function "^(clean_name f)^"in line "^(string_of_int !currentline)))
  | ["forall";v;t] -> let range = List.hd (stack_pop 1) in
                      let var = "V"^(clean_name v) in
                      let ty = clean_name t in
                      let range2 = decrease_debruijn var range in
                      patterns := List.map (decrease_debruijn var) (!patterns);
                      stack_push ("(!["^var^": "^ty^"]: "^range2^")")
  | ["exists";v;t] -> let range = List.hd (stack_pop 1) in
                      let var = "V"^(clean_name v) in
                      let ty = clean_name t in
                      let range2 = decrease_debruijn var range in
                      patterns := List.map (decrease_debruijn var) (!patterns);
                      stack_push ("(?["^var^": "^ty^"]: "^range2^")")
(* builtin operators *)
  | "="::_ -> let args = stack_pop 2 in
              stack_push ("("^(List.nth args 0)^" = "^(List.nth args 1)^")")
  | "and"::_ -> let args = stack_pop 2 in
              stack_push ("("^(List.nth args 0)^" & "^(List.nth args 1)^")")
  | "or"::_ -> let args = stack_pop 2 in
              stack_push ("("^(List.nth args 0)^" | "^(List.nth args 1)^")")
  | "implies"::_ -> let args = stack_pop 2 in
              stack_push ("("^(List.nth args 0)^" => "^(List.nth args 1)^")")
  | "iff"::_ -> let args = stack_pop 2 in
              stack_push ("("^(List.nth args 0)^" <=> "^(List.nth args 1)^")")
  | "not"::_ -> let arg = List.hd (stack_pop 1) in
              stack_push ("(~ ("^arg^"))")
  | "<"::_ -> let args = stack_pop 2 in
              stack_push ("("^(String.concat " @ " ("$less_int"::args))^")")
  | ">"::_ -> let args = stack_pop 2 in
              stack_push ("("^(String.concat " @ " ("$greater_int"::args))^")")
  | "<="::_ -> let args = stack_pop 2 in
              stack_push ("("^(String.concat " @ " ("$lesseq_int"::args))^")")
  | "=>"::_ -> let args = stack_pop 2 in
              stack_push ("("^(String.concat " @ " ("$greatereq_int"::args))^")")
  | "%"::_ -> let args = stack_pop 2 in
              stack_push ("("^(String.concat " @ " ("$remainder_int"::args))^")")
  | "+"::_ -> let args = stack_pop 2 in
              stack_push ("("^(String.concat " @ " ("$plus_int"::args))^")")
  | "-"::_ -> let args = stack_pop 2 in
              stack_push ("("^(String.concat " @ " ("$minus_int"::args))^")")
  | "*"::_ -> let args = stack_pop 2 in
              stack_push ("("^(String.concat " @ " ("$times_int"::args))^")")
  | "/"::_ -> let args = stack_pop 2 in
              stack_push ("("^(String.concat " @ " ("$divide_int"::args))^")")
  | "true"::_ -> stack_push "$true"
  | "false"::_ -> stack_push "$false"

(* real and int *)
  | ["num";n] -> stack_push n
(* toplevel *)
  | ["axiom"] -> (axioms := !axioms + 1;
                  print_string ("% Patterns:\n%"^(String.concat "\n%" (!patterns))^"\n");
                  patterns := [];

                  (if List.length !stack <> 1
                  then (print_string ("% Error while reading term:\n% Stack:\n%"^(String.concat "\n%\n%" (List.tl !stack))^"\n") (*;
                        failwith "Stacksize not one at axiom token." *)
                  ));
                  print_string ("thf(axiom"^(string_of_int !axioms)^
                  ",axiom,"^(List.hd (stack_pop 1))^").\n");
                  stack := [])
  | ["vc";name] -> ((if List.length !stack <> 1
                     then (print_string ("% Error while reading term:\n% Stack:\n%"^(String.concat "\n%\n%" (List.tl !stack))^"\n") (*;
                        failwith "Stacksize not one at axiom token." *)
                    ));
                    let vars = String.concat ", "
                                 (List.map (fun (v,t) -> v^": "^t) (List.rev !freevars))
                    in
                    freevars := [];
                    Hashtbl.clear freevartbl;
                    print_string ("thf(vc_"^name^
                    ",conjecture, !["^vars^"]:"^(List.hd (stack_pop 1))^").\n");
                    stack := [])
(* misc *)
(* fixme: Store and Select need type declarations in THF *)
  | ["select1";t1;t2] -> let ty1 = clean_name t1 in
                         let ty2 = clean_name t2 in
                         let select_typed = "select1_"^ty1^"_"^ty2 in
                         typedefs := !typedefs + 1;
                         print_string ("thf(typedef"^(string_of_int !typedefs)^",constant,("^select_typed^
                                       " : ("^ty1^" > "^ty2^") > "^ty1^" > "^ty2^")).\n");
                         stack_push ("("^(String.concat " @ " (select_typed::(stack_pop 2)))^")")
  | ["store1";t1;t2] ->  let ty1 = clean_name t1 in
                         let ty2 = clean_name t2 in
                         let store_typed = "store1_"^ty1^"_"^ty2 in
                         typedefs := !typedefs + 1;
                         print_string ("thf(typedef"^(string_of_int !typedefs)^",constant,("^store_typed^
                                       " : ("^ty1^" > "^ty2^") > "^ty1^" > "^ty2^" > ("^ty1^" > "^ty2^"))).\n");
                         stack_push ("("^(String.concat " @ " (store_typed::(stack_pop 3)))^")")



(* fixme:
  | ["store1";t1;t2] -> stack_push ("("^(String.concat " @ " (("store1_"^(clean_name t1)^"_"^(clean_name t2))::(stack_pop 3)))^")")
  | ["select2";t1;t2;t3] -> stack_push ("("^(String.concat " @ "
                                             (("select2_"^(clean_name t1)^"_"^(clean_name t2)^"_"^(clean_name t3))::(stack_pop 3)))^")")
  | ["store2";t1;t2;t3] -> stack_push ("("^(String.concat " @ "
                                            (("store2_"^(clean_name t1)^"_"^(clean_name t2)^"_"^(clean_name t3))::(stack_pop 4)))^")")
*)
  | ["free";v;t] -> (let var = "V"^(clean_name v) in
                     let ty = (clean_name t) in
                     (if not (Hashtbl.mem freevartbl var)
                      then (Hashtbl.add freevartbl var true;
                            freevars := (var,ty)::(!freevars)));
                     stack_push var)
  | ["label";pol;lbl] -> (let formula = List.hd (stack_pop 1) in
                          let label = "label_"^lbl in
                          typedefs := !typedefs + 1;
                          print_string ("thf(typedef"^(string_of_int !typedefs)^",constant,("^label^" : $o)).\n");
                          stack_push
                          (if pol = "pos"
                           then "((~ ("^label^")) & "^formula^")"
                           else "("^label^" | "^formula^")"))
  | "attribute"::_ -> ()
  | "pat"::_ -> patterns := (List.hd (stack_pop 1))::(!patterns)
  | "andpat"::_ -> patterns := (List.hd (stack_pop 1))::(!patterns)
  | "trigger"::_ -> print_string ("%"^(String.concat " " l)^"\n")
  | [] -> ()
  | _ -> failwith ("Term reader: Error in line "^(string_of_int !currentline)^":\n"^(String.concat " " l))

let showline l =
  let s = String.concat ";" l
  in
  "["^s^"]\n"

let read_file f_in =
  print_string "include('builtin.ax').\n\n"; 
  print_string "% Base Types:\n";
  read_section f_in do_basetypedef;
  print_string "% Composite Types:\n";
  read_section f_in do_complextypedef;
  print_string "% Function and Constant Types:\n";
  read_section f_in do_funtypedef; 
  print_string "% Axioms:\n";
  read_section f_in do_term;
  print_string "% Verification Condition:\n";
  read_section f_in do_term;
  print_string ("% Last line read: "^(string_of_int (!currentline))^"\n");
  print_string ("% Stack:\n%"^(if !stack = [] then " empty" else (String.concat "\n%\n%" !stack))^"\n")
(*  read_section f_in (fun l -> print_string (showline l)) *)





let _ = read_file (try open_in Sys.argv.(1) with _ -> stdin)
(* read_file "/home/tenzing/project/Verisoft/HOL-Boogie/examples/vcc2/max_correct.b2i" *)
