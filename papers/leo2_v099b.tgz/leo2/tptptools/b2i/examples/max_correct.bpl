const unique ^_vcc_memory_allocator: $ctype;

axiom $is_composite(^_vcc_memory_allocator);

axiom $ptr_level(^_vcc_memory_allocator) == 0;

procedure maximum(arr: int, len: int) returns ($result: int);
  requires $wrapped($s, $as_array($ptr(^^u1, arr), ^^u1, len), $array(^^u1, len));
  requires 0 < len && len < 1099511627776;
  modifies $s;
  ensures (exists Q#i$1^10.14: int :: $in_range_u4(Q#i$1^10.14) && Q#i$1^10.14 < len && $read_u1($s, $idx($ptr(^^u1, arr), Q#i$1^10.14, ^^u1)) == $result);
  ensures (forall Q#i$1^9.14: int :: $in_range_u4(Q#i$1^9.14) ==> Q#i$1^9.14 < len ==> $read_u1($s, $idx($ptr(^^u1, arr), Q#i$1^9.14, ^^u1)) <= $result);
  free ensures $in_range_u1($result);
  free ensures $writes_nothing(old($s), $s);
  free ensures $call_transition(old($s), $s);



implementation maximum(arr: int, len: int) returns ($result: int)
{
  var loopState#0: $state, witness: int where $in_range_u4(witness), p: int where $in_range_u4(p), max: int where $in_range_u1(max), #wrTime$1^6.1: int;

  anon6:
    assume $function_entry($s);
    assume $full_stop_ext(#tok$1^6.1, $s);
    assume $can_use_all_frame_axioms($s);
    assume $local_value_is($s, #tok$1^6.1, #loc.arr, $ptr(^^u1, arr));
    assume $local_value_is($s, #tok$1^6.1, #loc.len, len);
    assume #wrTime$1^6.1 == $current_timestamp($s);
    assume (forall #p: $ptr :: { $in_writes_at(#wrTime$1^6.1, #p) } $in_writes_at(#wrTime$1^6.1, #p) == false);
    // assume @in_range_u4(len); 
    assume $in_range_u4(len);
    // assert old(@_vcc_skip_wf(), @_vcc_in_domain(@_vcc_as_array(arr, ( UInt64)len), @_vcc_as_array(arr, ( UInt64)len))); 
    assert $in_domain($s, $as_array($ptr(^^u1, arr), ^^u1, len), $as_array($ptr(^^u1, arr), ^^u1, len));
    // UInt8 max; 
    // UInt32 p; 
    // UInt32 witness; 
    // var UInt8 max
    // assert @_vcc_typed2(arr[0]); 
    assert $typed2($s, $idx($ptr(^^u1, arr), 0, ^^u1), ^^u1);
    // assert @_vcc_thread_local2(arr[0]); 
    assert $thread_local2($s, $idx($ptr(^^u1, arr), 0, ^^u1), ^^u1);
    // max = *(arr[0]); 
    max := $read_u1($s, $idx($ptr(^^u1, arr), 0, ^^u1));
    assume $local_value_is($s, #tok$1^12.3, #loc.max, max);
    // var UInt32 p
    // var UInt32 witness
    // witness = 0; 
    witness := 0;
    assume $local_value_is($s, #tok$1^15.3, #loc.witness, witness);
    // p = 1; 
    p := 1;
    assume $local_value_is($s, #tok$1^18.8, #loc.p, p);
    loopState#0 := $s;
    while (true)
      invariant witness < len && $read_u1($s, $idx($ptr(^^u1, arr), witness, ^^u1)) == max;
      invariant (forall Q#i$1^20.17: int :: $in_range_u4(Q#i$1^20.17) ==> Q#i$1^20.17 < p ==> $read_u1($s, $idx($ptr(^^u1, arr), Q#i$1^20.17, ^^u1)) <= max);
      invariant p <= len;
    {
      anon5:
        assume $writes_nothing(old($s), $s);
        assume $timestamp_post(loopState#0, $s);
        assume $full_stop_ext(#tok$1^18.3, $s);
        assume $local_value_is($s, #tok$1^18.3, #loc.p, p);
        assume $local_value_is($s, #tok$1^18.3, #loc.witness, witness);
        assume $local_value_is($s, #tok$1^18.3, #loc.max, max);
        assume $local_value_is($s, #tok$1^18.3, #loc.len, len);
        assume $local_value_is($s, #tok$1^18.3, #loc.arr, $ptr(^^u1, arr));
        // assume @_vcc_meta_eq(); 
        assume $meta_eq(loopState#0, $s);
        // if (<(p, len)) ...
        if (p < len)
        {
          anon3:
            // assert @_vcc_typed2(arr[p]); 
            assert $typed2($s, $idx($ptr(^^u1, arr), p, ^^u1), ^^u1);
            // assert @_vcc_thread_local2(arr[p]); 
            assert $thread_local2($s, $idx($ptr(^^u1, arr), p, ^^u1), ^^u1);
            // if (>(*(arr[p]), max)) ...
            if ($read_u1($s, $idx($ptr(^^u1, arr), p, ^^u1)) > max)
            {
              anon1:
                // assert @_vcc_typed2(arr[p]); 
                assert $typed2($s, $idx($ptr(^^u1, arr), p, ^^u1), ^^u1);
                // assert @_vcc_thread_local2(arr[p]); 
                assert $thread_local2($s, $idx($ptr(^^u1, arr), p, ^^u1), ^^u1);
                // max = *(arr[p]); 
                max := $read_u1($s, $idx($ptr(^^u1, arr), p, ^^u1));
                assume $local_value_is($s, #tok$1^25.7, #loc.max, max);
                // witness = p; 
                witness := p;
                assume $local_value_is($s, #tok$1^27.7, #loc.witness, witness);
            }
            else
            {
              anon2:
                // empty
            }
        }
        else
        {
          anon4:
            // goto #break_1; 
            goto #break_1;
        }

      #continue_1:
        // assert @in_range_u4(+(p, 1)); 
        assert $in_range_u4(p + 1);
        // p = +(p, 1); 
        p := p + 1;
        assume $local_value_is($s, #tok$1^18.24, #loc.p, p);
    }

  anon7:
    assume $full_stop_ext(#tok$1^18.3, $s);

  #break_1:
    // return max; 
    $result := max;
    assert $position_marker();
    goto #exit;

  anon8:
    // empty

  #exit:
}



const unique #tok$1^18.24: $token;

const unique #tok$1^27.7: $token;

const unique #tok$1^25.7: $token;

const unique #tok$1^18.3: $token;

const unique #loc.p: $token;

const unique #tok$1^18.8: $token;

const unique #loc.witness: $token;

const unique #tok$1^15.3: $token;

const unique #loc.max: $token;

const unique #tok$1^12.3: $token;

const unique #loc.len: $token;

const unique #loc.arr: $token;

const unique #tok$1^6.1: $token;

const unique #file^Z?3A?5CC?5Cmax_correct.c: $token;

axiom $file_name_is(1, #file^Z?3A?5CC?5Cmax_correct.c);
