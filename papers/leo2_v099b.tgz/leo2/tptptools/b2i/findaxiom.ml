let infile = open_in Sys.argv.(1)
let limit = int_of_string Sys.argv.(2)

let tokenize s = 
  let accu = ref [] in
  let token = ref "" in
  for i = 0 to (String.length s) -1 do
    if (s.[i] = ' ' || s.[i] = '\t' || s.[i]='\n' || (Char.code s.[i])=13) 
    then (if !token <> ""
          then (accu := (!token::(!accu)); token := ""))
    else token := (!token)^(String.make 1 s.[i])
  done;
  if !token <> "" then accu := !token::!accu;
  List.rev !accu

let skipsection () =
  let nextline = ref [] in
  while !nextline <> ["#"] do
    nextline := try tokenize (input_line infile)
                with End_of_file -> ["#"]
  done

let passthrusection () =
  let nextline = ref [] in
  while !nextline <> ["#"] do
    (nextline := try tokenize (input_line infile)
                with End_of_file -> ["#"]);
    print_string ((String.concat " " !nextline)^"\n")
  done


let _ =
  if (try Sys.argv.(3) = "solo" with _ -> false)
  then (
    skipsection ();
    skipsection ();
    skipsection ()
  ) else (
    passthrusection ();
    passthrusection ();
    passthrusection ()
  )

let readmore = ref true

let _ =
  (* let shortest = ref 10000 in *)
  let axiom = ref "" in
  let accu = ref "" in
  let current = ref 0 in
  let axiom_count = ref 0 in
  while !readmore do
    let nextline = try tokenize (input_line infile)
                   with End_of_file -> (readmore := false;["#"])
    in
    match nextline with
      ["axiom"] -> ( axiom_count := !axiom_count + 1;
                     (* (if (!current) < (!shortest) && (!current) > limit then axiom := !accu); *)
                     (if !axiom_count = limit then axiom := !accu);
                     accu := ""; current := 0)
    | _ -> (accu := (!accu)^(String.concat " " nextline)^"\n"; current := !current + 1)
  done;
  print_string (!axiom^"axiom\n")
