#!/bin/sh
rm file_list
touch file_list
ls ~/install/TPTP-v3.6.0/Problems/*/*.p >> file_list
ls ~/install/TPTP-v3.6.0/Axioms/*.ax >> file_list
ls ~/install/TPTP-v3.6.0/Axioms/SET007/*.ax >> file_list

echo 'rm test_all; touch test_all' > read_list
sed -e 's/^\(.*\)$/read.native < \1 >> test_all/' file_list >> read_list
source read_list