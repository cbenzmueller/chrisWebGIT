#!/bin/sh
cp *.ml ../../syntakker/src
cp *.mli ../../syntakker/src
cp *.mll ../../syntakker/src
cp *.mly ../../syntakker/src
