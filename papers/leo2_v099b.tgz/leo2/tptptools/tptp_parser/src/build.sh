#!/bin/sh
ocamlbuild read.native
cp -L read.native ../bin/read
ocamlbuild expand.native
cp -L expand.native ../bin/expand
cp direxpand ../bin/direxpand