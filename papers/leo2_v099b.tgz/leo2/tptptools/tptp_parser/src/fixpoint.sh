#!/bin/sh
cat $1/*$2 | read.native | tee test1 | read.native >test2; diff test1 test2