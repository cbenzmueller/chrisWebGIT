#!/bin/sh

for file in `ls $1`
do
echo "File: $file"
sed -e 's/;.*$//' $1/$file | SyntaxBNF-yl-parser-verbose
done