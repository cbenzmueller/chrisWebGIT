#!/bin/csh -f

if ($#argv != 1) then
	echo Usage: $0 hotptp-bnf.txt '   ... or' syntaxBNF-3.1.1.13.txt
	exit $#argv
	endif

setenv LANG C
set inr = $1:r
set inrr = `basename $inr | sed 's/-[^-]*$//' `
set scriptdir = `dirname $0`
set builddir = $scriptdir/../build

$scriptdir/tptp-txt-clean.csh $1 > $builddir/$inrr-clean.txt
$scriptdir/tptp-trans.csh $builddir/$inrr-clean.txt > $builddir/$inrr-1.txt
$scriptdir/tptp-lex.csh $builddir/$inrr-1.txt
$scriptdir/tptp-y0.csh $builddir/$inrr-1.txt $builddir/$inrr-1.lex0
$scriptdir/tptp-y.csh $builddir/$inrr-1.y0
mv $builddir/$inrr-1.y $builddir/$inrr-1.y1
$scriptdir/tptp-y1.awksh $builddir/$inrr-1.y1 > $builddir/$inrr-1.y

