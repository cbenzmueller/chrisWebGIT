#!/bin/csh -f

# Goal for this script is to extract lines that belong in the parser.

# We need echo to collapse \\ to \.  Sadly, this is not standard.
set thisOS = `uname -s`
set ECHO = echo
if ($thisOS == Linux) set ECHO = (/bin/echo -e)
if ($thisOS == SunOs) set ECHO = (/bin/echo)

if ($#argv != 2) then
	echo Usage: $0 tptp-1.txt tptp-1.lex0 '   creates tptp-1.y0'
	exit $#argv
	endif

setenv LANG C
set inr = $1:r
set outy = $inr.y0
set includedir = `dirname $outy`/../include

cat $includedir/header.y > $outy


# Find the start symbol
cat $1 | \
awk '$2 == "_GRR" {print "%start ", $1;exit;}' | \
cat >> $outy

# Find the tokens in the lex file.
cat $2 | \
egrep 'return *\(' | \
sed -e 's/^.*return *( *\([^ )]*\) *);.*$/%token <ival> \1/' | \
sort -u | \
cat >> $outy



$ECHO '%%' >> $outy
$ECHO '' >> $outy
# Rules for yacc next; all tokens should appear in yacc file (maybe future)


cat $1 | \
awk '$2 == "_GRR"' | \
sed -e '/^[A-Za-z][A-Za-z0-9_]*file/s/\([A-Za-z0-9_]*\)\( *_GRR *\)\([A-Za-z0-9_]*\) *[+]/\1\2\3 | \1 \3/' | \
sed -e '/^[A-Za-z][A-Za-z0-9_]*file/s/\([A-Za-z0-9_]*\)\( *_GRR *\)\([A-Za-z0-9_]*\) *[*]/\1\2null | \1 \3/' | \
sed -e 's/\([A-Za-z0-9_]*\)\( *_GRR *\)\([A-Za-z0-9_]*\) *[+]/\1\2\3 | \3 \1/' | \
cat >> $outy
