(** Module Config
    @author Frank Theiss
    @since 12-11-08 *)

let binaries = Hashtbl.create 10

let get_binary exe = Hashtbl.find binaries exe

let set_binary exe path = Hashtbl.add binaries exe path

let bins = [("tptp_parser","/home/tenzing/import/leo/tptptools/SyntaxBNF/bin/SyntaxBNF-yl-parser-verbose");
            ("sed","sed")]

let _ = List.iter (fun (a,b) -> set_binary a b) bins
