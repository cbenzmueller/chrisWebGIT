(** Module Termcloud
    @author Frank Theiss
    @since 01-28-08 *)

let initsize = ref 1000000

exception Termcloud_exception of string

(** Sets of Integers *)
module IdSet =
  Set.Make
    (struct
      type t = int
      let compare x y = x - y
    end)

(** Terms *)
type term = 
    Appl of int * int * ((int * int) list)
  | Abstr of int * int
  | Symbol of string


(** Termcloud *)
type termcloud = {
  nodecount    : int ref;
  applications : (int * int * ((int * int) list), int) Hashtbl.t;
(** A unique application term is defined by its function term, its argument term, and the
    list of variable connections between them *) 

  abstractions : (int * int, int) Hashtbl.t;
(** A unique abstraction is defined by its body and the abstracted variable *)

  symbols      : (string, int) Hashtbl.t;
(** A unique symbol is defined by its string name *)

  varrange     : (int, int) Hashtbl.t;
(** The number of distinct variables occurring in a term *)

  terms        : (int, term) Hashtbl.t;

  app_with_fun : (int, IdSet.t) Hashtbl.t;
  app_with_arg : (int, IdSet.t) Hashtbl.t;
  abs_with_bdy : (int, IdSet.t) Hashtbl.t;
  }

(** Create a new termcloud *)
let new_termcloud () = {
  nodecount    = ref 1;
  applications = Hashtbl.create !initsize;
  abstractions = Hashtbl.create !initsize;
  symbols      = Hashtbl.create !initsize;

  varrange     = Hashtbl.create !initsize;
  terms        = Hashtbl.create !initsize;

  app_with_fun = Hashtbl.create !initsize;
  app_with_arg = Hashtbl.create !initsize;
  abs_with_bdy = Hashtbl.create !initsize;
}

let this_termcloud = ref (new_termcloud ())

(** Set the current termcloud *)
let set_termcloud tc = this_termcloud := tc

(** Get the current termcloud *)
let get_termcloud () = !(this_termcloud)

(** Create a new node in a termcloud *)
let new_node () =
  let tc = get_termcloud () in
  tc.nodecount := !(tc.nodecount) + 1;
  !(tc.nodecount)

(** Find a node *)
let get_node n =
  let tc = get_termcloud () in
  Hashtbl.find tc.terms n

(** Creating terms *)

(** Create a new application *)
let appl func arg varlist = 
  let tc = get_termcloud () in
  if Hashtbl.mem tc.applications (func, arg, varlist)
  then Hashtbl.find tc.applications (func, arg, varlist)
  else (
    let node = new_node () in
    Hashtbl.add tc.applications (func, arg, varlist) node;
    Hashtbl.add tc.terms node (Appl (func, arg, varlist));
    node
  ) 

(** Create a new abstraction *)
let abstr body var = 
  let tc = get_termcloud () in
  if Hashtbl.mem tc.abstractions (body,var)
  then Hashtbl.find tc.abstractions (body,var)
  else (
    let node = new_node () in
    Hashtbl.add tc.abstractions (body,var) node;
    Hashtbl.add tc.terms node (Abstr (body,var));
    node
  ) 

(** Create a new symbol *)
let symbol name = 
  let tc = get_termcloud () in
  if Hashtbl.mem tc.symbols name
  then Hashtbl.find tc.symbols name
  else (
    let node = new_node () in
    Hashtbl.add tc.symbols name node;
    Hashtbl.add tc.terms node (Symbol name);
    node
  ) 


(** Propagation *)

let rec first_n l n =
  (* print_string ("first_n: "^(String.concat "," l)^"\nwith n: "^(string_of_int n)^"\n"); *)
  if n <= 0 then ([],l)
  else
    match l with
      x::r -> let (l2,r2) = first_n r (n - 1) in
              (x::l2, r2)
    | _ -> failwith "first_n: list too short."

(** Propagate a variable context upwards *)
let propagate_appl_up node func arg =
(*print_string "propagate up:\n";
  print_string ((String.concat "," func)^" (func)\n");
  print_string ((String.concat "," arg)^" (arg)\n"); *)
  let tc = get_termcloud () in
  let varlist =
    try
      match Hashtbl.find tc.terms node with
        Appl (_,_,vl) -> ref vl
      | _ -> failwith ("propagate_appl_up: node "^(string_of_int node)^" is not an application.")
    with Not_found -> failwith ("propagate_appl_up: node "^(string_of_int node)^" does not exist.")
  in
  let rec drop l offset =
    match !varlist with
      [] -> l
    | (v2,_)::r1 -> ( (* print_string ("drop "^(string_of_int v2)^" with offset "^(string_of_int offset)^"\n"); *)
                     let (head,tail) = first_n l (v2 - offset) in
                  (*   print_string ((String.concat "," l)^" (list)\n");
                     print_string ((String.concat "," head)^" (head)\n");
                     print_string ((String.concat "," tail)^" (tail)\n"); *)
                     varlist := r1;
                     match tail with                     
                       _::r2 -> List.append head (drop r2 (v2 + 1))
                     | _ -> failwith ("propagate_appl_up: varrange too short for  Node "^(string_of_int node)^"."))
  in
  List.append func (drop arg 0) 


let propagate_abstr_up node body =
  let tc = get_termcloud () in
  let var =
    try
      match Hashtbl.find tc.terms node with
        Abstr (_,v) -> v
      | _ -> failwith ("propagate_abstr_up: node "^(string_of_int node)^" is not an abstraction.")
    with Not_found -> failwith ("propagate_abstr_up: node "^(string_of_int node)^" does not exist.")
  in
  if var = -1
  then body
  else
    match first_n body var with
      (v_hd,v::v_tl) -> List.append v_hd v_tl
    | _ -> failwith ("propagate_abstr_up: varrange too short for Node "^(string_of_int node)^".")
  
  

  

(** Propagate a variable context downwards *)
let propagate_appl_down node app =
(*  print_string "propagate down:\n";
  print_string ((String.concat "," app)^" (app)\n"); *)
  let tc = get_termcloud () in
  let (varlist, func_node) =
    try
      match Hashtbl.find tc.terms node with
        Appl (f,_,vl) -> (ref vl,f)
      | _ -> failwith ("propagate_appl_down: node "^(string_of_int node)^" is not an application.")
    with Not_found -> failwith ("propagate_appl_down: node "^(string_of_int node)^" does not exist.")
  in
  let func_range =
    try
      Hashtbl.find tc.varrange func_node
    with Not_found -> failwith ("propagate_appl_down: node "^(string_of_int node)^" does not exist.")
  in
  let (func,arg_pre) = first_n app func_range in
  let rec insert l offset =
    match !varlist with
      [] -> l
    | (v2,v1)::r1 -> (print_string ("insert "^(string_of_int v2)^"/"^(string_of_int v1)^" with offset "^(string_of_int offset)^"\n");
                      let (head,tail) = first_n l (v2 - offset) in
                  (*    print_string ((String.concat "," l)^" (list)\n");
                      print_string ((String.concat "," head)^" (head)\n");
                      print_string ((String.concat "," tail)^" (tail)\n");
                      print_string ((String.concat "," func)^" (func)\n"); *)
                      let var1 = List.nth func v1 in
                      varlist := r1;
                      List.append head (var1::(insert tail (v2 + 1))))
  in
  (func, insert arg_pre 0)


let propagate_abstr_down node abstr bound =
  let tc = get_termcloud () in
  let var =
    try
      match Hashtbl.find tc.terms node with
        Abstr (_,v) -> v
      | _ -> failwith ("propagate_abstr_up: node "^(string_of_int node)^" is not an abstraction.")
    with Not_found -> failwith ("propagate_abstr_up: node "^(string_of_int node)^" does not exist.")
  in
  let (v_hd,v_tl) = first_n abstr var in
  (List.append v_hd (bound::v_tl))
  
(** constraints *)

let make_constraints func arg eq =
  let rec find l elt offset =
    match l with
      hd::tl -> if (eq hd elt) then offset else find tl elt (offset + 1)
    | _ -> -1
  in
  let rec make_csrts l offset =
    match l with
      [] -> []
    | hd::tl -> (let pos = find func hd 0 in
                 let cs_tl = make_csrts tl (offset + 1) in
                 if pos = -1 then cs_tl else (offset,pos)::cs_tl)
  in
  make_csrts arg 0
    
let find_bound body var eq =
  let rec find_rec vars var offset =
    match vars with
      v::rest -> if (eq v var) then offset else find_rec rest var (offset + 1)
    | _ -> -1
  in
  find_rec body var 0


(** I/O *)

let to_csv () =
  let tc = get_termcloud () in
  let s = 
    (Hashtbl.fold
      (fun (f,a,cs) n s -> s^(string_of_int n)^";"^(string_of_int f)^";"^(string_of_int a)^";"^
                           (String.concat ":" (List.map (fun (x,y) -> "("^(string_of_int x)^","^(string_of_int y)^")") cs))^
                           "\n")
      tc.applications "")^
    (Hashtbl.fold
      (fun (b,v) n s -> s^((string_of_int n)^";"^(string_of_int b)^";"^(string_of_int v)^"\n"))
      tc.abstractions "")^
    (Hashtbl.fold
      (fun a n s -> s^(string_of_int n)^";"^a^"\n")
      tc.symbols "") in
  s

let read_csv_line s =
  let tc = get_termcloud () in
  let line = Util.split_string s ';' in
  let parse vars =
    let varlist = Util.split_string vars ':' in
    List.map
      (fun s ->
        let comma = String.index s ',' in
        let v1 = (String.sub s 1 (comma-1)) in
        let v2 = (String.sub s (comma + 1) ((String.length s) - (comma + 2))) in
        int_of_string v1, int_of_string v2)
      (List.filter (fun x -> x <> "") varlist)
  in  
  match line with
    [n;f;a;vars] ->
      let node = int_of_string n in
      let func = int_of_string f in
      let arg = int_of_string a in
      let varlist = parse vars in
      Hashtbl.add tc.applications (func, arg, varlist) node;
      Hashtbl.add tc.terms node (Appl (func, arg, varlist))
  | [n;b;v] ->
      let node = int_of_string n in
      let body = int_of_string b in
      let var = int_of_string v in
      Hashtbl.add tc.abstractions (body,var) node;
      Hashtbl.add tc.terms node (Abstr (body,var))
  | [n;name] ->
      let node = int_of_string n in
      Hashtbl.add tc.symbols name node;
      Hashtbl.add tc.terms node (Symbol name);
  | _ -> failwith "Could not recognize csv line"

let read_csv_file f =
  set_termcloud (new_termcloud ());
  let c_in = open_in f in
  let line_count = ref 0 in
  try
    while true do
      let line = input_line c_in in
      line_count := !line_count + 1;
      try read_csv_line line with _ -> failwith ("Error while reading "^f^", line "^(string_of_int !line_count))
    done
  with End_of_file -> ()
