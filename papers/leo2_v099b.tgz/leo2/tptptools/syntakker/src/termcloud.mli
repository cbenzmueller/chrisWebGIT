(** Module Termcloud
    @author Frank Theiss
    @since 01-28-08 *)

(** Terms *)
type term = 
    Appl of int * int * ((int * int) list)
  | Abstr of int * int
  | Symbol of string

(** Sets of Integers *)
module IdSet :
    sig
      type elt = int
      type t
      val empty : t
      val is_empty : t -> bool
      val mem : elt -> t -> bool
      val add : elt -> t -> t
      val singleton : elt -> t
      val remove : elt -> t -> t
      val union : t -> t -> t
      val inter : t -> t -> t
      val diff : t -> t -> t
      val compare : t -> t -> int
      val equal : t -> t -> bool
      val subset : t -> t -> bool
      val iter : (elt -> unit) -> t -> unit
      val fold : (elt -> 'a -> 'a) -> t -> 'a -> 'a
      val for_all : (elt -> bool) -> t -> bool
      val exists : (elt -> bool) -> t -> bool
      val filter : (elt -> bool) -> t -> t
      val partition : (elt -> bool) -> t -> t * t
      val cardinal : t -> int
      val elements : t -> elt list
      val min_elt : t -> elt
      val max_elt : t -> elt
      val choose : t -> elt
      val split : elt -> t -> t * bool * t
    end

(** Termcloud *)
type termcloud = {
  nodecount    : int ref;
  applications : (int * int * ((int * int) list), int) Hashtbl.t;
(** A unique application term is defined by its function term, its argument term, and the
    list of variable connections between them *) 

  abstractions : (int * int, int) Hashtbl.t;
(** A unique abstraction is defined by its body and the abstracted variable *)

  symbols      : (string, int) Hashtbl.t;
(** A unique symbol is defined by its string name *)

  varrange     : (int, int) Hashtbl.t;
(** The number of distinct variables occurring in a term *)

  terms        : (int, term) Hashtbl.t;

  app_with_fun : (int, IdSet.t) Hashtbl.t;
  app_with_arg : (int, IdSet.t) Hashtbl.t;
  abs_with_bdy : (int, IdSet.t) Hashtbl.t;
  }

val new_termcloud : unit -> termcloud

val set_termcloud : termcloud -> unit

val get_termcloud : unit -> termcloud

val get_node : int -> term


(** terms *)

val appl : int -> int -> (int * int) list -> int

val abstr : int -> int -> int

val symbol : string -> int



(** propagation *)

val propagate_appl_up : int -> 'a list -> 'a list -> 'a list

val propagate_abstr_up : int -> 'a list -> 'a list

val propagate_appl_down : int -> 'a list -> 'a list * 'a list

val propagate_abstr_down : int -> 'a list -> 'a -> 'a list


(** constraints *)

val make_constraints : 'a list -> 'a list -> ('a -> 'a -> bool) -> (int * int) list

val find_bound : 'a list -> 'a -> ('a -> 'a -> bool) -> int

(** I/O *)

val to_csv : unit -> string

val read_csv_file : string -> unit
