(** Module Config
    @author Frank Theiss
    @since 12-11-08 *)

val get_binary : string -> string

val set_binary : string -> string -> unit
