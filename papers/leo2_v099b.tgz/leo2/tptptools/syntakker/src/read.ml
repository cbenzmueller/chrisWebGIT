let _ =  
  let lexbuf = Lexing.from_channel stdin in
  let fs = Tptp_parser.tptp_file Tptp_lexer.token lexbuf in
  List.iter (fun f -> print_string ((Formula.to_string f)^"\n")) fs
