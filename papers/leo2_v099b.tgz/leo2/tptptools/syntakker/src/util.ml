(** Module Util
    @author Frank Theiss
    @since 03-11-09 *)

let split_string s sep =
  let parts = ref [] in
  let index = ref 0 in
  (try
    while true do
      let next = String.index_from s !index sep in
      parts := (String.sub s (!index) (next - (!index)))::(!parts);
      index := next + 1
    done
  with Not_found -> ());
  parts := (String.sub s (!index) ((String.length s) - (!index)))::(!parts);
  List.rev !parts

let newvar varnames prefix =
  let i = ref 0 in
  while List.mem (prefix^(string_of_int !i)) varnames
  do
    i := !i + 1
  done;
  prefix^(string_of_int !i)
