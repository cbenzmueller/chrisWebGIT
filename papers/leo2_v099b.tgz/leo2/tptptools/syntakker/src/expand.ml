let _ =
  let c_in = open_in Sys.argv.(1) in  
  let lexbuf = Lexing.from_channel c_in in
  let include_file flist =
    match flist with
      (Formula.Symbol file)::_ -> (
                    let dir = Filename.dirname (Sys.argv.(1))^"/" in
                    let base = String.sub file 1 ((String.length file) - 2) in
                    let axiomdirs = ref ["";"Axioms/";"../";"../Axioms/"] in
                    (try
                      while (not (Sys.file_exists (dir^(List.hd !axiomdirs)^base)))
                      do
                        axiomdirs := (List.tl !axiomdirs)
                      done
                    with _ -> failwith ("Could not open include file: "^base));
                    let output = Unix.open_process_in (Sys.argv.(0)^" "^dir^(List.hd !axiomdirs)^base) in
                    let include_result = ref "" in
                    let not_eof = ref true in
                    while !not_eof do
                      include_result := (!include_result)^
                                        (try ((input_line output)^"\n")
                                         with End_of_file -> (not_eof := false;""))
                    done;
                    let _ = Unix.close_process_in output in
                    !include_result)
    | _ -> failwith "No filename given"
  in
  Hashtbl.replace (!Formula.dictionary) "$$include" include_file;
  let fs = Tptp_parser.tptp_file Tptp_lexer.token lexbuf in
  List.iter (fun f -> print_string ((Formula.to_string f)^"\n")) fs;
  flush stdout
