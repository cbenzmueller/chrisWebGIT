let _ =  
  let lexbuf = Lexing.from_channel stdin in
  Formula.set_format "plain";
(* Tptp_config.accumulator := (fun f f_list -> let _ = Term.make (Term.to_term f) in f::f_list); *) 
  Tptp_config.accumulator := (fun f f_list -> let _ = Term.make (Term.to_term f) in f_list); 
  (try (
    let fs = Tptp_parser.tptp_file Tptp_lexer.token lexbuf in
(*    List.iter (fun f -> print_string ((Formula.to_string f)^"\n")) fs; *)
    print_string "======= All input read. ========\n" 
  )
  with Failure s -> print_string ("Failure: "^s^"\n"));
(*  print_string (Termcloud.to_csv ()); 
  let c_out = open_out "new_csv" in *)
  print_string "======= Termcloud ========\n"; 
  output_string stdout (Termcloud.to_csv ())
(*  close_out c_out;
  Termcloud.read_csv_file "new_csv";
  let c_out = open_out "new_csv2" in
  output_string c_out (Termcloud.to_csv ());
  close_out c_out; *)
  
