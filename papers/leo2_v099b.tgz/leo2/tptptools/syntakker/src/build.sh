#!/bin/sh
ocamlbuild syntakker.native
