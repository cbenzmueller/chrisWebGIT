(** Module Util
    @author Frank Theiss
    @since 03-11-09 *)

(** String utilities *)

(** Split string *)
val split_string : string -> char -> string list

val newvar : string list -> string -> string
