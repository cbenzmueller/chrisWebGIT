type term =
   Appl of term * term
 | Abstr of term * string
 | Symbol of string
 | Node of int * string list

let eq x y = (x = y)

let rec make t =
  match t with
    Appl (t1,t2) -> let Node (n1,vars1) = make t1 in
                    let Node (n2,vars2) = make t2 in
                    let n = Termcloud.appl n1 n2 (Termcloud.make_constraints vars1 vars2 eq) in
                    Node (n,(Termcloud.propagate_appl_up n vars1 vars2)) 
  | Abstr (t1,v) -> let Node (n1,vars1) = make t1 in
                    (* print_string ("Searching "^v^" in ");
                    List.iter (fun v -> print_string (v^" "))vars1;
                    print_string "\n"; *)
                    let n = Termcloud.abstr n1 (Termcloud.find_bound vars1 v eq) in
                    Node (n,(Termcloud.propagate_abstr_up n vars1))
  | Symbol s -> if (String.get s 0) >= 'A' && (String.get s 0) <= 'Z'
                then Node (0,[s])
                else Node ((Termcloud.symbol s),[])
  | Node _ -> t




let rec reconstruct n varnames =
  if n = 0
  then Symbol (List.nth varnames 0)
  else
    let node = Termcloud.get_node n in
    match node with
      Termcloud.Appl (t1,t2,_) ->
        let (vn1,vn2) = Termcloud.propagate_appl_down n varnames in
        Appl (reconstruct t1 vn1, reconstruct t2 vn2)
    | Termcloud.Abstr (t,v) ->
        let vn = Termcloud.propagate_abstr_down n varnames (Util.newvar varnames "V")   in
        Abstr (reconstruct t vn, List.nth varnames v)
    | Termcloud.Symbol s -> Symbol s


let rec unmake t =
  match t with
    Appl (t1,t2) -> Appl (unmake t1, unmake t2)
  | Abstr (t1,v) -> Abstr (unmake t1, v)
  | Symbol _ -> t
  | Node (n,varnames) -> reconstruct n varnames






let dictionary_read = ref (Hashtbl.create 0)

let rec to_term f =
  match f with
    Formula.Appl (Formula.Symbol func, args)  -> if Hashtbl.mem !dictionary_read func
                                then (Hashtbl.find !dictionary_read func) args
                                else List.fold_left (fun f a -> Appl (f,to_term a)) (Symbol func) args
  | Formula.Appl (func, args)         -> List.fold_left (fun f a -> Appl (f,to_term a)) (to_term f) args
  | Formula.Symbol s                  -> Symbol s

let rec make_list f_list =
  match f_list with
    f::rest -> Appl (Appl (Symbol "$$cons", to_term f), make_list rest)
  | [] -> Symbol "$$null"

let make_appl f args =
  List.fold_left (fun f a -> Appl (f,to_term a)) (to_term f) args

let make_abstr args =
  match args with
    [Formula.Symbol q;Formula.Appl (Formula.Symbol "$$tuple",vars);body]
      -> let abstr = List.fold_left
                       (fun b v ->
                          match v with
                            Formula.Appl (Formula.Symbol "$$typed_var",[Formula.Symbol var;vtype]) -> (* print_string ("tvar "^var^"\n"); *)
                                                                                                      Abstr (b,var)
                          | Formula.Symbol var -> (* print_string ("var "^var^"\n"); *)
                                                  Abstr (b,var)
                          | _ -> failwith ("error in variable declaration: "^(Formula.to_string v)))
                       (to_term body)
                       vars in
         if q = "^" then abstr else Appl (Symbol q, abstr)



 (*     -> Appl (Symbol q,
               List.fold_left
                 (fun b v ->
                    match v with
                      Formula.Appl (Formula.Symbol "$$typed_var",[Formula.Symbol var;vtype]) -> (* print_string ("tvar "^var^"\n"); *)
                                                                                                Abstr (b,var)
                    | Formula.Symbol var -> (* print_string ("var "^var^"\n"); *)
                                            Abstr (b,var)
                    | _ -> failwith ("error in variable declaration: "^(Formula.to_string v)))
                 (to_term body)
                 vars) *)
  | _ -> failwith "error in arguments for \"$$quantified\""


let formula2term = [
  ("$$tuple", make_list);
  ("$$null", fun _ -> Symbol "$$null");
  ("$$thf",fun x ->
             match x with
               [name;role;f;annotations] -> make_appl (Formula.Symbol "$$thf") x
             | _ -> failwith "wrong argument number for \"$$thf\"");
  ("$$fof",fun x ->
             match x with
               [name;role;f;annotations] -> make_appl (Formula.Symbol "$$fof") x
             | _ -> failwith "wrong argument number for \"$$thf\"");
  ("$$cnf",fun x ->
             match x with
               [name;role;f;annotations] -> make_appl (Formula.Symbol "$$cnf") x
             | _ -> failwith "wrong argument number for \"$$cnf\"");
(*  ("$$typed_var",fun x ->
             match x with
               [Formula.Symbol var;t] -> Symbol var
             | _ -> failwith "wrong argument number for \"$$typed_var\""); *)
  ("$$type_formula",fun x ->
             match x with
               [f;t] -> make_appl (Formula.Symbol "$$type_formula") x
             | _ -> failwith "wrong argument number for \"$$type_formula\"");
  ("$$annotations",fun x ->
             match x with
               [source;opt] -> make_appl (Formula.Symbol "$$annotations") x
             | _ -> failwith "wrong argument number for \"$$annotations\"");
  ("$$letrec",fun x ->
             match x with
               [lets;f] -> make_appl (Formula.Symbol "$$letrec") x
             | _ -> failwith "wrong argument number for \"$$letrec\"");
  ("$$useful_info",fun x ->
             match x with
               [info] -> make_appl (Formula.Symbol "$$useful_info") x
             | _ -> failwith "wrong argument number for \"$$useful_info\""); 
  ("$$poslit",fun x ->
             match x with
               [lit] -> make_appl (Formula.Symbol "$$poslit") x
             | _ -> failwith "wrong argument number for \"$$poslit\"");
  ("$$neglit",fun x ->
             match x with
               [lit] -> make_appl (Formula.Symbol "$$neglit") x
             | _ -> failwith "wrong argument number for \"$$neglit\"");
  ("$$formula_selection",fun x ->
             match x with
               [info] -> make_appl (Formula.Symbol "$$formula_selection") x
             | _ -> failwith "wrong argument number for \"$$formula_selection\"");
  (":",fun x ->
             match x with
               [t1;t2] -> make_appl (Formula.Symbol "$$typed") x
             | _ -> failwith "wrong argument number for \":\"");
  ("$$include",fun x ->
             match x with
               [file;select] -> make_appl (Formula.Symbol "$$include") x
             | _ -> failwith "wrong argument number for \"$$include\"");
  ("$$quantified", make_abstr)
  ]

let set_format f =
  match String.lowercase f with
  | "standard" -> (Hashtbl.clear !dictionary_read;
                   List.iter (fun (name,func) -> Hashtbl.add !dictionary_read name func) formula2term)
  | _ -> failwith ("set_format: There's no format \""^f^"\".")

let _ = print_string "Initialize..."

let _ = set_format "standard"

let _ = print_string "Done.\n"

let _ = flush stdout
