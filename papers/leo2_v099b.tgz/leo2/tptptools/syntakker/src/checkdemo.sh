#!/bin/sh
echo "" > demoall
for file in `ls ~/import/leo/demoarea/*.ax`
do
  echo "Reading: $file" 
#  ./syntakker.native < $file
  cat $file >> demoall
done
for file in `ls ~/import/leo/demoarea/*.p`
do
  echo "Reading: $file" 
#  ./syntakker.native < $file
  cat $file >> demoall
done
./syntakker.native < demoall > democsv


