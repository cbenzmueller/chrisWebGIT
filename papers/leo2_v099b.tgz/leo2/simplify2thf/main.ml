
let sexps = (Sexp.read_sexp stdin)

(* let _ = List.map (fun x -> print_string (Sexp.write_sexp x)) sexps *)

let _ = print_string (Simplify2thf.simplify2thf sexps)
