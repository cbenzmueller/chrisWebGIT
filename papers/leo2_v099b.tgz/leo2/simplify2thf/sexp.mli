(* S-expressions *)


(** The type of S-expressions *)

type sexp =
    Atom of string
  | Expr of sexp list

exception Parse_Error of string

(** Write S-expressions *)

val write_sexp: sexp -> string

(** Read S-expressions *)

val read_sexp: in_channel -> sexp list
