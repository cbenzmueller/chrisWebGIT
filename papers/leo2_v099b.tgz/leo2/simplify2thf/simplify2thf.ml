(* Translate Simplify format to TPTP-THF *)

(** Dictionaries *)

let top = Hashtbl.create 10

let inner = Hashtbl.create 10

let atom = Hashtbl.create 10

let scope_vars = ref []

(** Translator functions *)

let formula_count = ref 0

let next_name () =
  let name = "formula_"^(string_of_int (!formula_count)) in
  formula_count := (!formula_count) + 1;
  name

let make_axiom f = "thf("^(next_name ())^",axiom,"^f^").\n"

let make_constant f t = "thf("^(next_name ())^",constant,("^f^" : "^t^")).\n"

let clean_atom a = List.fold_left
                   (fun a (str,rplc) -> Str.global_replace (Str.regexp str) rplc a)
                   a
                   [
                    ("[.]","_");
                    ("\$","dollar_");
                    ("#","sharp_");
                    ("|@","bar_at_");
                    ("|\+","bar_plus_");
                    ("|","_bar");
                    ("@","_at_");
                   ]   

let do_atom a = if Hashtbl.mem atom a
                then Hashtbl.find atom a
                else
                  let clean_a = clean_atom a in
                  Hashtbl.add atom a clean_a;
                  clean_a

(* Rem.: maybe reset vars after scope end? *)
let do_var a = let clean_a = "X_"^(clean_atom a) in
               Hashtbl.add (List.hd !scope_vars) a clean_a;
               Hashtbl.add atom a clean_a;
               clean_a

let new_scope n = scope_vars := (Hashtbl.create n)::(!scope_vars)

let end_scope () = Hashtbl.iter (fun a _ -> Hashtbl.remove atom a) (List.hd (!scope_vars));
                   scope_vars := (List.tl (!scope_vars))

let rec do_inner_formula f =
  match f with
    Sexp.Expr ((Sexp.Atom func)::args) -> if Hashtbl.mem inner func
                                then (Hashtbl.find inner func) args
                                else "("^
                                (List.fold_left
                                   (fun thf fi ->
                                      thf^" @ "^(do_inner_formula fi))
                                   (do_atom func)
                                   args)
                                ^")"  
  | Sexp.Expr _ -> raise (Sexp.Parse_Error ("Can't read:\n"^(Sexp.write_sexp f)^"\n"))
  | Sexp.Atom a -> do_atom a


let do_formula f =
  match f with
    Sexp.Expr ((Sexp.Atom func)::args) -> if Hashtbl.mem top func
                                then (Hashtbl.find top func) args
                                else make_axiom (do_inner_formula f)
  | Sexp.Expr _ -> raise (Sexp.Parse_Error ("Can't read:\n"^(Sexp.write_sexp f)^"\n"))
  | Sexp.Atom a -> make_axiom (do_atom a)


(** Syntax functions *)

(** Inner formula *)

(* Rem.: maybe reset vars after scope end? *)
let resolve_quantifier q l =
  match l with
    (Sexp.Expr ((Sexp.Atom v1)::varlist))::_::_ ->
      (new_scope ((List.length varlist) + 1);
       let vars = try 
         (List.fold_left 
           (fun accu v -> 
             let Sexp.Atom var = v in
             accu^", "^(do_var var))
           (do_var v1) varlist)
         with _ -> raise (Sexp.Parse_Error ("Can't read varlist "^(Sexp.write_sexp (List.hd l))^" in forall statement.\n"))
         in
       let result = q^"["^vars^"]:"^(do_inner_formula (List.nth l ((List.length l)-1))) in
       end_scope ();
       result)
  | _ -> raise (Sexp.Parse_Error ("Syntax error in forall statement.\n"))

let binary_infix op l =
  match l with
    [a;b] -> "("^(do_inner_formula a)^" "^op^" "^(do_inner_formula b)^")"
  | _ -> raise (Sexp.Parse_Error ("Can't read "^(Sexp.write_sexp (Sexp.Expr ((Sexp.Atom op)::l)))^".\n"))

let n_ary_infix op l =
  match l with 
    [f1] -> do_inner_formula f1
  | f1::fl -> "("^(List.fold_left (fun accu f -> accu^" "^op^" "^(do_inner_formula f)) (do_inner_formula f1) fl)^")"
  | _ -> raise (Sexp.Parse_Error ("No arguments for n-ary operator "^op^".\n"))

let unary_prefix op l =
  match l with
    [Sexp.Atom a] -> "("^op^"("^(do_atom a)^"))"
  | [a] -> "("^op^" "^(do_inner_formula a)^")"
  | _ -> raise (Sexp.Parse_Error ("Can't read "^(Sexp.write_sexp (Sexp.Expr ((Sexp.Atom op)::l)))^".\n"))

(** Top formula *)

let resolve_let l =
  let [Sexp.Expr fs;f_let] = l in
  let accu = ref "" in
  List.iter
    (fun f ->
       match f with
         Sexp.Expr [(Sexp.Atom "FORMULA");(Sexp.Atom f_name);f_def] ->
           accu := (!accu)^(make_constant (do_atom f_name) "$o")^
                   (make_axiom ((do_atom f_name)^" <=> "^(do_inner_formula f_def)))
       | _ -> raise (Sexp.Parse_Error ("Can't resolve let statement:\n"^(Sexp.write_sexp f)^"\n")))
    fs;
  (!accu)^(do_formula f_let)


let resolve_and l =
  List.fold_left
    (fun accu f ->
       accu^(do_formula f))
    "" l

let resolve_bg_push fs =
  let accu = ref "" in
  List.iter (fun f -> accu := (!accu)^(do_formula f)) fs;
  !accu

let resolve_deftype l = 
   match l with
     (Sexp.Atom t)::_ -> (make_constant (do_atom t) "$type")
   | f::_ -> raise (Sexp.Parse_Error ("Can't resolve type definition:\n"^(Sexp.write_sexp f)^"\n"))
   | _ -> raise (Sexp.Parse_Error ("Empty type definition.\n"))

let resolve_defop l =
   match l with
     (Sexp.Atom op)::(Sexp.Atom ty1)::tys -> let op_type =
                                try  
                                (List.fold_left
                                   (fun accu tyi ->
                                      let Sexp.Atom t = tyi in
                                      accu^" > "^(do_atom t))
                                   (do_atom ty1)
                                   tys)
                                 with _ -> raise (Sexp.Parse_Error ("Ill type definition for "^op^".\n"))
                                 in
                                 (make_constant (do_atom op) op_type)
   | f::_ -> raise (Sexp.Parse_Error ("Type definition for non-atom \n"^(Sexp.write_sexp f)^"\n"))
   | _ -> raise (Sexp.Parse_Error ("Empty type definition.\n")) 

let rec resolve_distinct l =
  match l with
    [] -> ""
  | [_] -> ""
  | a::lr -> (List.fold_left
                (fun accu b -> accu^(make_axiom ((do_inner_formula a)^" != "^(do_inner_formula b))))
                "" lr)^
             (resolve_distinct lr) 

(** Dictionaries *)

let atom_dic = [
  ("$int","$int");
  ("$#__int__","$int");
  ("$bool","$o");
  ("$#__bool__","$o");
  ("|@false|","$false");
  ("|@true|","$true");
  ("FALSE","$false");
  ("TRUE","$true");
  ("<:","$partial_less");
  ("<=","$lesseq_int");
  ("<","$less_int");
  (">=","$greatereq_int");
  (">","$greater_int");
  ("+","$plus_int");
  ("-","$minus_int");
  ("/","$divide_int");
  ("*","$times_int");
  ("%","$remainder_int");
  ("LBLPOS","lblpos");
  ("LBLNEG","lblneg");
  ("ITE","if_then_else");
  ]

let inner_dic = [
  (* quantifiers *)
  ("FORALL",resolve_quantifier "!");
  ("EXISTS",resolve_quantifier "?");
  (* logic *)
  ("AND",n_ary_infix "&");
  ("OR",n_ary_infix "|");
  ("EQ",binary_infix "=");
  ("IMPLIES",binary_infix "=>");
  ("IFF",binary_infix "<=>");
  ("NEQ",binary_infix "!=");
  ("NOT",unary_prefix "~");
  ]

let top_dic = [
  ("LET",resolve_let);
  ("BG_PUSH",resolve_bg_push);
  ("DEFTYPE",resolve_deftype);
  ("DEFOP",resolve_defop);
  ("AND",resolve_and);
  ("DISTINCT",resolve_distinct);
  ]

let _ = List.iter (fun (a,b) -> Hashtbl.add atom a b) atom_dic

let _ = List.iter (fun (a,b) -> Hashtbl.add inner a b) inner_dic

let _ = List.iter (fun (a,b) -> Hashtbl.add top a b) top_dic


(** Do it *)

let rec simplify2thf fs =
  match fs with
    f::fr -> (do_formula f)^(simplify2thf fr)
  | [] -> "\n"
