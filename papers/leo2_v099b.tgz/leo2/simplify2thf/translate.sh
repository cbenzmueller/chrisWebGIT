#!/bin/sh
cat leodefs.thf
sed -e 's/;.*$//g' | main.native