(* Translate Simplify format to TPTP-THF *)

open Sexp

(** translate *)

val simplify2thf: sexp list -> string
