#! /bin/sh
sed -e 's/[^A-Z]\([A-Z][A-Z][A-Z]*\)[^A-Z]/\n\1\n/g' | sed -e '/[A-Z][A-Z]/!d' | sort -u