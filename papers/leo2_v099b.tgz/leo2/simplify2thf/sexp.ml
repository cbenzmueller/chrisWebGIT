(* S-expressions *)


(** The type of S-expressions *)

type sexp =
    Atom of string
  | Expr of sexp list

exception Parse_Error of string

(** Write S-expressions *)

let newline = ref true
let starter = ref true

let rec write_inner_sexp e i=
  match e with
    Atom s -> if s = "" then "noitem" else (newline:=false; starter:=false; s)
  | Expr l -> let result = ref "" in
              starter:=true;
              result := (!result)^(if !newline then "(" else "\n"^i^"("); 
              starter := true;
              newline := true;
              List.iter (fun x -> result:=(!result)^(if !starter then "" else " ");
                                  result:=(!result)^(write_inner_sexp x (i^" ")))
                l;
              result:=(!result)^")";
              starter:=false;
              !result

let write_sexp e =
  newline:=true;
  starter:=true;
  (write_inner_sexp e "")^"\n"


(** Read S-expressions *)

let read_sexp ci =
  let stack = ref [[]] in
  let token = ref "" in
  let line_number = ref 1 in
  let line_pos = ref 0 in
  
  let atom_end () =
    if not (!token = "") then
    (let l1::rest = !stack in
    stack := ((Atom !token)::l1)::rest;
    token := "")
    else ()
  in
  let sexp_start () =
    stack := []::!stack
  in
  let sexp_end () =
    let l1::l2::rest = !stack in
    stack := ((Expr (List.rev l1))::l2)::rest
  in
  let line_end () =
    line_number := !line_number +1;
    line_pos := 0
  in
  (try
    while true do
      line_pos := !line_pos + 1;
      match input_char ci with
        '(' -> atom_end (); sexp_start ()
      | ')' -> atom_end (); sexp_end ()
      | ' ' -> atom_end ();
      | '\013'
      | '\t' -> atom_end ()
      | '\n' -> atom_end (); line_end ()
      | c -> token := !token^(String.make 1 c)
    done
  with 
    End_of_file -> ()
  | _ -> raise (Parse_Error ("Syntax error in line "^(string_of_int !line_number)^
                                " at position "^(string_of_int !line_pos)^".")));
  try
    let [result] = !stack in
    List.rev result
  with _ -> raise (Parse_Error ("Unmatched opening bracket."))   

