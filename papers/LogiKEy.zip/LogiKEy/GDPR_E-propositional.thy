theory GDPR_E     (*GDPR CTD Example. Christoph Benzmüller & Xavier Parent, 2018*)
imports E
begin
  (*Unimportant.*) sledgehammer_params [max_facts=20,timeout=20] 
  (*Unimportant.*) nitpick_params [user_axioms,expect=genuine,show_all,format=2] 

 consts   process_data_lawfully::\<sigma>   erase_data::\<sigma>    kill_boss::\<sigma>

 axiomatization where
  (*It is an obligation to process data lawfully.*)
    A1: "\<lfloor>\<^bold>\<circle><process_data_lawfully>\<rfloor>"  and
  (*If data was not processed lawfully, then it is an obligation to erase the data.*)
    A2: "\<lfloor>\<^bold>\<circle><erase_data|\<^bold>\<not>process_data_lawfully>\<rfloor>" and
  (*Implicit: It is an obligation to keep the data if it was processed lawfully.*)
    Implicit: "\<lfloor>\<^bold>\<circle><\<^bold>\<not>erase_data |process_data_lawfully>\<rfloor>" and
  (*Given a situation where data is processed unlawfully.*) 
    Situation: "\<lfloor>(\<^bold>\<not>process_data_lawfully)\<rfloor>\<^sub>l" 

 (***Some Experiments***) 
  lemma True  nitpick [satisfy,card=1]  (*Consistency-check: Is there a model?*) 
  lemma False sledgehammer      oops  (*Inconsistency-check: Can Falsum be derived?*) 

  lemma "\<lfloor>\<^bold>\<circle><erase_data>\<rfloor>"   sledgehammer nitpick   (*Should the data be erased?*)
  lemma "\<lfloor>\<^bold>\<circle><\<^bold>\<not>erase_data>\<rfloor>"  sledgehammer nitpick oops  (*Should the data be kept?*)
  lemma "\<lfloor>\<^bold>\<circle><kill_boss>\<rfloor>"    sledgehammer nitpick oops  (*Should the boss be killed?*)            
end




  
 