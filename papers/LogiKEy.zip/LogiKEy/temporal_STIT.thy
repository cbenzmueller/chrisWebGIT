theory temporal_STIT
  imports Main

begin

  typedecl i                          (* "type for possible worlds" *)
  type_synonym \<sigma> = "(i\<Rightarrow>bool)"        (* "propositions are lifted to predicates on worlds" *)
  type_synonym \<alpha> = "(i \<Rightarrow> i \<Rightarrow> bool)" (* "type for possible agent" *)

  (* 2 Agents: a1 & a2 *)
  consts a1::\<alpha> a2::\<alpha>
  (* w rbox defines the set of worlds that are alternative to the world w. *)
  consts r_box :: "i\<Rightarrow>i\<Rightarrow>bool"  (infixr "rbox" 70)
  (* w ri defines the set of all alternatives that is forced 
     by agent i's actual choice at w. *)
  consts ri :: "i\<Rightarrow>i\<Rightarrow>bool"
  (* w ragt defines the set of all alternatives that is forced
     by the collective choice of all agents at w. *)
  consts r_agt :: "i\<Rightarrow>i\<Rightarrow>bool"  (infixr "ragt" 70)
  (* w rG defines the set of worlds that are 
     in the strict future of the world w. *)
  consts r_G :: "i\<Rightarrow>i\<Rightarrow>bool"    (infixr "rG" 70 )
  (* w rH defines the set of worlds that are
     in the past of the world w. *)
  consts r_H :: "i\<Rightarrow>i\<Rightarrow>bool"    (infixr "rH" 70 )

  consts aw::i (* actual world *)

 abbreviation mnot :: "\<sigma>\<Rightarrow>\<sigma>" ("\<^bold>\<not>_"[52]53)      (* negation *)
   where "\<^bold>\<not>\<phi> \<equiv> \<lambda>w. \<not>\<phi>(w)"
 abbreviation mand :: "\<sigma>\<Rightarrow>\<sigma>\<Rightarrow>\<sigma>" (infixr"\<^bold>\<and>"51)  (* conjunction *)
   where "\<phi>\<^bold>\<and>\<psi> \<equiv> \<lambda>w. \<phi>(w)\<and>\<psi>(w)" 
 abbreviation mor  :: "\<sigma>\<Rightarrow>\<sigma>\<Rightarrow>\<sigma>" (infixr"\<^bold>\<or>"50)  (* disjunction *)
  where "\<phi>\<^bold>\<or>\<psi> \<equiv> \<lambda>w. \<phi>(w)\<or>\<psi>(w)"   
 abbreviation mimp :: "\<sigma>\<Rightarrow>\<sigma>\<Rightarrow>\<sigma>" (infixr"\<^bold>\<rightarrow>"49) (* implication *)
   where "\<phi>\<^bold>\<rightarrow>\<psi> \<equiv> \<lambda>w. \<phi>(w)\<longrightarrow>\<psi>(w)"  
 abbreviation mequiv :: "\<sigma>\<Rightarrow>\<sigma>\<Rightarrow>\<sigma>" (infixr"\<^bold>\<equiv>"48) (* equivalence *)
   where "\<phi>\<^bold>\<equiv>\<psi> \<equiv> \<lambda>w. \<phi>(w)\<longleftrightarrow>\<psi>(w)"
 (* Box operator:
    \<^bold>\<box>\<phi> stands for '\<phi> is true regardless of what every agent does ' or
    simply '\<phi> is necessarily true ' *)
 abbreviation mbox :: "\<sigma>\<Rightarrow>\<sigma>" ("\<^bold>\<box>")
   where "\<^bold>\<box> \<phi> \<equiv> \<lambda>w. \<forall>v. (w rbox v) \<longrightarrow> \<phi>(v)"
 (* Diamond operator - the dual of \<^bold>\<box>
    \<^bold>\<diamond>\<phi> stands for '\<phi> is possibly true ' *)
 abbreviation mdia :: "\<sigma>\<Rightarrow>\<sigma>" ("\<^bold>\<diamond>")
   where "\<^bold>\<diamond> \<phi> \<equiv> \<^bold>\<not> \<^bold>\<box>( \<^bold>\<not> \<phi>) "
 (* CSTIT operator - Chellas’s STIT operator
    a cstit \<phi> stands for 'agent a sees to it that \<phi>' *)
 abbreviation mcstit :: "(i\<Rightarrow>i\<Rightarrow>bool)\<Rightarrow>\<sigma>\<Rightarrow>\<sigma>" ("_ cstit _")
   where "r cstit \<phi> \<equiv> \<lambda>w. \<forall>v. r w v \<longrightarrow> \<phi>(v)"
 (* DSTIT operator - Deliberative STIT operator *)
 abbreviation mdstit :: "(i\<Rightarrow>i\<Rightarrow>bool)\<Rightarrow>\<sigma>\<Rightarrow>\<sigma>" ("_ dstit _")
   where "r dstit \<phi> \<equiv> (r cstit \<phi>)  \<^bold>\<and> \<^bold>\<not> \<^bold>\<box> \<phi>"
 (* Group STIT operator 
    gstit \<phi> stands for 'all agents see to it that \<phi> by acting together ' *) 
 abbreviation mgstit :: "(\<sigma>\<Rightarrow>\<sigma>)" (" gstit _ ")
   where "gstit \<phi> \<equiv> \<lambda>w. \<forall>v. (w ragt v) \<longrightarrow> \<phi>(v)"
  (* Dual of the group STIT operator
     dualgstit \<phi> stands for 'All agents do not prevent \<phi>'
     or 'All agents allow it that \<phi>'
     or 'the particular choices of all agents do not rule out \<phi>'
     from paper "STIT is dangerously undecidable." *)
 abbreviation mdualgstit :: "(\<sigma>\<Rightarrow>\<sigma>)" (" dualgstit _ ")
   where "dualgstit \<phi> \<equiv> \<^bold>\<not> gstit (\<^bold>\<not> \<phi>)"
 (* G - Future tense operator
    G\<phi> stands for '\<phi> will always be true in the future '*)
 abbreviation mfuture :: "\<sigma>\<Rightarrow>\<sigma>" ("G _")
   where "G \<phi> \<equiv> \<lambda>w. \<forall>v. (w rG v) \<longrightarrow> \<phi>(v)"
 (* G*\<phi> stands for '\<phi> is true in the present and will always be true *)
 abbreviation mfuturestar :: "\<sigma>\<Rightarrow>\<sigma>" ("G* _ ")
   where "G* \<phi> \<equiv> \<phi> \<^bold>\<and> (G \<phi>)"
 (* F - dual of the future tense operator G 
    F\<phi> stands for '\<phi> will be true at some point in the future ' *)
 abbreviation mfuturepoint :: "\<sigma>\<Rightarrow>\<sigma>" ("F _ ")
   where "F \<phi> \<equiv> \<^bold>\<not> G \<^bold>\<not> \<phi>"
 (* F* - dual of the operator G* 
    F*\<phi> stands for '\<phi> is true in the present or will be true at some point in the future ' *)
 abbreviation mfuturepointstar :: "\<sigma>\<Rightarrow>\<sigma>" ("F* _")
   where "F* \<phi> \<equiv> \<^bold>\<not> G* \<^bold>\<not> \<phi>"
 (* H - Past tense operator 
    H\<phi> stands for '\<phi> has always been true in the past ' *)
 abbreviation mpast :: "\<sigma>\<Rightarrow>\<sigma>" ("H _")
   where "H \<phi> \<equiv> \<lambda>w. \<forall>v. (w rH v) \<longrightarrow> \<phi>(v)"
 (* P - dual of the past tense operator H
    P\<phi> stands for '\<phi> has been true at some point in the past ' *)
 abbreviation mpastpoint :: "\<sigma>\<Rightarrow>\<sigma>" ("P _")
   where "P \<phi> \<equiv> \<^bold>\<not> H \<^bold>\<not> \<phi>"

  abbreviation  mtrue  :: "\<sigma>" ("\<^bold>\<top>")
    where "\<^bold>\<top> \<equiv> \<lambda>w. True" 
  abbreviation mfalse :: "\<sigma>" ("\<^bold>\<bottom>") 
    where "\<^bold>\<bottom> \<equiv> \<lambda>w. False"  

 abbreviation valid :: "\<sigma> \<Rightarrow> bool" ("\<lfloor>_\<rfloor>" [7]8)
   where "\<lfloor>\<phi>\<rfloor> \<equiv> \<forall>w. \<phi>(w)"

 abbreviation actual :: "\<sigma> \<Rightarrow> bool" ("\<lfloor>_\<rfloor>\<^sub>l"[7]105) 
   where "\<lfloor>\<phi>\<rfloor>\<^sub>l \<equiv> \<phi>(aw)"

 (* Subset for relations *)
 abbreviation subset_rel :: "(i\<Rightarrow>i\<Rightarrow>bool)\<Rightarrow>(i\<Rightarrow>i\<Rightarrow>bool)\<Rightarrow>bool"  ("_ \<^bold>\<subseteq> _")
   where "r1 \<^bold>\<subseteq> r2 \<equiv> \<forall>w. \<forall>v. (r1 w v) \<longrightarrow> (r2 w v) "
 (* Composition of 2 relations *)
 abbreviation comp_rel :: "(i\<Rightarrow>i\<Rightarrow>bool)\<Rightarrow>(i\<Rightarrow>i\<Rightarrow>bool)\<Rightarrow>(i\<Rightarrow>i\<Rightarrow>bool)"  ("_ \<^bold>\<circ> _")
   where "r1 \<^bold>\<circ> r2 \<equiv> \<lambda>w. \<lambda>v. \<exists>u.( (r1 w u) \<and> (r2 u v))"
 (* Intersection between 2 relations *)
 abbreviation intersection_rel :: "(i\<Rightarrow>i\<Rightarrow>bool)\<Rightarrow>(i\<Rightarrow>i\<Rightarrow>bool)\<Rightarrow>(i\<Rightarrow>i\<Rightarrow>bool)"  ("_ \<^bold>\<inter> _")
  where "r1 \<^bold>\<inter> r2 \<equiv> \<lambda>w. \<lambda>v. (r1 w v) \<and> (r2 w v)"
 (* Reflexive relation *)
 abbreviation reflexive 
   where "reflexive r \<equiv> (\<forall>x. r x x)"
 (* Symmetric relation *)
 abbreviation symmetric 
   where "symmetric r \<equiv> (\<forall>x y. r x y \<longrightarrow> r y x)"
 (* Transitive relation *)
 abbreviation transitive 
   where "transitive r \<equiv> (\<forall>x y z. ((r x y) \<and> (r y z) \<longrightarrow> (r x z)))"
 (* Serial relation *)
 abbreviation serial 
   where "serial r \<equiv> (\<forall>w. \<exists>v. r w v)"
 (* Inverse relation *)
 abbreviation inverse :: "(i\<Rightarrow>i\<Rightarrow>bool)\<Rightarrow>(i\<Rightarrow>i\<Rightarrow>bool)\<Rightarrow>bool"
  where "inverse r s \<equiv> \<forall>w. \<forall>v. (r w v) \<longleftrightarrow> (s v w)"

 (* Abbrevations for conditions on the relations *)
 abbreviation axC1
   where "axC1 r \<equiv> r \<^bold>\<subseteq> r_box"
 abbreviation axC2 :: "(i\<Rightarrow>i\<Rightarrow>bool)\<Rightarrow>(i\<Rightarrow>i\<Rightarrow>bool)\<Rightarrow>bool" 
   where "axC2 r s \<equiv> ( \<forall>w. \<forall>v. ((w rbox w) \<and> (v rbox v) 
                                  \<and> (w rbox v) \<and> (v rbox w))
                         \<longrightarrow> (\<exists>x. r w x \<and> s v x))"
 abbreviation axC3 :: "(i\<Rightarrow>i\<Rightarrow>bool)\<Rightarrow>(i\<Rightarrow>i\<Rightarrow>bool)\<Rightarrow>bool"
   where "axC3 r s \<equiv> (\<forall>w.\<forall>v. (w ragt v) = (r w v \<and> s w v))" 

 axiomatization where
  (* rbox is an equivalence relation between the worlds in W *)
  ax_refl_rbox: "reflexive r_box" and
  ax_sym_rbox : "symmetric r_box" and
  ax_trans_rbox : "transitive r_box" and

  (* ragt is an equivalence relation between the worlds in W *)
  ax_refl_ragt: "reflexive r_agt" and
  ax_sym_ragt: "symmetric r_agt" and
  ax_trans_ragt: "transitive r_agt" and

  (* every r is an equivalence relation between the worlds in W *)
  ax_refl_a1:  "reflexive a1" and
  ax_sym_a1: "symmetric a1" and
  ax_trans_a1:  "transitive a1" and

  ax_refl_a2:  "reflexive a2" and
  ax_sym_a2: "symmetric a2" and
  ax_trans_a2:  "transitive a2" and

  (*  rG and rH are binary relations between worlds in W  such that 
    rG is serial and transitive, 
    rH is the inverse relation of rG *)
  (* ax_ser_rG: "serial r_G" and *) 
  ax_trans_rG: "transitive r_G" and
  ax_inverse_rG_rH: "inverse r_G r_H" 


lemma True nitpick [satisfy,user_axioms,show_all,format=2] oops


lemma ax_1: "\<exists>w. w=w" by simp (* W is a nonempty set of possible worlds *)

axiomatization where
  axC1_a1: "axC1 a1" 

axiomatization where
  axC1_a2: "axC1 a2" 

axiomatization where
  axC2_a1_a2 : "axC2 a1 a2 " 

axiomatization where
  axC3_a1_a2 : "axC3 a1 a2 "

lemma True nitpick [satisfy,user_axioms,show_all] oops

axiomatization where
  ax_C4 : "\<forall>w. \<forall>v. \<forall>u. ((w rG u) \<and> (w rG v))
           \<longrightarrow> ((u rG v) \<or> (v rG u) \<or> (u=v))" 

lemma True nitpick [satisfy,user_axioms,show_all] oops

axiomatization where
  ax_C5 : "\<forall>w. \<forall>v. \<forall>u. ((w rH u) \<and> (w rH v))
           \<longrightarrow> ((u rH v) \<or> (v rH u) \<or> (u=v))" 

lemma True nitpick [satisfy,user_axioms,show_all] oops

axiomatization where
  ax_C6 : "(r_G \<^bold>\<circ> r_box) \<^bold>\<subseteq> (r_agt \<^bold>\<circ> r_G)" 

lemma True nitpick [satisfy,user_axioms,show_all] oops
lemma True nunchaku [satisfy,card=2] oops

axiomatization where
  ax_C7 : "\<forall>w.\<forall>v. (w rbox v) \<longrightarrow> \<not> (w rG v)" 

lemma True nitpick [satisfy,user_axioms,show_all] oops
(*lemma True nunchaku_params [satisfy,card=2] oops
*)

(* Consistency Check *)
 lemma True nitpick [satisfy,user_axioms] oops
(*
 lemma False sledgehammer [verbose,timeout=600] oops

lemma False sledgehammer [verbose, remote_leo2 remote_satallax]
*)

 lemma test :
   " \<lfloor> a1 cstit \<phi> \<rfloor> \<Longrightarrow> \<lfloor> (a1 dstit \<phi>) \<^bold>\<or> (\<^bold>\<box> \<phi>) \<rfloor> " 
   by blast

lemma "\<lfloor>\<phi>\<^bold>\<rightarrow>( a1 cstit \<phi>) \<rfloor>" nitpick [user_axioms,show_all,format=2] oops
lemma "\<lfloor>\<phi>\<^bold>\<rightarrow> \<^bold>\<not>( a1 cstit (\<^bold>\<not>\<phi>)) \<rfloor>" 
  using ax_refl_a1 by blast
lemma " \<lfloor>(a1 cstit \<phi>)  \<^bold>\<rightarrow> \<^bold>\<diamond>( a1 cstit \<phi> ) \<rfloor> " 
  using ax_refl_rbox by blast

(* Axioms/Laws from Horty's Book *)

(* Page 17 *)

lemma "\<lfloor>\<phi> \<^bold>\<equiv> \<psi>\<rfloor> \<Longrightarrow> \<lfloor>(a1 cstit \<phi>) \<^bold>\<equiv> (a1 cstit \<psi>)\<rfloor> " 
  by simp

lemma "\<lfloor> a1 cstit \<^bold>\<top> \<rfloor>" 
  by simp

lemma "\<lfloor> (a1 cstit (\<phi> \<^bold>\<and> \<psi>))  \<^bold>\<rightarrow> ((a1 cstit (\<phi>)) \<^bold>\<and> (a1 cstit (\<psi>))) \<rfloor> " 
  by simp

lemma "\<lfloor> ((a1 cstit (\<phi>)) \<^bold>\<and> (a1 cstit (\<psi>))) \<^bold>\<rightarrow> (a1 cstit (\<phi> \<^bold>\<and> \<psi>)) \<rfloor> " 
  by simp

(* Page 18 *)
lemma  "\<lfloor>\<^bold>\<not> (a1 dstit \<^bold>\<top>) \<rfloor>"
  by simp

(* Page 19 *)
lemma "\<lfloor> (a1 cstit \<phi>) \<^bold>\<equiv> ((a1 dstit \<phi>) \<^bold>\<or> \<^bold>\<box>\<phi>) \<rfloor>"
  using axC1_a1 by blast 

lemma "\<lfloor> (a1 dstit \<phi>) \<^bold>\<equiv> ((a1 cstit \<phi>) \<^bold>\<and> \<^bold>\<not>\<^bold>\<box>\<phi>) \<rfloor>"
  by simp

(* Dart Example page 21. Figure 2.4*)
lemma " \<lfloor>\<phi>  \<^bold>\<rightarrow> \<^bold>\<diamond>( \<phi> ) \<rfloor> " 
  using ax_refl_rbox by auto

lemma " \<lfloor> \<^bold>\<diamond>(\<phi> \<^bold>\<or> \<psi>)  \<^bold>\<rightarrow> (\<^bold>\<diamond>\<phi>) \<^bold>\<or> (\<^bold>\<diamond>\<psi>) \<rfloor> " 
  by blast
(* Do not hold *)
lemma " \<lfloor>\<phi>  \<^bold>\<rightarrow> \<^bold>\<diamond>( a1 cstit \<phi> ) \<rfloor> "
  nitpick [user_axioms,show_all] oops

lemma "\<lfloor>\<^bold>\<diamond> (a1 cstit (\<phi> \<^bold>\<or> \<psi>)) \<^bold>\<rightarrow> (\<^bold>\<diamond>(a1 cstit (\<phi>)) \<^bold>\<or> \<^bold>\<diamond>(a1 cstit (\<psi>))) \<rfloor>" 
  nitpick [user_axioms,show_all] oops

lemma  " \<lfloor> (\<phi>  \<^bold>\<rightarrow> \<^bold>\<diamond>( a1 cstit \<phi> ))  \<^bold>\<or>
 (\<^bold>\<diamond> (a1 cstit (\<phi> \<^bold>\<or> \<psi>)) \<^bold>\<rightarrow> (\<^bold>\<diamond>(a1 cstit (\<phi>)) \<^bold>\<or> \<^bold>\<diamond>(a1 cstit (\<psi>)))) \<rfloor> "
  nitpick [user_axioms,show_all] oops

(* Page 24 *)
(* Valid according to book \<rightarrow> proof found *)
lemma "\<lfloor>\<^bold>\<diamond> (a1 cstit (\<^bold>\<diamond> (a1 cstit(\<phi>)))) \<^bold>\<rightarrow> (\<^bold>\<diamond>(a1 cstit (\<phi>))) \<rfloor>"
  using axC1_a1 ax_trans_rbox by blast
(* Invalid according to book \<rightarrow> countermodel found *)
lemma "\<lfloor>\<^bold>\<diamond> (a1 cstit (F (\<^bold>\<diamond> (a1 cstit(\<phi>))))) \<^bold>\<rightarrow> (\<^bold>\<diamond>(a1 cstit (\<phi>))) \<rfloor>"
  nitpick [user_axioms,show_all] oops

(* Page 26 *)
(* Valid according to book \<rightarrow> proof found *)
lemma "\<lfloor>(a1 dstit(\<^bold>\<not>((a1 dstit \<phi>)) )) \<^bold>\<equiv> (\<^bold>\<not> (a1 dstit \<phi>) \<^bold>\<and>\<^bold>\<diamond>((a1 dstit \<phi> ))) \<rfloor> " 
  by (smt axC2_a1_a2 ax_sym_a1 ax_sym_rbox ax_trans_a1 ax_trans_rbox)
(* Page 27 *)
(* Valid according to book \<rightarrow> proof found
 but One-line proof reconstruction failed: by (smt ax_sym_a1 ax_sym_rbox ax_trans_a1 ax_trans_rbox) *)
lemma "\<lfloor>(a1 dstit \<phi>)  \<^bold>\<equiv> (a1 dstit ( \<^bold>\<not>(a1 dstit\<^bold>\<not>(a1 dstit \<phi>)))) \<rfloor> " oops

(* Page 28 *)
(* Valid according to book \<rightarrow> proof found *)
lemma "\<lfloor> (a1 dstit \<phi>) \<^bold>\<rightarrow>  \<^bold>\<diamond> (a1 dstit (\<^bold>\<not>( a1 dstit \<phi>)))\<rfloor> "
  using ax_sym_a1 ax_sym_rbox by blast
(* Valid according to book \<rightarrow> proof found *)
lemma "\<lfloor>(a1 dstit (\<^bold>\<not>( a1 dstit \<phi>))) \<^bold>\<rightarrow>  \<^bold>\<diamond> (a1 dstit \<phi>) \<rfloor> "
  by blast
(* Valid according to book \<rightarrow> proof found *)
lemma "\<lfloor>\<^bold>\<diamond>(a1 dstit \<phi>) \<^bold>\<equiv> \<^bold>\<diamond>(a1 dstit \<^bold>\<not>(a1 dstit \<phi>)) \<rfloor>"
  using ax_sym_a1 ax_sym_rbox ax_trans_rbox by blast

(* Page 29 *)
lemma "\<lfloor>\<^bold>\<not>(a1 cstit \<phi>) \<^bold>\<equiv> (a1 cstit \<^bold>\<not>(a1 cstit \<phi>)) \<rfloor>"
  using ax_refl_a1 ax_sym_a1 ax_trans_a1 by blast


(* Axioms from Lorini's Paper *)

 lemma ax_C1_and_ax_C3: 
   " \<forall>v. (w ragt v) \<longrightarrow> (w rbox v) " 
   by (simp add: axC1_a1 axC3_a1_a2)

 lemma box_implies_cstit : 
   " \<lfloor>(\<^bold>\<box> \<phi>)  \<^bold>\<rightarrow> ( a1 cstit \<phi>)\<rfloor> " 
   by (simp add: axC1_a1)
   
 lemma cstit_implies_gstit : 
   " \<lfloor>((a1 cstit \<phi>) \<^bold>\<and> (a2 cstit \<psi>) )\<^bold>\<rightarrow> (gstit (\<phi> \<^bold>\<and> \<psi>))\<rfloor> "
   by (simp add: axC3_a1_a2)

  (* \<^bold>\<diamond>(a cstit \<phi>) stands for 'agent a can see to it that \<phi> ' *)
  (* Sledgehammer times out / No countermodel by Nitpick *)
 lemma AIA:
   " \<lfloor>((\<^bold>\<diamond>(a1 cstit \<phi>)) \<^bold>\<and> (\<^bold>\<diamond>(a2 cstit \<psi>)) ) \<^bold>\<rightarrow> (\<^bold>\<diamond> ((a1 cstit \<phi>) \<^bold>\<and> (a2 cstit \<psi>) ))\<rfloor> "
   nitpick [user_axioms,show_all]  oops

 lemma conv_GH: 
  " \<lfloor>\<phi> \<^bold>\<rightarrow> (G(P \<phi>))\<rfloor> "
   using ax_inverse_rG_rH by blast

 lemma conv_HG: 
   " \<lfloor>\<phi> \<^bold>\<rightarrow> (H(F \<phi>))\<rfloor> " 
   using ax_inverse_rG_rH by blast

 lemma connected_G : 
   " \<lfloor>(P(F \<phi>)) \<^bold>\<rightarrow> ((P \<phi>) \<^bold>\<or> \<phi> \<^bold>\<or> (F \<phi>))\<rfloor> " 
   using ax_C4 ax_inverse_rG_rH by blast

 lemma connected_H : 
   " \<lfloor>(F(P \<phi>)) \<^bold>\<rightarrow> ((P \<phi>) \<^bold>\<or> \<phi> \<^bold>\<or> (F \<phi>))\<rfloor> "
   using ax_C5 ax_inverse_rG_rH by blast

 lemma NCUH : 
   " \<lfloor>(F (\<^bold>\<diamond> \<phi>)) \<^bold>\<rightarrow> (dualgstit (F \<phi>))\<rfloor> " 
   using ax_C6 by blast

 lemma MP:
   " (\<lfloor>\<phi>\<rfloor>) \<and> (\<lfloor>\<phi> \<^bold>\<rightarrow> \<psi>\<rfloor>) \<Longrightarrow>  \<lfloor>\<psi>\<rfloor> "
   by simp

 (* Countermodel found when rG is not serial *)
 lemma IRR :
   " \<lfloor>((\<^bold>\<box>(\<^bold>\<not> p)) \<^bold>\<and> (\<^bold>\<box>((G p) \<^bold>\<and> (H p)))) \<^bold>\<rightarrow> \<phi> \<rfloor> \<Longrightarrow> \<lfloor>\<phi>\<rfloor> " nitpick [user_axioms,show_all] oops

 (* 2 propositions from Lorini's Temporal STIT logic and its application to normative reasoning *)
 lemma prop1 :
   " \<lfloor>(G (\<^bold>\<diamond> (G*\<phi>))) \<^bold>\<rightarrow> (dualgstit (G \<phi>))\<rfloor> " nitpick [user_axioms,show_all] oops

 (* Countermodel found when rG is not serial *)
 lemma prop2 :
   " \<lfloor>( G (\<^bold>\<diamond> ( (G*\<phi>) \<^bold>\<and> (F* \<psi>) ) )) \<^bold>\<rightarrow> (dualgstit((G \<phi>) \<^bold>\<and> (F \<psi>)))\<rfloor> " nitpick [user_axioms,show_all] oops


 (* Axiom K for the operators: box, gstit, every cstit,  G and H *)
lemma axiomK_box: " \<lfloor>((\<^bold>\<box> \<phi>)\<^bold>\<and>(\<^bold>\<box> (\<phi>\<^bold>\<rightarrow>\<psi>)) ) \<^bold>\<rightarrow> (\<^bold>\<box> \<psi>) \<rfloor> "
  by simp 
lemma axiomK_agt: " \<lfloor>((gstit \<phi>)\<^bold>\<and>(gstit (\<phi>\<^bold>\<rightarrow>\<psi>)) ) \<^bold>\<rightarrow> (gstit \<psi>) \<rfloor> "
  by simp
lemma axiomK_cstit : " \<lfloor>((a1 cstit \<phi>)\<^bold>\<and>(a1 cstit (\<phi>\<^bold>\<rightarrow>\<psi>)) ) \<^bold>\<rightarrow> (a1 cstit \<psi>) \<rfloor> " 
  by simp
lemma axiomK_rG: " \<lfloor> ((G \<phi>) \<^bold>\<and> G(\<phi>\<^bold>\<rightarrow>\<psi>)) \<^bold>\<rightarrow> (G \<psi>) \<rfloor>  " 
  by simp
lemma axiomK_rH: " \<lfloor> ((H \<phi>) \<^bold>\<and> H(\<phi>\<^bold>\<rightarrow>\<psi>)) \<^bold>\<rightarrow> (H \<psi>) \<rfloor>  " 
  by simp

 (* Axiom D for the operator G *)
(* No longer valid when seriality is removed *)
lemma axiomD_rG: " \<lfloor> \<^bold>\<not>((G \<phi>)\<^bold>\<and>(G \<^bold>\<not>\<phi>)) \<rfloor>  "
  nitpick [user_axioms,show_all] oops
(*  using ax_ser_rG by blast *)

 (* Axiom 4 for the operators: box, gstit, every cstit and G *)
lemma axiom4_box: " \<lfloor> (\<^bold>\<box> \<phi>)  \<^bold>\<rightarrow> ( \<^bold>\<box> (\<^bold>\<box>\<phi>)) \<rfloor> " 
  using ax_trans_rbox by blast
lemma axiom4_agt: " \<lfloor> (gstit \<phi>)  \<^bold>\<rightarrow> ( gstit (gstit \<phi>)) \<rfloor> "
  using ax_trans_ragt by blast
lemma axiom4_cstit: " \<lfloor> (a1 cstit \<phi>)  \<^bold>\<rightarrow> ( a1 cstit (a1 cstit \<phi>)) \<rfloor> " 
  using ax_trans_a1 by blast 
lemma axiom4_rG: " \<lfloor> (G \<phi>) \<^bold>\<rightarrow> (G (G \<phi>)) \<rfloor>  " 
  using ax_trans_rG by blast

 (* Axiom T for the operators: box, gstit, every cstit *) 
lemma axiomT_box: " \<lfloor> (\<^bold>\<box> \<phi>)  \<^bold>\<rightarrow> (\<phi>) \<rfloor> "
  by (simp add: ax_refl_rbox)
lemma axiomT_agt: " \<lfloor> (gstit \<phi>)  \<^bold>\<rightarrow> (\<phi>) \<rfloor> " 
  by (simp add: ax_refl_ragt)
lemma  axiomT_cstit: " \<lfloor> (a1 cstit \<phi>)  \<^bold>\<rightarrow> (\<phi>) \<rfloor> "
  by (simp add: ax_refl_a1)  

 (* Axiom B for the operators: box, gstit, every cstit *)
lemma axiomB_box: " \<lfloor> \<phi>  \<^bold>\<rightarrow> (\<^bold>\<box>(\<^bold>\<not>(\<^bold>\<box>(\<^bold>\<not> \<phi>)))) \<rfloor> "
  using ax_sym_rbox by blast
lemma axiomB_agt: " \<lfloor> \<phi>  \<^bold>\<rightarrow> (gstit(\<^bold>\<not>(gstit(\<^bold>\<not> \<phi>)))) \<rfloor> " 
  using ax_sym_ragt by blast
lemma axiomB_cstit: " \<lfloor> \<phi>  \<^bold>\<rightarrow> (a1 cstit (\<^bold>\<not>(a1 cstit(\<^bold>\<not> \<phi>)))) \<rfloor> " 
  using ax_sym_a1 by blast

 (* Nec rule for the operators, box, gstit, every cstit, G and H *)
lemma Nec_box: " \<lfloor> \<phi> \<rfloor> \<Longrightarrow>  \<lfloor> (\<^bold>\<box> \<phi>) \<rfloor> "
  by simp
lemma Nec_agt: " \<lfloor> \<phi> \<rfloor> \<Longrightarrow>  \<lfloor> (gstit \<phi>) \<rfloor> "
  by simp
lemma Nec_cstit: " \<lfloor> \<phi> \<rfloor> \<Longrightarrow>  \<lfloor> (a1 cstit \<phi>) \<rfloor> " 
  by simp
lemma Nec_rG: " \<lfloor> \<phi> \<rfloor> \<Longrightarrow>  \<lfloor> (G \<phi>) \<rfloor> "
  by simp
lemma Nec_rH: " \<lfloor> \<phi> \<rfloor> \<Longrightarrow>  \<lfloor> (H \<phi>) \<rfloor> "
  by simp

lemma " \<lfloor> (a1 cstit \<phi>) \<^bold>\<or> (a2 cstit \<phi>) \<rfloor> \<Longrightarrow> \<lfloor> gstit (\<phi>) \<rfloor>" 
  using axC3_a1_a2 by blast
lemma " \<lfloor> (a1 cstit \<phi>)  \<rfloor> \<Longrightarrow> \<lfloor> gstit (\<phi>) \<rfloor>"
  using axC3_a1_a2 by blast
lemma "(( \<lfloor> (a1 cstit \<phi>) \<rfloor>) \<and> (\<lfloor>\<phi> \<^bold>\<rightarrow>\<psi>\<rfloor>)) \<Longrightarrow> \<lfloor> a1 cstit (\<psi>) \<rfloor>" 
  by simp
lemma " \<lfloor> (a1 cstit \<phi>) \<^bold>\<and> (a1 cstit \<psi>) \<rfloor> \<Longrightarrow> \<lfloor> a1 cstit (\<phi> \<^bold>\<and> \<psi>) \<rfloor>"
  by simp
lemma " \<lfloor> (a1 cstit \<phi>) \<^bold>\<and> (a2 cstit \<psi>) \<rfloor> \<Longrightarrow> \<lfloor> gstit (\<phi> \<^bold>\<and> \<psi>) \<rfloor>"
  using axC3_a1_a2 by blast
lemma " \<lfloor>gstit (\<phi> \<^bold>\<and> \<psi>) \<rfloor> \<Longrightarrow> \<lfloor> (a1 cstit \<phi>) \<^bold>\<and> (a2 cstit \<psi>) \<rfloor>"
  using axiomT_agt by blast
lemma " \<lfloor>(gstit (\<phi>))  \<^bold>\<rightarrow> ((a1 cstit \<phi>) \<^bold>\<and> (a2 cstit \<phi>)) \<rfloor>" nitpick [user_axioms,show_all] oops

(* -- Example Section -- *)

(*
(* Example from the book "Agency and deontic logic - page 30 Figure 2.5: Group Actions"
   by John F. Horty *)

consts i1::i i2::i i3::i i4::i i5::i i6::i
consts A::\<sigma>

axiomatization where
 
  diff_i1 :  "(i1 \<noteq> i2) \<and> (i1 \<noteq> i3) \<and> (i1 \<noteq> i4) \<and> (i1 \<noteq> i5) \<and> (i1 \<noteq> i6)" and
  diff_i2 :  "(i2 \<noteq> i1) \<and> (i2 \<noteq> i3) \<and> (i2 \<noteq> i4) \<and> (i2 \<noteq> i5) \<and> (i2 \<noteq> i6)" and
  diff_i3 :  "(i3 \<noteq> i1) \<and> (i3 \<noteq> i2) \<and> (i3 \<noteq> i4) \<and> (i3 \<noteq> i5) \<and> (i3 \<noteq> i6)" and
  diff_i4 :  "(i4 \<noteq> i1) \<and> (i4 \<noteq> i2) \<and> (i4 \<noteq> i3) \<and> (i4 \<noteq> i5) \<and> (i4 \<noteq> i6)" and
  diff_i5 :  "(i5 \<noteq> i1) \<and> (i5 \<noteq> i2) \<and> (i5 \<noteq> i3) \<and> (i5 \<noteq> i4) \<and> (i5 \<noteq> i6)" and
  diff_i6 :  "(i6 \<noteq> i1) \<and> (i6 \<noteq> i2) \<and> (i6 \<noteq> i3) \<and> (i6 \<noteq> i4) \<and> (i6 \<noteq> i5)" and

  rbox_i1 : "(i1 rbox i1) \<and> (i1 rbox i2) \<and> (i1 rbox i3) \<and> (i1 rbox i4)
           \<and> (i1 rbox i5) \<and> (i1 rbox i6)" and

  no_rG : " (\<forall>w. \<forall> v.  \<not>(w rG v)) " and

  rAgt_i1 : "(i1 ragt i1) \<and> (\<forall>w. (w \<noteq> i1) \<longrightarrow> \<not>(i1 ragt w))" and
  rAgt_i2 : "(i2 ragt i2) \<and> (i2 ragt i3) \<and> (\<forall>w. ((w \<noteq> i2) \<and> (w \<noteq> i3)) \<longrightarrow> \<not>(i2 ragt w))" and
  rAgt_i3 : "(i3 ragt i3) \<and> (i3 ragt i2) \<and> (\<forall>w. ((w \<noteq> i2) \<and> (w \<noteq> i3)) \<longrightarrow> \<not>(i3 ragt w))" and
  rAgt_i4 : "(i4 ragt i4) \<and> (\<forall>w. (w \<noteq> i4) \<longrightarrow> \<not>(i4 ragt w))" and
  rAgt_i5 : "(i5 ragt i5) \<and> (i5 ragt i6) \<and> (\<forall>w. ((w \<noteq> i5) \<and> (w \<noteq> i6)) \<longrightarrow> \<not>(i5 ragt w))" and
  rAgt_i6 : "(i6 ragt i6) \<and> (i6 ragt i5) \<and> (\<forall>w. ((w \<noteq> i5) \<and> (w \<noteq> i6)) \<longrightarrow> \<not>(i6 ragt w))" and

  a1_i1 : "(a1 i1 i1) \<and> (a1 i1 i2) \<and> (a1 i1 i3)
        \<and> (\<forall>w. ((w \<noteq> i1) \<and> (w \<noteq> i2) \<and> (w \<noteq> i3)) \<longrightarrow> \<not>(a1 i1 w))" and
  a2_i1 : "(a2 i1 i1) \<and> (a2 i1 i5) \<and> (a2 i1 i6) 
        \<and> (\<forall>w. ((w \<noteq> i1) \<and> (w \<noteq> i5) \<and> (w \<noteq> i6)) \<longrightarrow> \<not>(a2 i1 w))" and
  a1_i2 : "(a1 i2 i2) \<and> (a1 i2 i1) \<and> (a1 i2 i3)
        \<and> (\<forall>w. ((w \<noteq> i1) \<and> (w \<noteq> i2) \<and> (w \<noteq> i3)) \<longrightarrow> \<not>(a1 i2 w))" and
  a2_i2 : "(a2 i2 i2) \<and> (a2 i2 i3) \<and> (a2 i2 i4) 
        \<and> (\<forall>w. ((w \<noteq> i2) \<and> (w \<noteq> i3) \<and> (w \<noteq> i4)) \<longrightarrow> \<not>(a2 i2 w))" and
  a1_i3 : "(a1 i3 i3) \<and> (a1 i3 i1) \<and> (a1 i3 i2)
        \<and> (\<forall>w. ((w \<noteq> i1) \<and> (w \<noteq> i2) \<and> (w \<noteq> i3)) \<longrightarrow> \<not>(a1 i3 w))" and
  a2_i3 : "(a2 i3 i3) \<and> (a2 i3 i2) \<and> (a2 i3 i4)
        \<and> (\<forall>w. ((w \<noteq> i2) \<and> (w \<noteq> i3) \<and> (w \<noteq> i4)) \<longrightarrow> \<not>(a2 i3 w))" and
  a1_i4 : "(a1 i4 i4) \<and> (a1 i4 i5) \<and> (a1 i4 i6)
        \<and> (\<forall>w. ((w \<noteq> i4) \<and> (w \<noteq> i5) \<and> (w \<noteq> i6)) \<longrightarrow> \<not>(a1 i4 w))" and
  a2_i4 : "(a2 i4 i4) \<and> (a2 i4 i2) \<and> (a2 i4 i3)
        \<and> (\<forall>w. ((w \<noteq> i2) \<and> (w \<noteq> i3) \<and> (w \<noteq> i4)) \<longrightarrow> \<not>(a2 i4 w))" and
  a1_i5 : "(a1 i5 i5) \<and> (a1 i5 i4) \<and> (a1 i5 i6)
        \<and> (\<forall>w. ((w \<noteq> i4) \<and> (w \<noteq> i5) \<and> (w \<noteq> i6)) \<longrightarrow> \<not>(a1 i5 w))" and
  a2_i5 : "(a2 i5 i5) \<and> (a2 i5 i1) \<and> (a2 i5 i6)  
        \<and> (\<forall>w. ((w \<noteq> i1) \<and> (w \<noteq> i5) \<and> (w \<noteq> i6)) \<longrightarrow> \<not>(a2 i5 w))" and
  a1_i6 : "(a1 i6 i6) \<and> (a1 i6 i4) \<and> (a1 i6 i5)
        \<and> (\<forall>w. ((w \<noteq> i4) \<and> (w \<noteq> i5) \<and> (w \<noteq> i6)) \<longrightarrow> \<not>(a1 i6 w))" and
  a2_i6 : "(a2 i6 i6) \<and> (a2 i6 i1) \<and> (a2 i6 i5) 
        \<and> (\<forall>w. ((w \<noteq> i1) \<and> (w \<noteq> i5) \<and> (w \<noteq> i6)) \<longrightarrow> \<not>(a2 i6 w))" and

  i1_holds : " (\<not>A i1) " and
  i2_holds : " (A i2)  " and
  i3_holds : " (A i3)  " and
  i4_holds : " (\<not>A i4) " and
  i5_holds : " (\<not>A i5) " and
  i6_holds : " (A i6)  " and

  actual_w : "aw = i2" 

lemma  " \<lfloor>\<^bold>\<not>(\<^bold>\<diamond>( a1 cstit A)) \<rfloor>\<^sub>l "
 nitpick [satisfy,user_axioms,show_all,format=2] 
 by (metis a1_i2 a1_i3 a2_i2 actual_w axC2_a1_a2 ax_sym_rbox ax_trans_a1 ax_trans_rbox i1_holds i4_holds)

lemma  " \<lfloor>\<^bold>\<not>(\<^bold>\<diamond>( a2 cstit A)) \<rfloor>\<^sub>l " 
  nitpick [satisfy,user_axioms,show_all,format=2] 
  by (metis a1_i2 a2_i2 a2_i3 actual_w axC2_a1_a2 ax_sym_rbox ax_trans_a2 ax_trans_rbox i1_holds i4_holds)

lemma  " \<lfloor> \<^bold>\<diamond>( gstit A) \<rfloor>\<^sub>l " 
  nitpick [satisfy,user_axioms,show_all,format=2] 
  by (metis a1_i2 actual_w axC1_a1 i2_holds i3_holds rAgt_i2)


axiomatization where
  limit : "\<forall>w. (w = i1) \<or> (w = i2) \<or> (w = i3) \<or> (w = i4) \<or> (w = i5) \<or> (w = i6)" 

lemma  " \<lfloor>\<^bold>\<not>(\<^bold>\<diamond>( a1 cstit A)) \<rfloor> " sledgehammer
 nitpick [user_axioms,show_all,format=2] 
 by (metis (full_types) a1_i1 a1_i2 a1_i3 a1_i4 a1_i5 a1_i6 i1_holds i4_holds limit)

lemma  " \<lfloor>\<^bold>\<not>(\<^bold>\<diamond>( a2 cstit A)) \<rfloor> "
  nitpick [satisfy,user_axioms,show_all,format=2] 
  by (metis (full_types) a2_i1 a2_i2 a2_i3 a2_i4 a2_i5 a2_i6 i1_holds i4_holds limit)

lemma  " \<lfloor> \<^bold>\<diamond>( gstit A) \<rfloor> " 
  nitpick [satisfy,user_axioms,show_all,format=2] 
  by (smt ax_sym_rbox ax_trans_rbox i2_holds i3_holds limit rAgt_i2 rbox_i1)

*)




(*

(* 
   Example from the paper "Temporal STIT logic and its application to normative reasoning"
   Finite version of it.
   This model fulfills: C1, C2, C3, C4 and C5. 
   Without seriality on RG - all 7 constraints are fulfilled.
 *)


consts i1::i i2::i i3::i i4::i i5::i i6::i i7::i i8::i i9::i i10::i i11::i i12::i i13::i i14::i i15::i i16::i
consts p::\<sigma> q::\<sigma> 

axiomatization where 
 actual_wa : "aw = i1" and

 diff_i1a :  "(i1 \<noteq> i2) \<and> (i1 \<noteq> i3) \<and> (i1 \<noteq> i4) \<and> (i1 \<noteq> i5) \<and> (i1 \<noteq> i6)
             \<and> (i1 \<noteq> i7) \<and> (i1 \<noteq> i8) \<and> (i1 \<noteq> i9) \<and> (i1 \<noteq> i10)
             \<and> (i1 \<noteq> i11) \<and> (i1 \<noteq> i12) \<and> (i1 \<noteq> i13) \<and> (i1 \<noteq> i14) \<and> (i1 \<noteq> i15) \<and> (i1 \<noteq> i16)" and
 diff_i2a :  "(i2 \<noteq> i1) \<and> (i2 \<noteq> i3) \<and> (i2 \<noteq> i4) \<and> (i2 \<noteq> i5) \<and> (i2 \<noteq> i6)
             \<and> (i2 \<noteq> i7) \<and> (i2 \<noteq> i8) \<and> (i2 \<noteq> i9) \<and> (i2 \<noteq> i10)
             \<and> (i2  \<noteq> i11) \<and> (i2 \<noteq> i12) \<and> (i2 \<noteq> i13) \<and> (i2 \<noteq> i14) \<and> (i2 \<noteq> i15) \<and> (i2 \<noteq> i16)" and
 diff_i3a :  "(i3 \<noteq> i1) \<and> (i3 \<noteq> i2) \<and> (i3 \<noteq> i4) \<and> (i3 \<noteq> i5) \<and> (i3 \<noteq> i6)
             \<and> (i3 \<noteq> i7) \<and> (i3 \<noteq> i8) \<and> (i3 \<noteq> i9) \<and> (i3 \<noteq> i10)
             \<and> (i3 \<noteq> i11) \<and> (i3 \<noteq> i12) \<and> (i3 \<noteq> i13) \<and> (i3 \<noteq> i14) \<and> (i3 \<noteq> i15) \<and> (i3 \<noteq> i16)" and
 diff_i4a :  "(i4 \<noteq> i1) \<and> (i4 \<noteq> i2) \<and> (i4 \<noteq> i3) \<and> (i4 \<noteq> i5) \<and> (i4 \<noteq> i6)
             \<and> (i4 \<noteq> i7) \<and> (i4 \<noteq> i8) \<and> (i4 \<noteq> i9) \<and> (i4 \<noteq> i10)
             \<and> (i4 \<noteq> i11) \<and> (i4 \<noteq> i12) \<and> (i4 \<noteq> i13) \<and> (i4 \<noteq> i14) \<and> (i4 \<noteq> i15) \<and> (i4 \<noteq> i16)" and
 diff_i5a :  "(i5 \<noteq> i1) \<and> (i5 \<noteq> i2) \<and> (i5 \<noteq> i3) \<and> (i5 \<noteq> i4) \<and> (i5 \<noteq> i6)
             \<and> (i5 \<noteq> i7) \<and> (i5 \<noteq> i8) \<and> (i5 \<noteq> i9) \<and> (i5 \<noteq> i10)
             \<and> (i5 \<noteq> i11) \<and> (i5 \<noteq> i12) \<and> (i5 \<noteq> i13) \<and> (i5 \<noteq> i14) \<and> (i5 \<noteq> i15) \<and> (i5 \<noteq> i16)" and
 diff_i6a :  "(i6 \<noteq> i1) \<and> (i6 \<noteq> i2) \<and> (i6 \<noteq> i3) \<and> (i6 \<noteq> i4) \<and> (i6 \<noteq> i5)
             \<and> (i6 \<noteq> i7) \<and> (i6 \<noteq> i8) \<and> (i6 \<noteq> i9) \<and> (i6 \<noteq> i10)
             \<and> (i6 \<noteq> i11) \<and> (i6 \<noteq> i12) \<and> (i6 \<noteq> i13) \<and> (i6 \<noteq> i14) \<and> (i6 \<noteq> i15) \<and> (i6 \<noteq> i16)" and
 diff_i7a :  "(i7 \<noteq> i1) \<and> (i7 \<noteq> i2) \<and> (i7 \<noteq> i3) \<and> (i7 \<noteq> i4) \<and> (i7 \<noteq> i5)
             \<and> (i7 \<noteq> i6) \<and> (i7 \<noteq> i8) \<and> (i7 \<noteq> i9) \<and> (i7 \<noteq> i10)
             \<and> (i7 \<noteq> i11) \<and> (i7 \<noteq> i12) \<and> (i7 \<noteq> i13) \<and> (i7 \<noteq> i14) \<and> (i7 \<noteq> i15) \<and> (i7 \<noteq> i16)" and
 diff_i8a :  "(i8 \<noteq> i1) \<and> (i8 \<noteq> i2) \<and> (i8 \<noteq> i3) \<and> (i8 \<noteq> i4) \<and> (i8 \<noteq> i5)
             \<and> (i8 \<noteq> i6) \<and> (i8 \<noteq> i7) \<and> (i8 \<noteq> i9) \<and> (i8 \<noteq> i10)
             \<and> (i8 \<noteq> i11) \<and> (i8 \<noteq> i12) \<and> (i8 \<noteq> i13) \<and> (i8 \<noteq> i14) \<and> (i8 \<noteq> i15) \<and> (i8 \<noteq> i16)" and
 diff_i9a :  "(i9 \<noteq> i1) \<and> (i9 \<noteq> i2) \<and> (i9 \<noteq> i3) \<and> (i9 \<noteq> i4) \<and> (i9 \<noteq> i5)
            \<and> (i9 \<noteq> i6) \<and> (i9 \<noteq> i7) \<and> (i9 \<noteq> i8) \<and> (i9 \<noteq> i10)
            \<and> (i9 \<noteq> i11) \<and> (i9 \<noteq> i12) \<and> (i9 \<noteq> i13) \<and> (i9 \<noteq> i14)  \<and> (i9 \<noteq> i15) \<and> (i9 \<noteq> i16)" and
 diff_i10a :  "(i10 \<noteq> i1) \<and> (i10 \<noteq> i2) \<and> (i10 \<noteq> i3) \<and> (i10 \<noteq> i4) \<and> (i10 \<noteq> i5)
             \<and> (i10 \<noteq> i6) \<and> (i10 \<noteq> i7) \<and> (i10 \<noteq> i8) \<and> (i10 \<noteq> i9)
             \<and> (i10 \<noteq> i11) \<and> (i10 \<noteq> i12) \<and> (i10 \<noteq> i13) \<and> (i10 \<noteq> i14) \<and> (i10 \<noteq> i15) \<and> (i10 \<noteq> i16)" and
 diff_i11a :  "(i11 \<noteq> i1) \<and> (i11 \<noteq> i2) \<and> (i11 \<noteq> i3) \<and> (i11 \<noteq> i4) \<and> (i11 \<noteq> i5)
             \<and> (i11 \<noteq> i6) \<and> (i11 \<noteq> i7) \<and> (i11 \<noteq> i8) \<and> (i11 \<noteq> i9)
             \<and> (i11 \<noteq> i10) \<and> (i11 \<noteq> i12) \<and> (i11 \<noteq> i13) \<and> (i11 \<noteq> i14) \<and> (i11 \<noteq> i15) \<and> (i11 \<noteq> i16)" and
 diff_i12a :  "(i12 \<noteq> i1) \<and> (i12 \<noteq> i2) \<and> (i12 \<noteq> i3) \<and> (i12 \<noteq> i4) \<and> (i12 \<noteq> i5)
             \<and> (i12 \<noteq> i6) \<and> (i12 \<noteq> i7) \<and> (i12 \<noteq> i8) \<and> (i12 \<noteq> i9)
             \<and> (i12 \<noteq> i10) \<and> (i12 \<noteq> i11) \<and> (i12 \<noteq> i13) \<and> (i12 \<noteq> i14) \<and> (i12 \<noteq> i15) \<and> (i12 \<noteq> i16)" and
 diff_i13a :  "(i13 \<noteq> i1) \<and> (i13 \<noteq> i2) \<and> (i13 \<noteq> i3) \<and> (i13 \<noteq> i4) \<and> (i13 \<noteq> i5)
             \<and> (i13 \<noteq> i6) \<and> (i13 \<noteq> i7) \<and> (i13 \<noteq> i8) \<and> (i13 \<noteq> i9)
             \<and> (i13 \<noteq> i10) \<and> (i13 \<noteq> i11) \<and> (i13 \<noteq> i12) \<and> (i13 \<noteq> i14) \<and> (i13 \<noteq> i15) \<and> (i13 \<noteq> i16)" and
 diff_i14a :  "(i14 \<noteq> i1) \<and> (i14 \<noteq> i2) \<and> (i14 \<noteq> i3) \<and> (i14 \<noteq> i4) \<and> (i14 \<noteq> i5)
             \<and> (i14 \<noteq> i6) \<and> (i14 \<noteq> i7) \<and> (i14 \<noteq> i8) \<and> (i14 \<noteq> i9)
             \<and> (i14 \<noteq> i10) \<and> (i14 \<noteq> i11) \<and> (i14 \<noteq> i12) \<and> (i14 \<noteq> i13) \<and> (i14 \<noteq> i15) \<and> (i14 \<noteq> i16)" and
 diff_i15a :  "(i15 \<noteq> i1) \<and> (i15 \<noteq> i2) \<and> (i15 \<noteq> i3) \<and> (i15 \<noteq> i4) \<and> (i15 \<noteq> i5)
             \<and> (i15 \<noteq> i6) \<and> (i15 \<noteq> i7) \<and> (i15 \<noteq> i8) \<and> (i15 \<noteq> i9)
             \<and> (i15 \<noteq> i10) \<and> (i15 \<noteq> i11) \<and> (i15 \<noteq> i12) \<and> (i15 \<noteq> i13) \<and> (i15 \<noteq> i14) \<and> (i15 \<noteq> i16)" and
 diff_i16a :  "(i16 \<noteq> i1) \<and> (i16 \<noteq> i2) \<and> (i16 \<noteq> i3) \<and> (i16 \<noteq> i4) \<and> (i16 \<noteq> i5)
             \<and> (i16 \<noteq> i6) \<and> (i16 \<noteq> i7) \<and> (i16 \<noteq> i8) \<and> (i16 \<noteq> i9)
             \<and> (i16 \<noteq> i10) \<and> (i16 \<noteq> i11) \<and> (i16 \<noteq> i12) \<and> (i16 \<noteq> i13) \<and> (i16 \<noteq> i14) \<and> (i16 \<noteq> i15)" and

 rbox_i1a : "(i1 rbox i1) \<and> (i1 rbox i2) \<and> (i1 rbox i3) \<and> (i1 rbox i4)
           \<and> (i1 rbox i5) \<and> (i1 rbox i6) \<and>  (i1 rbox i7) \<and> (i1 rbox i8)
           \<and> \<not>(i1 rbox i9)  \<and> \<not>(i1 rbox i10) \<and> \<not>(i1 rbox i11) \<and> \<not>(i1 rbox i12)
           \<and> \<not>(i1 rbox i13) \<and> \<not>(i1 rbox i14) \<and> \<not>(i1 rbox i15) \<and> \<not>(i1 rbox i16)" and
 rbox_i9a : "(i9 rbox i9) \<and> (i9 rbox i10)
           \<and> (\<forall>w. ((w \<noteq> i9) \<and> (w \<noteq> i10)) \<longrightarrow> \<not>(i9 rbox w))" and
 rbox_i11a : "(i11 rbox i11) \<and> (i11 rbox i12)           
           \<and> (\<forall>w. ((w \<noteq> i11) \<and> (w \<noteq> i12)) \<longrightarrow> \<not>(i11 rbox w))" and
 rbox_i13a : "(i13 rbox i13) \<and> (i13 rbox i14)           
           \<and> (\<forall>w. ((w \<noteq> i13) \<and> (w \<noteq> i14)) \<longrightarrow> \<not>(i13 rbox w))" and
 rbox_i15a : "(i15 rbox i15) \<and> (i15 rbox i16)           
           \<and> (\<forall>w. ((w \<noteq> i15) \<and> (w \<noteq> i16)) \<longrightarrow> \<not>(i15 rbox w))" and

 rG_i1a : " (i1 rG i9) \<and> (\<forall> w.  (w \<noteq> i9) \<longrightarrow> \<not>(i1 rG w)) " and
 rG_i2a : " (i2 rG i10) \<and> (\<forall> w.  (w \<noteq> i10) \<longrightarrow> \<not>(i2 rG w)) " and
 rG_i3a : " (i3 rG i11) \<and> (\<forall> w.  (w \<noteq> i11) \<longrightarrow> \<not>(i3 rG w)) " and
 rG_i4a : " (i4 rG i12) \<and> (\<forall> w.  (w \<noteq> i12) \<longrightarrow> \<not>(i4 rG w)) " and
 rG_i5a : " (i5 rG i13) \<and> (\<forall> w.  (w \<noteq> i13) \<longrightarrow> \<not>(i5 rG w)) " and
 rG_i6a : " (i6 rG i14) \<and> (\<forall> w.  (w \<noteq> i14) \<longrightarrow> \<not>(i6 rG w)) " and
 rG_i7a : " (i7 rG i15) \<and> (\<forall> w.  (w \<noteq> i15) \<longrightarrow> \<not>(i7 rG w)) " and
 rG_i8a : " (i8 rG i16) \<and> (\<forall> w.  (w \<noteq> i16) \<longrightarrow> \<not>(i8 rG w)) " and
 rG_i9a : " (\<forall> w.  \<not>(i9 rG w)) " and
 rG_i10a : "(\<forall> w.  \<not>(i10 rG w)) " and
 rG_i11a : "(\<forall> w.  \<not>(i11 rG w)) " and
 rG_i12a : "(\<forall> w.  \<not>(i12 rG w)) " and
 rG_i13a : "(\<forall> w.  \<not>(i13 rG w)) " and
 rG_i14a : "(\<forall> w.  \<not>(i14 rG w)) " and
 rG_i15a : "(\<forall> w.  \<not>(i15 rG w)) " and
 rG_i16a : "(\<forall> w.  \<not>(i16 rG w)) " and

 rAgt_i1a : "(i1 ragt i1) \<and> (i1 ragt i2) \<and> (\<forall>w. ((w \<noteq> i1) \<and> (w \<noteq> i2)) \<longrightarrow> \<not>(i1 ragt w))" and
 rAgt_i2a : "(i2 ragt i2) \<and> (i2 ragt i1) \<and> (\<forall>w. ((w \<noteq> i1) \<and> (w \<noteq> i2)) \<longrightarrow> \<not>(i2 ragt w))" and
 rAgt_i3a : "(i3 ragt i3) \<and> (i3 ragt i4) \<and> (\<forall>w. ((w \<noteq> i3) \<and> (w \<noteq> i4)) \<longrightarrow> \<not>(i3 ragt w))" and
 rAgt_i4a : "(i4 ragt i4) \<and> (i4 ragt i3) \<and> (\<forall>w. ((w \<noteq> i3) \<and> (w \<noteq> i4)) \<longrightarrow> \<not>(i4 ragt w))" and
 rAgt_i5a : "(i5 ragt i5) \<and> (i5 ragt i6) \<and> (\<forall>w. ((w \<noteq> i5) \<and> (w \<noteq> i6)) \<longrightarrow> \<not>(i5 ragt w))" and
 rAgt_i6a : "(i6 ragt i6) \<and> (i6 ragt i5) \<and> (\<forall>w. ((w \<noteq> i5) \<and> (w \<noteq> i6)) \<longrightarrow> \<not>(i6 ragt w))" and
 rAgt_i7a : "(i7 ragt i7) \<and> (i7 ragt i8) \<and> (\<forall>w. ((w \<noteq> i7) \<and> (w \<noteq> i8)) \<longrightarrow> \<not>(i7 ragt w))" and
 rAgt_i8a : "(i8 ragt i8) \<and> (i8 ragt i7) \<and> (\<forall>w. ((w \<noteq> i7) \<and> (w \<noteq> i8)) \<longrightarrow> \<not>(i8 ragt w))" and
 rAgt_i9a : "(i9 ragt i9) \<and> (\<forall>w. (w \<noteq> i9) \<longrightarrow> \<not>(i9 ragt w))" and
 rAgt_i10a : "(i10 ragt i10) \<and> (\<forall>w. (w \<noteq> i10) \<longrightarrow> \<not>(i10 ragt w))" and
 rAgt_i11a : "(i11 ragt i11) \<and> (\<forall>w. (w \<noteq> i11) \<longrightarrow> \<not>(i11 ragt w))" and
 rAgt_i12a : "(i12 ragt i12) \<and> (\<forall>w. (w \<noteq> i12) \<longrightarrow> \<not>(i12 ragt w))" and
 rAgt_i13a : "(i13 ragt i13) \<and> (\<forall>w. (w \<noteq> i13) \<longrightarrow> \<not>(i13 ragt w))" and
 rAgt_i14a : "(i14 ragt i14) \<and> (\<forall>w. (w \<noteq> i14) \<longrightarrow> \<not>(i14 ragt w))" and
 rAgt_i15a : "(i15 ragt i15) \<and> (\<forall>w. (w \<noteq> i15) \<longrightarrow> \<not>(i15 ragt w))" and
 rAgt_i16a : "(i16 ragt i16) \<and> (\<forall>w. (w \<noteq> i16) \<longrightarrow> \<not>(i16 ragt w))" and

 a1_i1a : "(a1 i1 i1) \<and> (a1 i1 i2) \<and> (a1 i1 i5) \<and> (a1 i1 i6)
        \<and> (\<forall>w. ((w \<noteq> i1) \<and> (w \<noteq> i2) \<and> (w \<noteq> i5) \<and> (w \<noteq> i6)) \<longrightarrow> \<not>(a1 i1 w))" and
 a2_i1a : "(a2 i1 i1) \<and> (a2 i1 i2) \<and> (a2 i1 i3) \<and> (a2 i1 i4)
        \<and> (\<forall>w. ((w \<noteq> i1) \<and> (w \<noteq> i2) \<and> (w \<noteq> i3) \<and> (w \<noteq> i4)) \<longrightarrow> \<not>(a2 i1 w))" and
 a1_i2a : "(a1 i2 i2) \<and> (a1 i2 i1) \<and> (a1 i2 i5) \<and> (a1 i2 i6)
        \<and> (\<forall>w. ((w \<noteq> i1) \<and> (w \<noteq> i2) \<and> (w \<noteq> i5) \<and> (w \<noteq> i6)) \<longrightarrow> \<not>(a1 i2 w))" and
 a2_i2a : "(a2 i2 i2) \<and> (a2 i2 i1) \<and> (a2 i2 i3) \<and> (a2 i2 i4)
        \<and> (\<forall>w. ((w \<noteq> i1) \<and> (w \<noteq> i2) \<and> (w \<noteq> i3) \<and> (w \<noteq> i4)) \<longrightarrow> \<not>(a2 i2 w))" and
 a1_i3a : "(a1 i3 i3) \<and> (a1 i3 i4) \<and> (a1 i3 i7) \<and> (a1 i3 i8)
        \<and> (\<forall>w. ((w \<noteq> i3) \<and> (w \<noteq> i4) \<and> (w \<noteq> i7) \<and> (w \<noteq> i8)) \<longrightarrow> \<not>(a1 i3 w))" and
 a2_i3a : "(a2 i3 i3) \<and> (a2 i3 i1) \<and> (a2 i3 i2) \<and> (a2 i3 i4)
        \<and> (\<forall>w. ((w \<noteq> i1) \<and> (w \<noteq> i2) \<and> (w \<noteq> i3) \<and> (w \<noteq> i4)) \<longrightarrow> \<not>(a2 i3 w))" and
 a1_i4a : "(a1 i4 i4) \<and> (a1 i4 i3) \<and> (a1 i4 i7) \<and> (a1 i4 i8)
        \<and> (\<forall>w. ((w \<noteq> i3) \<and> (w \<noteq> i4) \<and> (w \<noteq> i7) \<and> (w \<noteq> i8)) \<longrightarrow> \<not>(a1 i4 w))" and
 a2_i4a : "(a2 i4 i4) \<and> (a2 i4 i1) \<and> (a2 i4 i2) \<and> (a2 i4 i3)
        \<and> (\<forall>w. ((w \<noteq> i1) \<and> (w \<noteq> i2) \<and> (w \<noteq> i3) \<and> (w \<noteq> i4)) \<longrightarrow> \<not>(a2 i4 w))" and
 a1_i5a : "(a1 i5 i5) \<and> (a1 i5 i1) \<and> (a1 i5 i2) \<and> (a1 i5 i6)
        \<and> (\<forall>w. ((w \<noteq> i1) \<and> (w \<noteq> i2) \<and> (w \<noteq> i5) \<and> (w \<noteq> i6)) \<longrightarrow> \<not>(a1 i5 w))" and
 a2_i5a : "(a2 i5 i5) \<and> (a2 i5 i6) \<and> (a2 i5 i7) \<and> (a2 i5 i8)
        \<and> (\<forall>w. ((w \<noteq> i5) \<and> (w \<noteq> i6) \<and> (w \<noteq> i7) \<and>(w \<noteq> i8)) \<longrightarrow> \<not>(a2 i5 w))" and
 a1_i6a : "(a1 i6 i6) \<and> (a1 i6 i1) \<and> (a1 i6 i2) \<and> (a1 i6 i5)
        \<and> (\<forall>w. ((w \<noteq> i1) \<and> (w \<noteq> i2) \<and> (w \<noteq> i5) \<and> (w \<noteq> i6)) \<longrightarrow> \<not>(a1 i6 w))" and
 a2_i6a : "(a2 i6 i6) \<and> (a2 i6 i5) \<and> (a2 i6 i7) \<and> (a2 i6 i8)
        \<and> (\<forall>w. ((w \<noteq> i5) \<and> (w \<noteq> i6) \<and> (w \<noteq> i7) \<and> (w \<noteq> i8)) \<longrightarrow> \<not>(a2 i6 w))" and
 a1_i7a : "(a1 i7 i7) \<and> (a1 i7 i3) \<and> (a1 i7 i4) \<and> (a1 i7 i8)
        \<and> (\<forall>w. ((w \<noteq> i3) \<and> (w \<noteq> i4) \<and> (w \<noteq> i7) \<and> (w \<noteq> i8)) \<longrightarrow> \<not>(a1 i7 w))" and
 a2_i7a : "(a2 i7 i7) \<and> (a2 i7 i5) \<and> (a2 i7 i6) \<and> (a2 i7 i8)
        \<and> (\<forall>w. ((w \<noteq> i5) \<and> (w \<noteq> i6) \<and> (w \<noteq> i7) \<and> (w \<noteq> i8)) \<longrightarrow> \<not>(a2 i7 w))" and
 a1_i8a : "(a1 i8 i8) \<and> (a1 i8 i3) \<and> (a1 i8 i4) \<and> (a1 i8 i7)
        \<and> (\<forall>w. ((w \<noteq> i3) \<and> (w \<noteq> i4) \<and> (w \<noteq> i7) \<and> (w \<noteq> i8)) \<longrightarrow> \<not>(a1 i8 w))" and
 a2_i8a : "(a2 i8 i8) \<and> (a2 i8 i5) \<and> (a2 i8 i6) \<and> (a2 i8 i7)
        \<and> (\<forall>w. ((w \<noteq> i5) \<and> (w \<noteq> i6) \<and> (w \<noteq> i7) \<and> (w \<noteq> i8)) \<longrightarrow> \<not>(a2 i8 w))" and
 a1_i9a : "(a1 i9 i9) \<and> (\<forall>w. (w \<noteq> i9) \<longrightarrow> \<not>(a1 i9 w))" and
 a2_i9a : "(a2 i9 i9) \<and> (a2 i9 i10) \<and>  (\<forall>w. ((w \<noteq> i9) \<and> (w \<noteq> i10)) \<longrightarrow> \<not>(a2 i9 w))" and
 a1_i10a : "(a1 i10 i10) \<and> (\<forall>w. (w \<noteq> i10) \<longrightarrow> \<not>(a1 i10 w))" and
 a2_i10a : "(a2 i10 i10) \<and> (a2 i10 i9) \<and> (\<forall>w. ((w \<noteq> i9) \<and> (w \<noteq> i10)) \<longrightarrow> \<not>(a2 i10 w))" and
 a1_i11a : "(a1 i11 i11) \<and> (\<forall>w. (w \<noteq> i11) \<longrightarrow> \<not>(a1 i11 w))" and
 a2_i11a : "(a2 i11 i11) \<and> (a2 i11 i12) \<and> (\<forall>w. ((w \<noteq> i11) \<and> (w \<noteq> i12)) \<longrightarrow> \<not>(a2 i11 w))" and
 a1_i12a : "(a1 i12 i12) \<and> (\<forall>w. (w \<noteq> i12) \<longrightarrow> \<not>(a1 i12 w))" and
 a2_i12a : "(a2 i12 i12) \<and> (a2 i12 i11) \<and> (\<forall>w. ((w \<noteq> i11) \<and> (w \<noteq> i12)) \<longrightarrow> \<not>(a2 i12 w))" and
 a1_i13a : "(a1 i13 i13) \<and> (\<forall>w. (w \<noteq> i13) \<longrightarrow> \<not>(a1 i13 w))" and
 a2_i13a : "(a2 i13 i13) \<and> (a2 i13 i14) \<and> (\<forall>w. ((w \<noteq> i13) \<and> (w \<noteq> i14)) \<longrightarrow> \<not>(a2 i13 w))" and
 a1_i14a : "(a1 i14 i14) \<and> (\<forall>w. (w \<noteq> i14) \<longrightarrow> \<not>(a1 i14 w))" and
 a2_i14a : "(a2 i14 i14) \<and> (a2 i14 i13) \<and> (\<forall>w. ((w \<noteq> i13) \<and> (w \<noteq> i14)) \<longrightarrow> \<not>(a2 i14 w))" and
 a1_i15a : "(a1 i15 i15) \<and> (\<forall>w. (w \<noteq> i15) \<longrightarrow> \<not>(a1 i15 w))" and
 a2_i15a : "(a2 i15 i15) \<and> (a2 i15 i16) \<and> (\<forall>w. ((w \<noteq> i15) \<and> (w \<noteq> i16)) \<longrightarrow> \<not>(a2 i15 w))" and
 a1_i16a : "(a1 i16 i16) \<and> (\<forall>w. (w \<noteq> i16) \<longrightarrow> \<not>(a1 i16 w))" and
 a2_i16a : "(a2 i16 i16) \<and> (a2 i16 i15) \<and> (\<forall>w. ((w \<noteq> i15) \<and> (w \<noteq> i16)) \<longrightarrow> \<not>(a2 i16 w))" and

 i1_holds_a : " (p i1) \<and> (\<not>q i1) " and
 i2_holds_a : " (p i2) \<and> (\<not>q i2) " and
 i3_holds_a : " (p i3) \<and> (\<not>q i3) " and
 i4_holds_a : " (p i4) \<and> (\<not>q i4) " and
 i5_holds_a : " (\<not>p i5) \<and> (q i5) " and
 i6_holds_a : " (\<not>p i6) \<and> (q i6) " and
 i7_holds_a : " (\<not>p i7) \<and> (\<not>q i7) " and
 i8_holds_a : " (\<not>p i8) \<and> (\<not>q i8) " and
 i9_holds_a : " (\<not>p i9) \<and> (q i9) " and
 i10_holds_a : " (\<not>p i10) \<and> (q i10) " and 
 i11_holds_a : " (\<not>p i11) \<and> (\<not>q i11) " and
 i12_holds_a : " (\<not>p i12) \<and> (\<not>q i12) " and
 i13_holds_a : " (\<not>p i13) \<and> (\<not>q i13) " and
 i14_holds_a : " (\<not>p i14) \<and> (\<not>q i14) " and
 i15_holds_a : " (\<not>p i15) \<and> (\<not>q i15) " and
 i16_holds_a : " (\<not>p i16) \<and> (\<not>q i16) " 

lemma True nitpick [satisfy,user_axioms,show_all,card=16] oops

lemma  " \<lfloor> a1 cstit (p \<^bold>\<or> q) \<rfloor>\<^sub>l " 
  nitpick [satisfy,user_axioms,show_all,format=2,card=16] 
  using a1_i1a actual_wa i1_holds_a i2_holds_a i5_holds_a i6_holds_a by force
lemma  " \<lfloor> a2 cstit (p) \<rfloor>\<^sub>l "
  nitpick [satisfy,user_axioms,show_all,format=2,card=16] 
  using a2_i1a actual_wa i1_holds_a i2_holds_a i3_holds_a i4_holds_a by force 
lemma  " \<lfloor> gstit (F q) \<rfloor>\<^sub>l "
  nitpick [satisfy,user_axioms,show_all,format=2,card=16] 
  by (metis actual_wa i10_holds_a i9_holds_a rAgt_i1a rG_i1a rG_i2a)
lemma " \<lfloor> G (\<^bold>\<box>q) \<rfloor>\<^sub>l " sledgehammer
  by (metis actual_wa i10_holds_a i9_holds_a rG_i1a rbox_i9a)


lemma " (i5 rG i13) \<and> (i13 rbox i13)" 
  by (simp add: rG_i5a rbox_i13a)
lemma " (i5 ragt i5) \<and> (i5 rG i13) " 
  by (simp add: rAgt_i5a rG_i5a)

lemma " (i3 rG i11) \<and> (i11 rbox i11) " 
  by (simp add: rG_i3a rbox_i11a) 
lemma " (i3 ragt i3) \<and> (i3 rG i11) "
  by (simp add: rAgt_i3a rG_i3a)

lemma " (i1 rG i9) \<and> (i9 rbox i9) " 
  by (simp add: rG_i1a rbox_i9a)
lemma " (i1 ragt i1) \<and> (i1 rG i9) " 
  by (simp add: rAgt_i1a rG_i1a)
 
*)


end