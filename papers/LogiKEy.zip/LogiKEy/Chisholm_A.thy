theory Chisholm_A imports SDL                   (*Christoph Benzmüller & Xavier Parent, 2018*)

begin (* Chisholm Example *) 
 consts go::\<sigma> tell::\<sigma> kill::\<sigma>
 axiomatization where
  D1: "\<lfloor>\<^bold>\<circle><go>\<rfloor>" (*It ought to be that Jones goes to assist his neighbors.*) and
  D2: "\<lfloor>\<^bold>\<circle><go \<^bold>\<rightarrow> tell>\<rfloor>"  (*It ought to be that if Jones goes, then he tells them he is coming.*) and
  D3: "\<lfloor>\<^bold>\<circle><\<^bold>\<not>go \<^bold>\<rightarrow> \<^bold>\<not>tell>\<rfloor>" (*If Jones doesn't go, then he ought not tell them he is coming.*) and
  D4: "\<lfloor>\<^bold>\<not>go\<rfloor>\<^sub>l" (*Jones doesn't go. (This is encoded as a locally valid statement.)*)    


 (*Some Experiments*) 
  sledgehammer_params [max_facts=20] (*Sets default parameters for the theorem provers*)
  nitpick_params [user_axioms,expect=genuine,show_all,format=2] (*... and for the model finder.*)

 lemma True  nitpick [satisfy] oops  (*Consistency-check: Is there a model?*) 
 lemma False sledgehammer      oops  (*Inconsistency-check: Can Falsum be derived?*) 

 lemma "\<lfloor>\<^bold>\<circle><\<not>tell>\<rfloor>" sledgehammer  nitpick oops   (*Should James not tell?*)
 lemma "\<lfloor>\<^bold>\<circle><tell>\<rfloor>"  sledgehammer  nitpick oops   (*Should James tell?*)
 lemma "\<lfloor>\<^bold>\<circle><kill>\<rfloor>"  sledgehammer  nitpick oops   (*Should James kill?*)   

 (* The issue of Chisholm_A: D1 entails D3 (The requirement of logical independence is not met).*)
lemma  "(\<lfloor>\<^bold>\<circle><go>\<rfloor>) \<longrightarrow> (\<lfloor>\<^bold>\<circle><\<^bold>\<not>go \<^bold>\<rightarrow> \<^bold>\<not>tell>\<rfloor>)" sledgehammer  by simp
end

