open List
open Cmdline
open Interactive
open Automation
open State

let () =
  if Build_config.debug then
    begin
      Printexc.record_backtrace true;
      Printexc.register_printer Translation.exc_printers
    end;
  Sys.catch_break true

let rev =
  if Build_config.revision = "" then "" else "(" ^ Build_config.revision ^ ")"

let version () =
  print_endline ("LEO-II version v2.1 " ^ rev ^ " \
  (compiled on " ^ Sys.os_type ^ " with OCaml-" ^ Sys.ocaml_version ^ ")");
  if State.state_initialize.flags.verbose then Automation.atp_versions ()

type arg =
  | FILENAME of string (*name of file to process*)
  (*the rest of the arguments are described in "help ()" below*)
  | ANALYZE
  | ATP of string
  | ATPRC of string
  | ATPTIMEOUT of int
  | ATPFREQUENCY of int
  | DEBUG of int
  | DIR of string
  | EXPAND_EXTUNI
  | FOATP of string
  | HELP
  | INTERACTIVE
  | NOSLICES
  | MAXUNIDEPTH of int (*FIXME unidepth*)
  | PRETTYPRINTONLY (*FIXME prettyPrintOrig*)
  | PRIMSUBST of int
  | PROOFOUTPUT of int
  | PROTOCOL_OUTPUT
  | RELEVANCEFILTER of int
  | RELEVANCETOLERANCE of int
  | NOTREPLACELEIBNIZEQ
  | NOTREPLACEANDREWSEQ
  | NOTUSECHOICE
  | NOTUSEEXTUNI
  | NOTUSE_EXTCNFCOMBINED
  | SCRIPTMODE
  | SOS
  | TIMEOUT of int
  | TMPPATH of string (*FIXME tmp*)
  | TRANSLATION of string
  | UNFOLDDEFSEARLY
  | UNFOLDDEFSLATE
  | DEFSASRULES
  | ATPMAXCLAUSES of int
  | INSTANTIATE of int
  | VERBOSE
  | VERSION
  | ORDERING of string
  | AGEWEIGHT of int
  | WRITEFOCLAUSES

let help () = print_string ("\
    Usage: leo [OPTIONS] [FILE]\n\
    Options:\n \
     --analyze, -a              Compute and return features of the input problem for 
                                application in machine learning (used e.g. by MALES)
     --atp ATP=EXEC             Set the exec file for external prover ATP to EXEC\n \
                                (overrides the .leoatprc file, option can be used repeatedly)\n \
     --atprc FILE               Set ATP config file\n \
     --cores N                  Run N portfolio branches in parallel, one per core,\n \
                                and answer with the first that succeeds.\n \
                                0 (or \"auto\") takes the whole machine.\n \
     Default: 1, a single strategy (the branches are at portfolio_branches)\n \
     --atptimeout N, -at N      Set the ATPtimeout (calls to E) to N seconds\n \
     --atpfrequency N, -af N    Call the first-order prover every N iterations\n \
                                Default: 5\n \
     --debug N, -D N            Set debug level to N\n \
                                (0 = no output, 1 = minimal output, 2 = full output)\n \
                                Default: 0\n \
     --dir DIR, -d DIR          Run on all files in DIR\n \
     --expand_extuni            Provide detailed unification inferences. \n \
     --foatp PROVER, -f PROVER  Select PROVER as first-order prover\n\tCurrently supported: " ^
                              String.concat ", " Automation.supported_atps ^ "\n\tDefault: " ^ global_conf.foatp ^ "\n \
     --help, -h                 Display this help screen and exit\n \
     --interactive, -i          Start interactive mode\n \
                                Default is non-interactive\n \
     --noslices -ns             Deactivates automatic time slicing; please use after the -t option e.g. as in leo -t 20 -ns file.p\n \
     --prettyPrintOrig, -ppo    Write pretty print of expanded original problem to a file (in tmp)\n \
     --primsubst N, -ps N       Set the prim subst level to N \n \
                                Default: 3\n \
     --proofoutput N, -po N     Print proof object \n \
                                N=0 (default): no proof output  \n \
                                N=1: Print proof object without detailed information on the fo-atp contribution \n \
                                N=2: Print proof object with detailed information on the fo-atp contribution \n \
     --protocoloutput           Print full proof protocol. \n \
     --relevancefilter N, -rf N Set the relevance filter to N\n \
     --relevancetolerance N     Pin the per-round tolerance for new symbols;\n\t0 is the sharpest setting\n \
                                Default: 0\n \
     --notReplLeibnizEQ, -nrleq Do not automatically replace Leibniz EQ literals in clauses \n \
     --notReplAndrewsEQ, -nraeq Do not automatically replace Andrews EQ literals in clauses \n \
     --notUseChoice,     -nuc   Do not use the choice rule \n \
     --notUseExtuni,     -nue   Do not use extensional unification \n \
     --notUseExtCnfCmbd, -nux   Do not use the extcnf_combined rule \n \
     --order ORDERING           Use ORDERING\n\tAvailable options: " ^
                                String.concat ", " (List.map Orderings.ordering_to_string Orderings.available_orderings) ^ "\n \
     --ageWeightRatio N         Take one given clause by age in every N; 1 is first in first out\n \
     --scriptmode, -s           Start script mode\n \
     --sos, -S                  (this flag is currently deactivated, don't use)\n \
     --timeout N, -t N          Enforce timeout after N seconds\n \
                                (0 = no timeout)\n \
                                Default: 600 sec\n \
     --tmp PATH, -tmp PATH      Set path for temporary files\n \
     --translation TRANSLATION  Use TRANSLATION into FOL\n\tAvailable translations: " ^
                              String.concat ", " (List.map Translation_general.print_translation Translation_general.fo_translations) ^ "\n \
     --instantiate N            Also instantiate a universal variable with up to N \n \
                                of the problem's own lambda abstractions of its type \n \
                                (0 = off, the default) \n \
     --atpmaxclauses N          Send at most N clauses to the first-order prover \n \
     (0 = all of them, the default) \n \
     --defsasrules              Keep definitions folded and add them as equations \n \
     --unfolddefsearly, -ude    Prefer early unfolding of definitions \n \
     --unfolddefslate, -udl     Prefer late unfolding of definitions \n \
     --unidepth N, -u N         Set the maximal (pre-)unification depth to N\n \
                                Default: 5\n \
     --verbose, -V              Run in verbose mode\n \
     --version, -v              Display version information and exit\n \
     --writeFOclauses, -w       Write the first-order translations to a file (after termination)\n \
     \n")

let error msg =
  prerr_endline ("LEO-II: " ^ msg);
  prerr_endline ("Type \"" ^ Array.get Sys.argv 0 ^ " --help\" for argument info.");
  exit 255

(* try to read an integer from the command line arguments *)
let get_cl_int opt = function
  | [] -> error ("Option " ^ opt ^ " needs an argument.")
  | x :: xs ->
      try int_of_string x
      with _ -> error ("Option '" ^ opt ^ "' needs an argument.")

(* try to read a string from the command line arguments *)
let get_cl_string opt = function
  | [] -> error ("Option " ^ opt ^ " needs an argument.")
  | x :: _ -> x

(* parse command line arguments, return arg list. the arg list is accummulated
in "ps"*)
let rec parse_cl cs ps =
  match cs with
    | "-a" :: xs
    | "--analyze" :: xs ->
        parse_cl xs (ANALYZE :: ps)
    | "--atp" :: xs ->
        parse_cl (tl xs) (ATP (get_cl_string (hd cs) xs) :: ps)
    | "--atprc" :: xs ->
        parse_cl (tl xs) (ATPRC (get_cl_string (hd cs) xs) :: ps)
    | "-at" :: xs
    | "--atptimeout" :: xs ->
        parse_cl (tl xs) (ATPTIMEOUT (get_cl_int (hd cs) xs) :: ps)
    | "-af" :: xs
    | "--atpfrequency" :: xs ->
        parse_cl (tl xs) (ATPFREQUENCY (get_cl_int (hd cs) xs) :: ps)
    | "-D" :: xs
    | "--debug" :: xs ->
        parse_cl (tl xs) (DEBUG (get_cl_int (hd cs) xs) :: ps)
    | "-d" :: xs
    | "--dir" :: xs ->
        parse_cl (tl xs) (DIR (get_cl_string (hd cs) xs) :: ps)
    | "--expand_extuni" :: xs ->
        parse_cl xs (EXPAND_EXTUNI :: ps)
    | "-f" :: xs
    | "--foatp" :: xs ->
        parse_cl (tl xs) (FOATP (String.lowercase_ascii (get_cl_string (hd cs) xs)) :: ps)
    | "-h" :: xs
    | "--help" :: xs ->
        parse_cl xs (HELP :: ps)
    | "-i" :: xs
    | "--interactive" :: xs ->
        parse_cl xs (INTERACTIVE :: ps)
    | "-ns" :: xs
    | "--noslices" :: xs ->
        parse_cl xs (NOSLICES :: ps)
    | "-ppo" :: xs
    | "--prettyPrintOnly" :: xs ->
        parse_cl xs (PRETTYPRINTONLY :: ps)
    | "-ps" :: xs
    | "--primsubst" :: xs ->
        parse_cl  (tl xs) (PRIMSUBST (get_cl_int (hd cs) xs) :: ps)
    | "-po" :: xs
    | "--proofoutput" :: xs ->
        parse_cl (tl xs) (PROOFOUTPUT (get_cl_int (hd cs) xs) :: ps)
    | "--protocoloutput" :: xs ->
        parse_cl xs (PROTOCOL_OUTPUT :: ps)
    | "-rf" :: xs
    | "--relevancefilter" :: xs ->
        parse_cl (tl xs) (RELEVANCEFILTER (get_cl_int (hd cs) xs) :: ps)
    | "--relevancetolerance" :: xs ->
        parse_cl (tl xs) (RELEVANCETOLERANCE (get_cl_int (hd cs) xs) :: ps)
    | "-nrleq" :: xs
    | "--notReplLeibnizEQ" :: xs ->
        parse_cl xs (NOTREPLACELEIBNIZEQ :: ps)
    | "-nraeq" :: xs
    | "--notReplAndrewsEQ" :: xs ->
        parse_cl xs (NOTREPLACEANDREWSEQ :: ps)
    | "-nuc" :: xs
    | "--notUseChoice" :: xs ->
        parse_cl xs (NOTUSECHOICE :: ps)
    | "-nue" :: xs
    | "--notUseExtuni" :: xs ->
        parse_cl xs (NOTUSEEXTUNI :: ps)
    | "-nux" :: xs
    | "--notUseExtCnfCmbd" :: xs ->
        parse_cl xs (NOTUSE_EXTCNFCOMBINED :: ps)
    | "-s" :: xs
    | "--scriptmode" :: xs ->
        parse_cl xs (SCRIPTMODE :: ps)
    | "-S" :: xs
    | "--sos" :: xs ->
        parse_cl xs (SOS :: ps)
    | "-t" :: xs
    | "--timeout" :: xs ->
        parse_cl (tl xs) (TIMEOUT (get_cl_int (hd cs) xs) :: ps)
    | "-tmp" :: xs
    | "--tmp" :: xs ->
        parse_cl (tl xs) (TMPPATH (get_cl_string (hd cs) xs) :: ps)
    | "--translation" :: xs ->
        parse_cl (tl xs) (TRANSLATION (get_cl_string (hd cs) xs) :: ps)
    | "-ude" :: xs
    | "--unfolddefsearly" :: xs ->
        parse_cl xs (UNFOLDDEFSEARLY :: ps)
    | "--defsasrules" :: xs ->
        parse_cl xs (DEFSASRULES :: ps)
    | "--atpmaxclauses" :: xs ->
        parse_cl (tl xs) (ATPMAXCLAUSES (get_cl_int (hd cs) xs) :: ps)
    | "--instantiate" :: xs ->
        parse_cl (tl xs) (INSTANTIATE (get_cl_int (hd cs) xs) :: ps)
    | "-udl" :: xs
    | "--unfolddefslate" :: xs ->
        parse_cl xs (UNFOLDDEFSLATE :: ps)
    | "-u" :: xs
    | "--unidepth" :: xs ->
        parse_cl (tl xs) (MAXUNIDEPTH (get_cl_int (hd cs) xs) :: ps)
    | "-V" :: xs
    | "--verbose" :: xs ->
        parse_cl xs (VERBOSE :: ps)
    | "-v" :: xs
    | "--version" :: xs ->
        parse_cl xs (VERSION :: ps)
    | "--order" :: xs ->
        parse_cl (tl xs) (ORDERING (get_cl_string (hd cs) xs) :: ps)
    | "--ageWeightRatio" :: xs ->
        parse_cl (tl xs) (AGEWEIGHT (get_cl_int (hd cs) xs) :: ps)
    | "-w" :: xs
    | "--writeFOclauses" :: xs ->
        parse_cl xs (WRITEFOCLAUSES :: ps)
    | x :: xs ->
          if String.get x 0 = '-'
          then error ("Unknown command line argument \'" ^ x ^ "\'.")
          else
            (*the argument must be a filename, so attempt to parse it.*)
            parse_cl xs (FILENAME x :: ps)
    | [] -> ps (*return the arglist*)

(*How many slices the budget can actually carry.  A slice shorter than the time
  its own schedule will try to spend inside it is overrun by its first call to
  the first-order prover, which at a short global timeout consumes the slice
  whole and leaves the strategies after it unrun.

  Everything that divides the budget must use this same number.  Deriving the
  local time limit from the configured slice count while the scheduler creates
  a different number of slices gives the prover a limit computed for slices
  that do not exist -- which is what the FIXME under TIMEOUT below observed.*)
let effective_slices timeout =
  max 1 (min global_conf.time_slices (timeout / State.min_slice_seconds))

let cleanup () =
  Interactive.kill_children ();
  Util.delete_all_tmpfiles ()

(*FIXME move to State, or delete -- left here temporarily for testing*)
let sched_num = ref 0

let sched_inc () =
  let next = 1 + !sched_num in
    sched_num := next;
    next

(*This function oversees the running schedules, and controlled is returned to
  this function when a schedule's timeout expires. It consumes the schedules
  from a queue and runs them for the scheduled duration. The queue is created
  at the start of the Leo2 process.*)
let run_schedules () =
  (*assumes schedule queue isn't empty*)
  let run_next_schedule () =
    let schedule = Queue.take global_conf.schedules in
    (*if this is the last schedule and we have unused time from earlier slices,
      use it now (or, if we've used up too much time previously, decrement from
      this strategy's time)*)
    let duration =
      (*in any case, correct for overshot*)
      if Queue.is_empty global_conf.schedules then
        float global_conf.global_timeout -. !State.problem_cumulative_time -. !State.problem_overshot
      else
        schedule.duration -.
          (!State.problem_overshot /. float (Queue.length global_conf.schedules)) in
    (*Timeout for the ATP*)
    let atptmo =
      (*FIXME constants can be made parameters*)
      min 25
        (max State.atp_min_timeout
           (int_of_float (duration /. float State.atp_subslices)))
    in
      if Build_config.debug then
        begin
          Util.sysoutf 2 (fun () -> ("Schedule " ^ string_of_int (sched_inc ()) ^
          " (total of " ^ string_of_float duration ^ "s" ^
          ", E gets slices of maximum " ^ string_of_int atptmo ^ ")\n"))
        end;

      State.set_current_success_status None Unknown;
      begin
        match State.global_conf.atp_timeout_forced with
            None -> ignore(State.set_flag_atp_timeout State.state_initialize atptmo)
          | Some forced_timeout ->
              if forced_timeout > atptmo then
                prerr_endline ("WARNING: forcing ATP timeout of " ^ string_of_int forced_timeout ^ "s" ^
                                 " but strategy would have assigned " ^ string_of_int atptmo ^ "s");
              ignore(State.set_flag_atp_timeout State.state_initialize forced_timeout)
      end;
      State.current_schedule := {schedule with duration = duration};
      State.child_time := 0.0;
      State.problem_overshot := 0.0;
      State.schedule_start := Unix.gettimeofday () +. duration;
      Strategy_scheduling.execute_commands schedule.strategy in
  let solved = ref false
  in
    (*having completed the schedule, check if there's a next schedule to run*)
    while (not (Queue.is_empty global_conf.schedules) && not !solved)
    do
      let start_time = Unix.gettimeofday () in
      try
        solved := run_next_schedule ()
      with State.STRATEGY_TERMINATED -> ();

      State.problem_cumulative_time := !State.problem_cumulative_time +.
        !State.current_schedule.duration;
      State.problem_overshot := !State.problem_overshot +.
        (Unix.gettimeofday () -. start_time) -. !State.current_schedule.duration;
    done;

    if not !solved &&
      !State.problem_cumulative_time > float global_conf.global_timeout then
      set_current_success_status None Timeout
    (*otherwise if we haven't solved by haven't exceeded timeout, leave status as is*)

(*FIXME move to some library module*)
(*Take up to n items from the prefix of l;
  doesn't complain if there are fewer than n elements in l*)
let take_upto n l =
  let rec take_upto' n revacc l =
    if n = 0 then revacc
    else
      match l with
          [] -> revacc
        | (x :: xs) -> take_upto' (n - 1) (x :: revacc) xs
  in List.rev (take_upto' n [] l)

let execute_conf () =
  (*FIXME hack -- set hook in Orderings*)
  Orderings.set_ord (State.get_flag_termorder State.state_initialize);
  if global_conf.interactive
  then comint ()
  else
    begin
      ignore(Interactive.initialize ());
      if global_conf.dir <> ""
      then
        let cmd = "prove-directory-with-fo-atp " ^ global_conf.dir ^ " " ^
          global_conf.foatp
        in
          print_endline ("\nLEO-II: " ^ cmd);
          ignore (Cmdline.execute_command cmd)
      else
        (*FIXME check behaviour when run on multiple problem files*)
        if global_conf.problemfiles <> [] then
          let compute_schedules_for_prob probfilename =
            (*FIXME currently each schedule is given an equal slice of time*)
            (*A slice shorter than the time its own schedule will try to
              spend inside it is wasted.  The first-order prover is asked for
              atp_subslices calls and each has a floor of atp_min_timeout, so
              a slice below their product is overrun by its first call; at a
              short global timeout that consumes the slice whole and the
              strategies after it never run at all.  The number of slices is
              therefore capped by what the budget can carry, which leaves the
              behaviour at long timeouts unchanged.*)
            let slices = effective_slices global_conf.global_timeout in
            let timeslice = max 1 (global_conf.global_timeout / slices) in
            (*The clock starts here, before the problem is read.  Reading and
              indexing it happens before any slice exists and can take longer
              than the whole limit, and until this was set nothing could stop
              it.*)
            State.global_deadline :=
              Unix.gettimeofday () +. float_of_int global_conf.global_timeout;
            (*And a real alarm as the backstop.  A deadline only helps where
              something reads it, and the places that do not are not a fixed
              list: indexing the problem, normalising a formula, whatever is
              added next.  A signal arrives wherever the prover happens to be,
              so the limit holds without every loop having to know about it.
              The grace is what a run needs to report its own status.*)
            ignore
              (Unix.setitimer Unix.ITIMER_REAL
                 {Unix.it_value = float_of_int (global_conf.global_timeout + 5);
                  Unix.it_interval = 2.0});
            let schedules =
              try
                take_upto slices
                  (Strategy_scheduling.compute_strategies global_conf probfilename)
              with State.STRATEGY_TERMINATED ->
                (*Out of time before a single strategy could be chosen.*)
                set_current_success_status None Timeout;
                []
            in
              Queue.clear global_conf.schedules;
              if Build_config.debug then Util.sysoutf 2 (fun () -> ("Duration of slices: " ^ string_of_int timeslice));
              (*enqueue schedules.  A strategy that filters the axioms by
                relevance finishes fast when it finishes at all -- the problems
                it adds to the ontological-argument dataset take 0.1 to 1.1
                seconds -- and a slice as long as the others only takes time
                from the unfiltered search, which loses what needs the whole
                budget.  It gets a quarter of the budget, two seconds at least,
                and the other strategies share the rest; time a slice leaves
                unused falls to the last one anyway.*)
              let is_filter = function "flag-relevance-filter 1" :: _ -> true | _ -> false in
              let total = float_of_int (timeslice * List.length schedules) in
              let n_filter = List.length (List.filter is_filter schedules) in
              let n_plain = List.length schedules - n_filter in
              let filter_dur =
                if n_filter = 0 then 0. else max 2.0 (total /. 4. /. float_of_int n_filter) in
              let plain_dur =
                if n_plain = 0 then total /. float_of_int n_filter
                else (total -. filter_dur *. float_of_int n_filter) /. float_of_int n_plain in
              List.iter
                (fun strat ->
                   let sched : schedule =
                     {duration = (if is_filter strat then filter_dur else plain_dur);
                      strategy = strat}
                   in
                     Queue.add sched global_conf.schedules)
                schedules;

              (*start*)
              State.problem_cumulative_time := 0.;
              Translation.reset_prev_fo_clauses_cache ();
              ignore(run_schedules ());
              sys_time_offset := !sys_time_offset +. !State.problem_cumulative_time;

              Util.sysoutf 0 (fun () -> (State.szs_result None(*FIXME state info not available?*)
                                          ^ "\n"))
          in
            begin
              sys_time_offset := Sys.time ();
              List.iter compute_schedules_for_prob global_conf.problemfiles
          end
        else error "No problem file given."
    end

(* process the argument list, build the configuration record
 * and finally call execute_conf *)
let rec process args = match args with
  | FILENAME s :: args ->
      global_conf.problemfiles <- s :: global_conf.problemfiles;
      process args
  | ATP s :: args ->
      let eqpos = String.index s '=' in
      let len = String.length s in
      let atp = String.sub s 0 eqpos in
      let executable = String.sub s (eqpos + 1) (len - eqpos - 1) in
      (* print_string ("ATP: "^atp^", exec: "^executable^"\n"); *)
      if Sys.file_exists executable 
      then
	( Automation.atp_cmds := (atp, executable) :: !Automation.atp_cmds;
	  Automation.atp_configured := true;
	  Util.sysoutf 1 (fun () -> ("  Configured: " ^ atp ^ " = " ^ executable ^ "\n"));
	);
	process args
  | ANALYZE :: args ->
      global_conf.analyze <- true;
      process args
  | ATPRC s :: args ->
      Automation.atp_config_file := s;
      process args
  | ATPTIMEOUT n :: args ->
      global_conf.atp_timeout_forced <- Some n;
      ignore(State.set_flag_atp_timeout State.state_initialize (max 5 n));
      process args
  | ATPFREQUENCY n :: args ->
      if n < 1 then error "--atpfrequency needs a positive argument";
      ignore(State.set_flag_atp_calls_frequency State.state_initialize n);
      process args
  | DEBUG n :: args ->
      global_conf.debug <- n;
      Util.debuglevel := n;
      process args
  | DIR s :: args ->
      global_conf.dir <- s;
      process args
  | EXPAND_EXTUNI :: args ->
      ignore(State.set_flag_expand_extuni State.state_initialize true);
      process args
  | FOATP s :: args ->
      global_conf.foatp <- s;
      process args
  | HELP :: args ->
      help ()
  | INTERACTIVE :: args ->
      global_conf.interactive <- true;
      Cmdline.interactive := true;
      Util.debuglevel := 1;
      Cmdline.save_tcio ();
      process args
  | NOSLICES :: args ->
      global_conf.time_slices <- 1;
      process args
  | MAXUNIDEPTH n :: args ->
      ignore(State.set_flag_max_uni_depth State.state_initialize (max 1 n));
      process args
  | PRETTYPRINTONLY :: args ->
      ignore(State.set_flag_pretty_print_only State.state_initialize true);
      process args
  | PRIMSUBST n :: args ->
      ignore(State.set_flag_prim_subst State.state_initialize n);
      process args
  | PROOFOUTPUT n :: args ->
      ignore(State.set_flag_proof_output State.state_initialize n);
      process args
  | PROTOCOL_OUTPUT :: args ->
      ignore(State.set_flag_protocol_output State.state_initialize true);
      process args
  | RELEVANCEFILTER n :: args ->
      ignore(State.set_flag_relevance_filter State.state_initialize (max 0 n));
      process args
  | RELEVANCETOLERANCE n :: args ->
      (*How many symbols new to the selection one round may admit.  Without it
        the tolerance falls with the round, so a higher filter level admits more
        in its first round and prunes less; pinning it at 0 keeps only the
        axioms that introduce nothing new, which is the sharpest the filter
        can be.*)
      ignore(State.set_flag_relevance_tolerance State.state_initialize (max 0 n));
      process args
  | NOTREPLACELEIBNIZEQ :: args ->
      ignore(State.set_flag_replace_leibnizEQ State.state_initialize false);
      process args
  | NOTREPLACEANDREWSEQ :: args ->
      ignore(State.set_flag_replace_andrewsEQ State.state_initialize false);
      process args
  | NOTUSECHOICE :: args ->
      ignore(State.set_flag_use_choice State.state_initialize false);
      process args
  | NOTUSEEXTUNI :: args ->
      ignore(State.set_flag_use_extuni State.state_initialize false);
      process args
  | NOTUSE_EXTCNFCOMBINED :: args ->
      ignore(State.set_flag_use_extcnf_combined State.state_initialize false);
      process args
  | SCRIPTMODE :: args ->
      global_conf.interactive <- true;
      process args
  | SOS :: args ->
      ignore(State.set_flag_sos State.state_initialize false);
      process args
  | TIMEOUT n :: args ->
      (*NOTE the code below is left in case it affects the interactive mode. In automatic mode,
             the timeout behaviour of Leo2 is controlled by the strategy scheduling mechanism.*)
      let globaltmo  = (max 1 n) in
      (*ATP applied for between 1 and 25 seconds. The exact value is at most 30% of the global timeout
        if the sequence instructions (related to -t and -ns) are followed*)
      let slices = effective_slices n in
      let atptmo = (min 25 (max 1 (n / (slices + 2)))) in
      (*Timeout for each slice; each strategy is given an equal amount of time*)
      let localtmo = (max 1 (n / slices)) in
       global_conf.global_timeout <- globaltmo; (*used to scale time slices for each schedule*)
       Interactive.set_original_timeout globaltmo;
       Interactive.set_timeout localtmo; (*FIXME relevant?*)
       ignore
        (State.set_flag_atp_timeout
         State.state_initialize atptmo);
       ignore
        (State.set_flag_max_local_time
         State.state_initialize localtmo); (*FIXME relevant?*)
       process args
  | TMPPATH s :: args ->
      (*This process was given a directory, so the one it made for itself at
        startup is not wanted.  It goes now and not at exit, because a
        portfolio branch is killed rather than allowed to finish and never
        reaches its exit handlers.*)
      (try Unix.rmdir Util.own_tmp_dir with Unix.Unix_error _ -> ());
      Util.tmp_path := s;
      process args
  | TRANSLATION s :: args ->
      ignore(State.set_flag_fo_translation
               State.state_initialize
               (* This checks that the translation is indeed supported *)
               (Translation_general.print_translation (Translation_general.read_translation s)));
      process args
  | UNFOLDDEFSEARLY :: args ->
      ignore(State.set_flag_unfold_defs_early State.state_initialize true);
      process args
  | INSTANTIATE n :: args ->
      ignore(State.set_flag_instantiate_max State.state_initialize n);
      process args
  | ATPMAXCLAUSES n :: args ->
      ignore(State.set_flag_atp_max_clauses State.state_initialize n);
      process args
  | DEFSASRULES :: args ->
      ignore(State.set_flag_defs_as_rules State.state_initialize true);
      process args
  | UNFOLDDEFSLATE :: args ->
      ignore(State.set_flag_unfold_defs_early State.state_initialize false);
      process args
  | VERBOSE :: args ->
      ignore(State.set_flag_verbose State.state_initialize true);
      process args
  | VERSION :: args ->
      version ()
  | AGEWEIGHT n :: args ->
      if n < 1 then error "--ageWeightRatio needs a positive argument";
      Clauseset.age_weight_ratio := n;
      process args
  | ORDERING s :: args ->
      ignore(State.set_flag_termorder
               State.state_initialize
               (* This checks that the weighting is indeed supported *)
               (Orderings.ordering_of_string s));
      (*possible syntax idea for precedences (as done by E and others):
        weighting(val=VALUE,fun={x:y,...},...)
        FIXME currently order information not supported.
      *)
      process args
  | WRITEFOCLAUSES :: args ->
      ignore(State.set_flag_write_fo_like_clauses State.state_initialize true);
      process args
  | [] -> execute_conf ()

(*A parallel portfolio.

  LEO-II runs its strategies one after another inside a single budget on a
  single core.  That ordering cannot be fixed by reordering, because the
  settings that solve what the default cannot are exactly the settings that
  lose most of what it can.  The relevance filter is the clearest case: it
  answers 96 of the 294 problems of the ontological-argument set on its own,
  and 20 of the 126 that the default misses.  As a default it is a disaster;
  as a sibling it is the most valuable branch there is.

  A branch is this same binary re-executed with different flags, so every
  branch takes the ordinary code path and the soundness of the whole is the
  soundness of a single run.  Nothing is shared between branches but the
  answer.  The default is one core, and at one core none of this code runs,
  so single-core behaviour is unchanged -- which also keeps LEO-II comparable
  with the single-core first-order provers it is usually measured against.

  The branches below are a greedy cover, computed over all 294 problems and
  not over the ones the default misses.  That distinction is the whole
  lesson: measured on the 120 the default misses, "-rf 1 -ns" looked like the
  second-best branch there is; measured on all 294 it answers 105, because it
  throws away more than it gains.  A cover over a subset silently assumes
  every setting keeps what the default already had, and none of them do.

  Thirteen settings were run one at a time over all 294 at ten seconds, one
  core each.  What each branch adds, as the running total:

    --translation fof_experiment                             181
    -rf 1 -ns --relevancetolerance 1 -ps 0 -nux              212
    -ns -nux                                                 216
    -rf 1 -ns --relevancetolerance 3 -ps 0 -nux              220
    -ns                                                      222

  The plain configuration is kept as the first branch even though the cover
  does not need it: it answers 180 on its own, it is the configuration every
  other measurement is against, and a branch costs nothing but a core.

  For scale, on the same problems and the same limit: E 3.2 answers 209 with
  "--auto", 218 with its own schedule on one core and 226 with that schedule
  on five; Vampire 4.8 answers 173 plainly and 184 with its portfolio on five
  cores; Leo-III answers 160.

  Every setting that helps makes the search *smaller* -- no primitive
  substitution, no combined extensional CNF, a tighter relevance filter.  The
  search is drowning in its own conclusions, not missing them.  Note that
  three of these branches are incomplete configurations; see the guard in
  interactive.ml that keeps such a branch from claiming a countermodel.*)
let portfolio_branches =
  [| [];
     ["--translation"; "fof_experiment"];
     ["--relevancefilter"; "1"; "-ns"; "--relevancetolerance"; "1";
      "--primsubst"; "0"; "-nux"];
     ["-ns"; "-nux"];
     ["--relevancefilter"; "1"; "-ns"; "--relevancetolerance"; "3";
      "--primsubst"; "0"; "-nux"];
     ["-ns"] |]

(*A status that settles the problem.  Anything else (Unknown, Timeout, Error,
  GaveUp) is a branch failing, and the next branch is still worth waiting for.*)
let conclusive_status line =
  let statuses =
    ["Theorem"; "Unsatisfiable"; "ContradictoryAxioms";
     "CounterSatisfiable"; "Satisfiable"] in
  let marker = "SZS status " in
  match String.index_opt line 'S' with
    | None -> false
    | Some _ ->
        let n = String.length marker and l = String.length line in
        let rec at i =
          if i + n > l then false
          else if String.sub line i n = marker then
            let rest = String.sub line (i + n) (l - i - n) in
              List.exists
                (fun st ->
                   let m = String.length st in
                     String.length rest >= m && String.sub rest 0 m = st)
                statuses
          else at (i + 1)
        in at 0

let file_is_conclusive path =
  try
    let ch = open_in path in
    let rec scan () =
      match (try Some (input_line ch) with End_of_file -> None) with
        | None -> false
        | Some l -> if conclusive_status l then true else scan ()
    in
    let r = scan () in close_in ch; r
  with Sys_error _ -> false

let dump_file path =
  try
    let ch = open_in path in
    let rec go () =
      match (try Some (input_line ch) with End_of_file -> None) with
        | None -> ()
        | Some l -> print_endline l; go ()
    in go (); close_in ch
  with Sys_error _ -> ()

(*Strip "--cores N" from an argument list, so that what is handed to a branch
  is the user's own command line and nothing else.*)
let rec strip_cores = function
  | "--cores" :: _ :: xs -> strip_cores xs
  | x :: xs -> x :: strip_cores xs
  | [] -> []

(*Branches must not share a scratch directory.  LEO-II names its temporary
  files after the problem's basename alone, so two branches working on the
  same problem write, and then unlink, the same file; the loser dies with
  ENOENT on a file it had every reason to expect.  Each branch therefore gets
  its own directory underneath whichever one the user asked for.  The option
  is removed and reinserted rather than appended, so that there is exactly one
  of it and no question of which occurrence wins.*)
let rec strip_tmp = function
  | ("--tmp" | "-tmp") :: _ :: xs -> strip_tmp xs
  | x :: xs -> x :: strip_tmp xs
  | [] -> []

let rec tmp_of = function
  | ("--tmp" | "-tmp") :: d :: _ -> Some d
  | _ :: xs -> tmp_of xs
  | [] -> None

(*How many cores this machine reports.  There is no portable call for it, so
  ask the system the way each system likes to be asked and believe the first
  answer.  Anything unreadable means one core, which is the conservative
  reading: it runs the plain configuration and nothing else.*)
let detected_cores =
  let ask cmd =
    try
      let ch = Unix.open_process_in cmd in
      let line = try Some (input_line ch) with End_of_file -> None in
        ignore (Unix.close_process_in ch);
        match line with
          | Some l -> (try Some (int_of_string (String.trim l)) with Failure _ -> None)
          | None -> None
    with _ -> None in
  let rec first = function
    | [] -> 1
    | cmd :: rest ->
        (match ask cmd with
           | Some n when n > 0 -> n
           | _ -> first rest) in
    lazy (first ["getconf _NPROCESSORS_ONLN 2>/dev/null";
                 "sysctl -n hw.ncpu 2>/dev/null";
                 "nproc 2>/dev/null"])

(*One core unless asked otherwise, which is how the provers LEO-II is measured
  against behave: E's "--auto-schedule" without an argument is one core and
  only "=N" or "=Auto" is more, and Vampire's "--cores" is 1 by default even
  in portfolio mode, with 0 meaning the maximum.  "--cores 0" and
  "--cores auto" follow Vampire's spelling and take the whole machine, which
  the number of branches then clips.  Note that each branch runs a
  first-order prover beside itself, so the whole machine means more processes
  than cores.*)
let all_cores () = max 1 (Lazy.force detected_cores)

let rec cores_of = function
  | "--cores" :: ("auto" | "Auto" | "0") :: _ -> Some (all_cores ())
  | "--cores" :: n :: _ -> (try Some (int_of_string n) with Failure _ -> None)
  | _ :: xs -> cores_of xs
  | [] -> None

(*Run the first n branches at once and exit with the first conclusive answer.
  Does not return.*)
let run_portfolio n com_line =
  let base = strip_tmp (strip_cores com_line) in
  let tmp_root =
    match tmp_of com_line with
      | Some d -> d
      | None -> Filename.get_temp_dir_name () in
  let n = min n (Array.length portfolio_branches) in
  let scratch =
    Array.init n
      (fun i ->
         let d = Filename.concat tmp_root
                   (Printf.sprintf "leo_branch_%d_%d" (Unix.getpid ()) i) in
           (try Unix.mkdir d 0o700 with Unix.Unix_error _ -> ()); d) in
  let outputs = Array.init n (fun i -> Filename.temp_file "leo_branch" (string_of_int i ^ ".out")) in
  let children =
    Array.init n
      (fun i ->
         let argv =
           (*"--cores 1" is not decoration: without it a branch finds no
             "--cores" on its command line, reads the default, and forks a
             portfolio of its own.*)
           Array.of_list
             (Sys.executable_name ::
                (base @ portfolio_branches.(i) @
                   ["--cores"; "1"; "--tmp"; scratch.(i)])) in
           match Unix.fork () with
             | 0 ->
                 (*A branch stays in the process group it was forked in.
                   Putting it in its own session was tried and is wrong: it is
                   how callers kill this prover.  A harness, a CASC driver or a
                   shell sends a signal to the whole group, and a branch that
                   has left the group survives it.  Doing that for 294 problems
                   left four immortal branches behind for every problem that
                   ran out of time, and they were still holding the machine
                   down hours later.  The first-order prover a branch leaves
                   behind stops on its own CPU limit, which is bounded by
                   atp_timeout.*)
                 let fd = Unix.openfile outputs.(i)
                            [Unix.O_WRONLY; Unix.O_CREAT; Unix.O_TRUNC] 0o600 in
                   Unix.dup2 fd Unix.stdout;
                   Unix.dup2 fd Unix.stderr;
                   Unix.close fd;
                   (try Unix.execv Sys.executable_name argv
                    with _ -> exit 2)
             | pid -> pid)
  in
  let alive = Array.make n true in
  let kill_rest except =
    Array.iteri
      (fun i pid ->
         if i <> except && alive.(i) then
           begin
             (*Only this branch.  Signalling the group would signal the
               supervisor too, since the branch is no longer a group of its
               own.*)
             (try Unix.kill pid Sys.sigkill with Unix.Unix_error _ -> ());
             alive.(i) <- false
           end)
      children in
  let cleanup () =
    Array.iter (fun f -> try Sys.remove f with Sys_error _ -> ()) outputs;
    (*and the branches' scratch directories, with whatever a killed branch left
      in them.  A branch that is shot does not tidy up after itself, so this is
      the only place it can happen; without it a run over 294 problems left
      fifteen hundred directories in the system's temporary directory.*)
    Array.iter
      (fun d ->
         (try Array.iter (fun f -> try Sys.remove (Filename.concat d f)
                                   with Sys_error _ -> ())
                         (Sys.readdir d)
          with Sys_error _ -> ());
         try Unix.rmdir d with Unix.Unix_error _ -> ())
      scratch;
    Array.iter
      (fun d ->
         (try Array.iter (fun f -> try Sys.remove (Filename.concat d f)
                                   with Sys_error _ -> ()) (Sys.readdir d)
          with Sys_error _ -> ());
         (try Unix.rmdir d with Unix.Unix_error _ -> ()))
      scratch in
  let index_of_pid pid =
    let r = ref (-1) in
      Array.iteri (fun i p -> if p = pid then r := i) children; !r in
  let rec wait_for remaining =
    if remaining = 0 then None
    else
      match (try Some (Unix.wait ()) with Unix.Unix_error _ -> None) with
        | None -> None
        | Some (pid, status) ->
            let i = index_of_pid pid in
              if i < 0 then wait_for remaining
              else
                begin
                  alive.(i) <- false;
                  if file_is_conclusive outputs.(i) then Some (i, status)
                  else wait_for (remaining - 1)
                end
  in
    match wait_for n with
      | Some (i, status) ->
          kill_rest i;
          dump_file outputs.(i);
          cleanup ();
          exit (match status with Unix.WEXITED c -> c | _ -> 1)
      | None ->
          (*Nobody settled it.  Report the default branch, which is the one
            whose inconclusive answer the user would have got anyway.*)
          kill_rest (-1);
          dump_file outputs.(0);
          cleanup ();
          exit 1


let leo_main () =
  (*POSIX signal number for "CPU time limit exceeded"*)
  let sigxcpu = 24
  in
    (*register signal handlers*)
    begin
      try
        (*A first-order prover that rejects its input exits at once, and the
          write that is still in flight then raises SIGPIPE, whose default is
          to kill the process.  LEO-II died there without printing an SZS
          status at all, so a caller saw it vanish rather than fail.  Ignored,
          the write fails as an ordinary error and the run ends with a status
          like any other.*)
        ignore(Sys.signal Sys.sigpipe Sys.Signal_ignore);
        (*The alarm above lands here: say the run timed out and leave, the way
          the CPU-limit signal already does.*)
        ignore(Sys.signal Sys.sigalrm
                 (Sys.Signal_handle
                    (fun _ ->
                       set_current_success_status None Timeout;
                       cleanup ();
                       raise (Termination None))));
        ignore(Sys.signal Sys.sigquit
                 (Sys.Signal_handle
                    (fun _ ->
                       set_current_success_status None Force;
                       cleanup ();
                       raise (Termination None))));
        ignore(Sys.signal sigxcpu
                 (Sys.Signal_handle
                    (fun _ ->
                       set_current_success_status None ResourceOut;
                       cleanup ();
                       raise (Termination None))));
        ignore(Sys.signal Sys.sigvtalrm
                 (Sys.Signal_handle
                    (fun _ ->
                       assert global_conf.interactive;
                       (*if in interactive mode then preserve current behaviour*)
                       Interactive.handle_timeout ())));
      (*FIXME check if following exclusion affects zombies*)
      (*FIXME could make dependent on a DEBUG switch:
        ignore(Sys.signal Sys.sigchld Sys.Signal_ignore); *)
        let com_line = List.tl (Array.to_list Sys.argv) in
        (*The portfolio is decided before anything else is set up: a branch is
          a fresh process running the ordinary command line, so the supervisor
          must not have started proving anything itself.*)
        (match cores_of com_line with
           | Some n when n > 1 ->
               (*A branch is this binary run again on the same command line,
                 which is meaningless for anything that does not prove one
                 problem and exit: the help screen, the version, the
                 interactive prompt, a directory, the feature analysis.*)
               let excluded =
                 ["-h"; "--help"; "-v"; "--version"; "-i"; "--interactive";
                  "-d"; "--dir"; "-s"; "--scriptmode"; "-a"; "--analyze"] in
                 if not (List.exists (fun x -> List.mem x excluded) com_line)
                 then run_portfolio n com_line (*does not return*)
           | _ -> ());
        let args = parse_cl (strip_cores com_line) [] in
          process args
      with
        | Termination maybe_st ->
            (*Some unplanned exits pass through here: e.g. timeouts, errors*)
            begin
              Util.sysoutf 0 (fun () -> (State.szs_result maybe_st ^ "\n"));
              exit (szs_exitcode ())
            end
        | e ->
            (*All other unplanned exists pass through here*)
            if e = Sys.Break then
              set_current_success_status None User
            else
              begin
                set_current_success_status None Error;
                prerr_endline ("\nError occurred:" ^ Printexc.to_string e);
                prerr_endline (Printexc.get_backtrace ())
              end;
            Util.sysoutf 0 (fun () -> (State.szs_result None ^ "\n"));
            exit (szs_exitcode ())
    end;
    if not global_conf.interactive then
        exit (szs_exitcode ())

let () = if not Build_config.toplevel then leo_main ()
