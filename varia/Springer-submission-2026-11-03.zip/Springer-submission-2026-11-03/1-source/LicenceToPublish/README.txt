Contributor Agreements — nine chapter authors

  1 Cordelia Mühlenbeck      6 Levin Hornischer
  2 Tim Lethen               7 Brigitte Falkenburg
  3 Edward N. Zalta          8 Claus Kiefer
  4 Georgii D. Paksiutov     9 Seán McFadden
  5 Gary Mar

The signed forms follow. The editors are circulating the Contributor
Agreement supplied by the publisher on 3 November 2026 and will send the
complete set as soon as it is in. Contact details for all nine authors are
in Contributor-details.txt in the source folder.
